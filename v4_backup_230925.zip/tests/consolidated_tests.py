#!/usr/bin/env python3
"""
HH v4 CONSOLIDATED TEST SUITE
Единый модуль тестирования приоритетов 1-2 с общим выводом результатов

Автор: AI Assistant
Дата: 23.09.2025
Соответствует требованиям: req_16572309.md
"""

import sys
import os
import time
import json
import sqlite3
import requests
import psutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Any

# Добавляем корневую папку проекта в путь для импортов
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.database_v3 import VacancyDatabase
from core.scheduler_daemon import SchedulerDaemon
from core.task_dispatcher import TaskDispatcher
from core.auth import apply_auth_headers
from plugins.fetcher_v4 import VacancyFetcher


class TestResult:
    """Структура для хранения результата теста"""
    def __init__(self, test_id: str, name: str, priority: int):
        self.test_id = test_id
        self.name = name
        self.priority = priority
        self.passed = False
        self.error_message = ""
        self.execution_time = 0.0
        self.details = {}


class ConsolidatedTestSuite:
    """Основной класс консолидированного тестирования"""
    
    def __init__(self):
        self.results: List[TestResult] = []
        self.config = self._load_config()
        self.start_time = time.time()
        
    def _load_config(self) -> Dict:
        """Загрузка конфигурации"""
        config_path = Path(__file__).parent.parent / "config" / "config_v4.json"
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  Не удалось загрузить конфигурацию: {e}")
            return {}
    
    def _execute_test(self, test_func, test_id: str, name: str, priority: int) -> TestResult:
        """Выполнение одного теста с измерением времени"""
        result = TestResult(test_id, name, priority)
        start_time = time.time()
        
        try:
            test_func(result)
            result.passed = True
        except Exception as e:
            result.passed = False
            result.error_message = str(e)
        
        result.execution_time = time.time() - start_time
        return result


class Priority1Tests(ConsolidatedTestSuite):
    """Критические тесты приоритета 1 - должны проходить 100%"""
    
    def test_resource_monitoring_critical_thresholds(self, result: TestResult):
        """2.1.1 - Мониторинг системных ресурсов"""
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        result.details = {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'disk_percent': disk.percent
        }
        
        # Проверяем что мониторинг работает
        assert cpu_percent >= 0, "CPU мониторинг не работает"
        assert memory.percent >= 0, "Memory мониторинг не работает"
        assert disk.percent >= 0, "Disk мониторинг не работает"
        
        # Проверяем критические пороги из конфигурации
        monitoring_config = self.config.get('system_monitoring', {})
        cpu_critical = monitoring_config.get('cpu_critical_percent', 95)
        memory_critical = monitoring_config.get('memory_critical_percent', 95)
        disk_critical = monitoring_config.get('disk_critical_percent', 95)
        
        if cpu_percent > cpu_critical:
            result.details['cpu_alert'] = f"CPU превышает критический порог {cpu_critical}%"
        if memory.percent > memory_critical:
            result.details['memory_alert'] = f"Память превышает критический порог {memory_critical}%"
        if disk.percent > disk_critical:
            result.details['disk_alert'] = f"Диск превышает критический порог {disk_critical}%"
    
    def test_service_status_response(self, result: TestResult):
        """2.1.2 - Проверка статуса демона"""
        try:
            # Ищем процесс демона
            daemon_found = False
            daemon_info = {}
            
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
                try:
                    if any('scheduler_daemon' in str(cmd) for cmd in proc.info['cmdline'] or []):
                        daemon_found = True
                        daemon_info = {
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'create_time': datetime.fromtimestamp(proc.info['create_time']).isoformat(),
                            'uptime_seconds': time.time() - proc.info['create_time']
                        }
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            result.details = {
                'daemon_found': daemon_found,
                'daemon_info': daemon_info
            }
            
            assert daemon_found, "Демон планировщика не найден среди процессов"
            assert daemon_info['uptime_seconds'] > 0, "Время работы демона некорректно"
            
        except Exception as e:
            # Если не можем найти через процессы, проверяем через файл состояния
            state_file = Path(__file__).parent.parent / "data" / "daemon.state"
            if state_file.exists():
                result.details['daemon_status'] = "Файл состояния найден"
            else:
                raise AssertionError(f"Демон не активен: {e}")
    
    def test_02_api_auth_headers(self, result: TestResult):
        """2.1.3 - Проверка авторизации HH"""
        auth_config_path = Path(__file__).parent.parent / "config" / "auth_roles.json"
        
        if not auth_config_path.exists():
            result.details['auth_status'] = "Файл auth_roles.json не найден - авторизация отключена"
            return
        
        try:
            with open(auth_config_path, 'r', encoding='utf-8') as f:
                auth_config = json.load(f)
            
            profiles = auth_config.get('profiles', [])
            enabled_profiles = [p for p in profiles if p.get('enabled', False)]
            
            result.details = {
                'total_profiles': len(profiles),
                'enabled_profiles': len(enabled_profiles),
                'auth_percentage': (len(enabled_profiles) / max(len(profiles), 1)) * 100
            }
            
            assert len(enabled_profiles) > 0, "Нет активных профилей авторизации"
            
        except Exception as e:
            result.details['error'] = f"Ошибка проверки авторизации: {e}"
            # Не провалываем тест если авторизация не настроена
    
    def test_dispatcher_start_command(self, result: TestResult):
        """2.4.1 - Проверка запуска диспетчера"""
        try:
            # Проверяем что TaskDispatcher может быть инициализирован
            dispatcher = TaskDispatcher(self.config.get('task_dispatcher', {}))
            result.details = {
                'dispatcher_created': True,
                'max_workers': dispatcher.max_workers,
                'queue_maxsize': getattr(dispatcher, 'queue_maxsize', 'unlimited')
            }
            
            # Проверяем базовые методы диспетчера
            assert hasattr(dispatcher, 'add_task'), "Метод add_task не найден"
            assert hasattr(dispatcher, 'get_progress'), "Метод get_progress не найден"
            
        except Exception as e:
            raise AssertionError(f"Ошибка инициализации диспетчера: {e}")
    
    def test_web_interface_command(self, result: TestResult):
        """2.4.2 - Проверка веб-интерфейса"""
        web_config = self.config.get('web_interface', {})
        port = web_config.get('port', 8000)
        
        try:
            # Проверяем доступность веб-интерфейса
            response = requests.get(f"http://localhost:{port}/api/version", timeout=5)
            
            result.details = {
                'port': port,
                'status_code': response.status_code,
                'response_time': response.elapsed.total_seconds(),
                'api_reachable': response.status_code == 200
            }
            
            assert response.status_code == 200, f"Веб-интерфейс недоступен (статус {response.status_code})"
            
        except requests.exceptions.ConnectionError:
            result.details = {
                'port': port,
                'error': 'Connection refused - веб-сервер не запущен'
            }
            # Не провалываем тест если веб-интерфейс намеренно выключен
            if web_config.get('enabled', True):
                raise AssertionError("Веб-интерфейс должен быть доступен согласно конфигурации")
    
    def test_database_health_check(self, result: TestResult):
        """2.10.1 - Проверка здоровья базы данных"""
        db_config = self.config.get('database', {})
        db_path = Path(__file__).parent.parent / db_config.get('path', 'data/hh_v4.sqlite3')
        
        try:
            # Создаем БД если не существует
            db_path.parent.mkdir(exist_ok=True)
            
            with sqlite3.connect(str(db_path), timeout=30) as conn:
                cursor = conn.cursor()
                
                # Проверяем базовые операции
                cursor.execute("SELECT sqlite_version()")
                sqlite_version = cursor.fetchone()[0]
                
                # Проверяем размер БД
                db_size = db_path.stat().st_size if db_path.exists() else 0
                
                # Проверяем количество таблиц
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                table_count = cursor.fetchone()[0]
                
                result.details = {
                    'sqlite_version': sqlite_version,
                    'db_size_bytes': db_size,
                    'table_count': table_count,
                    'db_path': str(db_path),
                    'wal_mode': db_config.get('wal_mode', False)
                }
                
                assert db_size >= 0, "Размер БД некорректен"
                assert table_count >= 0, "Количество таблиц некорректно"
                
        except Exception as e:
            raise AssertionError(f"Ошибка проверки БД: {e}")
    
    def test_config_file_loading(self, result: TestResult):
        """2.6.4 - Загрузка конфигурации"""
        config_path = Path(__file__).parent.parent / "config" / "config_v4.json"
        
        try:
            assert config_path.exists(), f"Файл конфигурации не найден: {config_path}"
            
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # Проверяем обязательные секции
            required_sections = ['database', 'task_dispatcher', 'logging', 'api']
            missing_sections = [s for s in required_sections if s not in config]
            
            result.details = {
                'config_sections': list(config.keys()),
                'required_sections': required_sections,
                'missing_sections': missing_sections,
                'config_valid': len(missing_sections) == 0
            }
            
            assert len(missing_sections) == 0, f"Отсутствуют обязательные секции: {missing_sections}"
            
        except json.JSONDecodeError as e:
            raise AssertionError(f"Некорректный JSON в конфигурации: {e}")
    
    def test_search_finds_new_vacancies(self, result: TestResult):
        """2.11.1 + 2.11.3 - Поиск и сбор ID вакансий"""
        try:
            # Инициализируем загрузчик
            fetcher_config = self.config.get('vacancy_fetcher', {})
            fetcher = VacancyFetcher(fetcher_config)
            
            # Простой тестовый запрос
            test_params = {
                'text': 'python',
                'area': '1',  # Москва
                'per_page': '1',
                'page': '0'
            }
            
            # Формируем URL запроса
            base_url = self.config.get('api', {}).get('base_url', 'https://api.hh.ru')
            url = f"{base_url}/vacancies"
            
            response = requests.get(url, params=test_params, timeout=10)
            
            result.details = {
                'api_url': url,
                'test_params': test_params,
                'status_code': response.status_code,
                'response_time': response.elapsed.total_seconds()
            }
            
            if response.status_code == 200:
                data = response.json()
                result.details.update({
                    'found_vacancies': data.get('found', 0),
                    'pages': data.get('pages', 0),
                    'items_count': len(data.get('items', []))
                })
                
                assert data.get('found', 0) > 0, "API не возвращает вакансии"
                
            elif response.status_code == 400:
                result.details['error'] = "Ошибка 400 - проблема с User-Agent или параметрами"
                raise AssertionError("API возвращает ошибку 400")
            else:
                raise AssertionError(f"API недоступен (статус {response.status_code})")
                
        except requests.exceptions.RequestException as e:
            raise AssertionError(f"Ошибка сетевого запроса: {e}")


class Priority2Tests(ConsolidatedTestSuite):
    """Важные тесты приоритета 2 - могут иметь известные ограничения"""
    
    def test_cleanup_command(self, result: TestResult):
        """2.2.1-2.2.2 + 2.2.4 - Тесты очистки"""
        cleanup_config = self.config.get('cleanup', {})
        
        result.details = {
            'auto_cleanup_enabled': cleanup_config.get('auto_cleanup_enabled', False),
            'keep_logs_days': cleanup_config.get('keep_logs_days', 30),
            'keep_tasks_days': cleanup_config.get('keep_tasks_days', 7)
        }
        
        # Проверяем что настройки очистки разумные
        assert cleanup_config.get('keep_logs_days', 30) > 0, "Период хранения логов должен быть больше 0"
        assert cleanup_config.get('keep_tasks_days', 7) > 0, "Период хранения задач должен быть больше 0"
    
    def test_critical_event_logging(self, result: TestResult):
        """2.3.1 - Централизованное логирование"""
        logging_config = self.config.get('logging', {})
        log_file = Path(__file__).parent.parent / logging_config.get('file_path', 'logs/app.log')
        
        result.details = {
            'log_file': str(log_file),
            'log_exists': log_file.exists(),
            'log_config': logging_config
        }
        
        # Создаем папку логов если не существует
        log_file.parent.mkdir(exist_ok=True)
        
        if log_file.exists():
            stat = log_file.stat()
            result.details.update({
                'log_size_bytes': stat.st_size,
                'log_modified': datetime.fromtimestamp(stat.st_mtime).isoformat()
            })
            
            # Проверяем что лог не слишком старый (менее суток)
            age_hours = (time.time() - stat.st_mtime) / 3600
            result.details['log_age_hours'] = age_hours
            
            if age_hours > 24:
                result.details['warning'] = f"Лог не обновлялся {age_hours:.1f} часов"
    
    def test_telegram_critical_alerts(self, result: TestResult):
        """2.6.2 - Настройки Telegram"""
        telegram_config = self.config.get('telegram', {})
        
        result.details = {
            'telegram_enabled': telegram_config.get('enabled', False),
            'has_token': bool(telegram_config.get('token', '').strip()),
            'has_chat_id': bool(telegram_config.get('chat_id', '').strip()),
            'alerts_enabled': telegram_config.get('alerts_enabled', False)
        }
        
        if telegram_config.get('enabled', False):
            # Если Telegram включен, проверяем наличие обязательных параметров
            assert telegram_config.get('token', '').strip(), "Токен Telegram не настроен"
            assert telegram_config.get('chat_id', '').strip(), "Chat ID Telegram не настроен"
        else:
            result.details['note'] = "Telegram интеграция отключена в конфигурации"


class TestRunner:
    """Основной класс для запуска всех тестов"""
    
    def __init__(self, priorities: List[int] = None):
        self.priorities = priorities or [1, 2]
        self.results: List[TestResult] = []
        
    def run_all_tests(self) -> Dict[str, Any]:
        """Запуск всех тестов с красивым выводом"""
        print("=" * 65)
        print("           HH v4 CONSOLIDATED TEST RESULTS")
        print("=" * 65)
        print(f"Запуск: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Приоритеты: {', '.join(map(str, self.priorities))}")
        print()
        
        total_start_time = time.time()
        
        # Запуск тестов приоритета 1
        if 1 in self.priorities:
            print("🔴 ПРИОРИТЕТ 1 ТЕСТЫ (Критические)")
            print("-" * 45)
            self._run_priority_tests(Priority1Tests(), 1)
        
        # Запуск тестов приоритета 2  
        if 2 in self.priorities:
            print("\n🟡 ПРИОРИТЕТ 2 ТЕСТЫ (Важные)")
            print("-" * 35)
            self._run_priority_tests(Priority2Tests(), 2)
        
        total_time = time.time() - total_start_time
        
        # Итоговая статистика
        return self._print_final_results(total_time)
    
    def _run_priority_tests(self, test_class: ConsolidatedTestSuite, priority: int):
        """Запуск тестов определенного приоритета"""
        test_methods = [m for m in dir(test_class) if m.startswith('test_')]
        
        for method_name in test_methods:
            test_func = getattr(test_class, method_name)
            test_name = test_func.__doc__.split('\n')[0].strip() if test_func.__doc__ else method_name
            
            print(f"  • {test_name[:60]}...", end=" ", flush=True)
            
            result = test_class._execute_test(test_func, method_name, test_name, priority)
            self.results.append(result)
            
            if result.passed:
                print(f"✅ ({result.execution_time:.2f}s)")
            else:
                print(f"❌ ({result.execution_time:.2f}s)")
                print(f"    Ошибка: {result.error_message}")
    
    def _print_final_results(self, total_time: float) -> Dict[str, Any]:
        """Печать итоговых результатов"""
        print("\n" + "=" * 65)
        print("                    ИТОГОВЫЕ РЕЗУЛЬТАТЫ")
        print("=" * 65)
        
        # Группировка по приоритетам
        priority_stats = {}
        for priority in self.priorities:
            priority_results = [r for r in self.results if r.priority == priority]
            passed = len([r for r in priority_results if r.passed])
            total = len(priority_results)
            percentage = (passed / total * 100) if total > 0 else 0
            
            priority_stats[priority] = {
                'passed': passed,
                'total': total,
                'percentage': percentage
            }
            
            status_icon = "✅" if percentage == 100 else "⚠️" if percentage >= 80 else "❌"
            print(f"Приоритет {priority}: {passed}/{total} ({percentage:.1f}%) {status_icon}")
        
        # Общая статистика
        total_passed = sum(r.passed for r in self.results)
        total_tests = len(self.results)
        overall_percentage = (total_passed / total_tests * 100) if total_tests > 0 else 0
        
        print("-" * 65)
        print(f"ОБЩИЙ ИТОГ: {total_passed}/{total_tests} ({overall_percentage:.1f}%)")
        print(f"Время выполнения: {total_time:.2f} секунд")
        
        # Список проблемных тестов
        failed_tests = [r for r in self.results if not r.passed]
        if failed_tests:
            print("\n🔍 ПРОБЛЕМНЫЕ ТЕСТЫ:")
            for test in failed_tests:
                print(f"  ❌ {test.name}")
                print(f"     {test.error_message}")
        
        print("=" * 65)
        
        # Возвращаем структурированные результаты
        return {
            'timestamp': datetime.now().isoformat(),
            'total_tests': total_tests,
            'passed_tests': total_passed,
            'overall_percentage': overall_percentage,
            'execution_time': total_time,
            'priority_stats': priority_stats,
            'failed_tests': [{'name': t.name, 'error': t.error_message} for t in failed_tests],
            'detailed_results': [
                {
                    'test_id': r.test_id,
                    'name': r.name,
                    'priority': r.priority,
                    'passed': r.passed,
                    'execution_time': r.execution_time,
                    'error_message': r.error_message,
                    'details': r.details
                }
                for r in self.results
            ]
        }


def main():
    """Главная функция для CLI запуска"""
    import argparse
    
    parser = argparse.ArgumentParser(description='HH v4 Consolidated Test Suite')
    parser.add_argument('--priority', type=str, default='1,2', 
                       help='Приоритеты тестов через запятую (по умолчанию: 1,2)')
    parser.add_argument('--output', type=str, 
                       help='Файл для сохранения JSON результатов')
    
    args = parser.parse_args()
    
    # Парсинг приоритетов
    try:
        priorities = [int(p.strip()) for p in args.priority.split(',')]
    except ValueError:
        print("❌ Некорректный формат приоритетов. Используйте: --priority 1,2")
        return 1
    
    # Запуск тестов
    runner = TestRunner(priorities)
    results = runner.run_all_tests()
    
    # Сохранение результатов в файл
    if args.output:
        try:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"\n📝 Результаты сохранены в {args.output}")
        except Exception as e:
            print(f"⚠️  Ошибка сохранения результатов: {e}")
    
    # Возвращаем код выхода
    return 0 if results['overall_percentage'] >= 80 else 1


if __name__ == '__main__':
    sys.exit(main())
