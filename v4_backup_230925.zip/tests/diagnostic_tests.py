#!/usr/bin/env python3
"""
HH v4 DIAGNOSTIC TEST SUITE
Специализированные тесты самодиагностики и мониторинга системы

Автор: AI Assistant
Дата: 23.09.2025
Соответствует требованиям: 2.1.* (самодиагностика)
"""

import sys
import os
import time
import json
import psutil
import sqlite3
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

# Добавляем корневую папку проекта в путь для импортов
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class DiagnosticResult:
    """Результат диагностического теста"""
    def __init__(self, test_name: str, category: str):
        self.test_name = test_name
        self.category = category
        self.status = "UNKNOWN"  # OK, WARNING, CRITICAL, ERROR
        self.message = ""
        self.details = {}
        self.metrics = {}
        self.timestamp = datetime.now()


class SystemDiagnostic:
    """Основной класс системной диагностики"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or str(Path(__file__).parent.parent / "config" / "config_v4.json")
        self.config = self._load_config()
        self.results: List[DiagnosticResult] = []
        
    def _load_config(self) -> Dict:
        """Загрузка конфигурации"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  Конфигурация недоступна: {e}")
            return {}
    
    def run_full_diagnostic(self) -> Dict[str, Any]:
        """Полная диагностика системы"""
        print("🔍 СИСТЕМНАЯ ДИАГНОСТИКА HH v4")
        print("=" * 50)
        print(f"Время: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        start_time = time.time()
        
        # Запуск всех категорий диагностики
        self._diagnose_system_resources()
        self._diagnose_daemon_status()
        self._diagnose_database_health()
        self._diagnose_log_health()
        self._diagnose_network_connectivity()
        self._diagnose_storage_usage()
        
        execution_time = time.time() - start_time
        return self._generate_report(execution_time)
    
    def _diagnose_system_resources(self):
        """Диагностика системных ресурсов"""
        print("📊 Системные ресурсы...")
        
        monitoring_config = self.config.get('system_monitoring', {})
        
        # CPU диагностика
        cpu_result = DiagnosticResult("CPU Usage", "system_resources")
        try:
            cpu_percent = psutil.cpu_percent(interval=2)  # 2 секунды для точности
            cpu_count = psutil.cpu_count()
            cpu_freq = psutil.cpu_freq()
            
            cpu_threshold = monitoring_config.get('cpu_threshold_percent', 80)
            cpu_critical = monitoring_config.get('cpu_critical_percent', 95)
            
            cpu_result.metrics = {
                'cpu_percent': cpu_percent,
                'cpu_count': cpu_count,
                'cpu_freq_current': cpu_freq.current if cpu_freq else None,
                'cpu_freq_max': cpu_freq.max if cpu_freq else None
            }
            
            if cpu_percent >= cpu_critical:
                cpu_result.status = "CRITICAL"
                cpu_result.message = f"CPU загружен на {cpu_percent:.1f}% (критический уровень)"
            elif cpu_percent >= cpu_threshold:
                cpu_result.status = "WARNING"
                cpu_result.message = f"CPU загружен на {cpu_percent:.1f}% (превышен порог)"
            else:
                cpu_result.status = "OK"
                cpu_result.message = f"CPU загружен на {cpu_percent:.1f}% (норма)"
                
        except Exception as e:
            cpu_result.status = "ERROR"
            cpu_result.message = f"Ошибка мониторинга CPU: {e}"
        
        self.results.append(cpu_result)
        
        # Memory диагностика
        memory_result = DiagnosticResult("Memory Usage", "system_resources")
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            memory_threshold = monitoring_config.get('memory_threshold_percent', 85)
            memory_critical = monitoring_config.get('memory_critical_percent', 95)
            
            memory_result.metrics = {
                'memory_percent': memory.percent,
                'memory_total_gb': memory.total / (1024**3),
                'memory_available_gb': memory.available / (1024**3),
                'swap_percent': swap.percent,
                'swap_total_gb': swap.total / (1024**3)
            }
            
            if memory.percent >= memory_critical:
                memory_result.status = "CRITICAL"
                memory_result.message = f"Память использована на {memory.percent:.1f}% (критический уровень)"
            elif memory.percent >= memory_threshold:
                memory_result.status = "WARNING"
                memory_result.message = f"Память использована на {memory.percent:.1f}% (превышен порог)"
            else:
                memory_result.status = "OK"
                memory_result.message = f"Память использована на {memory.percent:.1f}% (норма)"
                
        except Exception as e:
            memory_result.status = "ERROR"
            memory_result.message = f"Ошибка мониторинга памяти: {e}"
        
        self.results.append(memory_result)
        
        # Disk диагностика
        disk_result = DiagnosticResult("Disk Usage", "system_resources")
        try:
            # Получаем диск с проектом
            project_path = Path(__file__).parent.parent
            disk = psutil.disk_usage(str(project_path))
            
            disk_threshold = monitoring_config.get('disk_threshold_percent', 85)
            disk_critical = monitoring_config.get('disk_critical_percent', 95)
            
            disk_percent = (disk.used / disk.total) * 100
            
            disk_result.metrics = {
                'disk_percent': disk_percent,
                'disk_total_gb': disk.total / (1024**3),
                'disk_free_gb': disk.free / (1024**3),
                'disk_used_gb': disk.used / (1024**3)
            }
            
            if disk_percent >= disk_critical:
                disk_result.status = "CRITICAL"
                disk_result.message = f"Диск заполнен на {disk_percent:.1f}% (критический уровень)"
            elif disk_percent >= disk_threshold:
                disk_result.status = "WARNING"
                disk_result.message = f"Диск заполнен на {disk_percent:.1f}% (превышен порог)"
            else:
                disk_result.status = "OK"
                disk_result.message = f"Диск заполнен на {disk_percent:.1f}% (норма)"
                
        except Exception as e:
            disk_result.status = "ERROR"
            disk_result.message = f"Ошибка мониторинга диска: {e}"
        
        self.results.append(disk_result)
    
    def _diagnose_daemon_status(self):
        """Диагностика статуса демона"""
        print("🤖 Статус демона...")
        
        daemon_result = DiagnosticResult("Daemon Status", "daemon")
        
        try:
            # Поиск процесса демона
            daemon_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time', 'memory_info']):
                try:
                    cmdline = proc.info['cmdline'] or []
                    if any('scheduler_daemon' in str(cmd) or 'daemon' in str(cmd) for cmd in cmdline):
                        daemon_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'cmdline': ' '.join(cmdline),
                            'create_time': proc.info['create_time'],
                            'memory_mb': proc.info['memory_info'].rss / (1024*1024)
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            daemon_result.metrics = {
                'daemon_processes_count': len(daemon_processes),
                'daemon_processes': daemon_processes
            }
            
            if len(daemon_processes) == 0:
                daemon_result.status = "WARNING"
                daemon_result.message = "Демон планировщика не обнаружен в процессах"
                
                # Проверяем файл состояния как альтернативу
                state_file = Path(__file__).parent.parent / "data" / "daemon.state"
                if state_file.exists():
                    daemon_result.message += " (найден файл состояния)"
                    daemon_result.status = "OK"
                    
            elif len(daemon_processes) == 1:
                daemon_info = daemon_processes[0]
                uptime_hours = (time.time() - daemon_info['create_time']) / 3600
                daemon_result.status = "OK"
                daemon_result.message = f"Демон активен (PID: {daemon_info['pid']}, работает {uptime_hours:.1f}ч)"
                daemon_result.details = {
                    'uptime_hours': uptime_hours,
                    'memory_usage_mb': daemon_info['memory_mb']
                }
            else:
                daemon_result.status = "WARNING"
                daemon_result.message = f"Обнаружено {len(daemon_processes)} процессов демона (возможно дублирование)"
                
        except Exception as e:
            daemon_result.status = "ERROR"
            daemon_result.message = f"Ошибка проверки демона: {e}"
        
        self.results.append(daemon_result)
    
    def _diagnose_database_health(self):
        """Диагностика состояния базы данных"""
        print("🗄️  База данных...")
        
        db_result = DiagnosticResult("Database Health", "database")
        
        try:
            db_config = self.config.get('database', {})
            db_path = Path(__file__).parent.parent / db_config.get('path', 'data/hh_v4.sqlite3')
            
            if not db_path.exists():
                db_result.status = "WARNING"
                db_result.message = "База данных не найдена (будет создана при первом запуске)"
                self.results.append(db_result)
                return
            
            # Подключение и проверка БД
            with sqlite3.connect(str(db_path), timeout=10) as conn:
                cursor = conn.cursor()
                
                # Основная информация
                cursor.execute("SELECT sqlite_version()")
                sqlite_version = cursor.fetchone()[0]
                
                cursor.execute("PRAGMA integrity_check")
                integrity = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                table_count = cursor.fetchone()[0]
                
                # Размер БД
                db_size_mb = db_path.stat().st_size / (1024*1024)
                
                # Статистика вакансий (если таблица существует)
                vacancy_stats = {}
                try:
                    cursor.execute("SELECT COUNT(*) FROM vacancies")
                    vacancy_stats['total_vacancies'] = cursor.fetchone()[0]
                    
                    cursor.execute("SELECT COUNT(DISTINCT employer_id) FROM vacancies WHERE employer_id IS NOT NULL")
                    vacancy_stats['unique_employers'] = cursor.fetchone()[0]
                    
                except sqlite3.OperationalError:
                    vacancy_stats['note'] = "Таблица vacancies не найдена"
                
                db_result.metrics = {
                    'sqlite_version': sqlite_version,
                    'integrity_check': integrity,
                    'table_count': table_count,
                    'db_size_mb': db_size_mb,
                    'vacancy_stats': vacancy_stats
                }
                
                if integrity == "ok" and table_count > 0:
                    db_result.status = "OK"
                    db_result.message = f"БД исправна ({table_count} таблиц, {db_size_mb:.1f} МБ)"
                elif integrity == "ok":
                    db_result.status = "WARNING"
                    db_result.message = "БД исправна, но таблицы отсутствуют"
                else:
                    db_result.status = "CRITICAL"
                    db_result.message = f"Обнаружены проблемы целостности БД: {integrity}"
                    
        except Exception as e:
            db_result.status = "ERROR"
            db_result.message = f"Ошибка проверки БД: {e}"
        
        self.results.append(db_result)
    
    def _diagnose_log_health(self):
        """Диагностика состояния логов"""
        print("📝 Система логирования...")
        
        log_result = DiagnosticResult("Log Health", "logging")
        
        try:
            logging_config = self.config.get('logging', {})
            log_path = Path(__file__).parent.parent / logging_config.get('file_path', 'logs/app.log')
            
            if not log_path.exists():
                log_result.status = "WARNING"
                log_result.message = "Основной файл логов не найден"
                self.results.append(log_result)
                return
            
            # Анализ лог-файла
            stat = log_path.stat()
            log_size_mb = stat.st_size / (1024*1024)
            log_age_hours = (time.time() - stat.st_mtime) / 3600
            
            # Подсчет записей и ошибок
            error_count = 0
            warning_count = 0
            total_lines = 0
            recent_errors = []
            
            try:
                with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    total_lines = len(lines)
                    
                    # Анализируем последние 1000 строк
                    for line in lines[-1000:]:
                        if 'ERROR' in line or 'CRITICAL' in line:
                            error_count += 1
                            if len(recent_errors) < 5:  # Сохраняем первые 5 ошибок
                                recent_errors.append(line.strip())
                        elif 'WARNING' in line:
                            warning_count += 1
                            
            except Exception as e:
                log_result.details['read_error'] = str(e)
            
            log_result.metrics = {
                'log_size_mb': log_size_mb,
                'log_age_hours': log_age_hours,
                'total_lines': total_lines,
                'error_count': error_count,
                'warning_count': warning_count,
                'recent_errors': recent_errors
            }
            
            max_size_mb = logging_config.get('max_size_mb', 100)
            
            if error_count > 10:
                log_result.status = "CRITICAL"
                log_result.message = f"Много ошибок в логах ({error_count} ошибок в последних записях)"
            elif log_size_mb > max_size_mb:
                log_result.status = "WARNING"
                log_result.message = f"Лог-файл превышает лимит ({log_size_mb:.1f} МБ > {max_size_mb} МБ)"
            elif log_age_hours > 24:
                log_result.status = "WARNING"
                log_result.message = f"Лог не обновлялся {log_age_hours:.1f} часов"
            else:
                log_result.status = "OK"
                log_result.message = f"Логирование работает нормально ({total_lines} записей, {log_size_mb:.1f} МБ)"
                
        except Exception as e:
            log_result.status = "ERROR"
            log_result.message = f"Ошибка анализа логов: {e}"
        
        self.results.append(log_result)
    
    def _diagnose_network_connectivity(self):
        """Диагностика сетевого соединения"""
        print("🌐 Сетевое соединение...")
        
        network_result = DiagnosticResult("Network Connectivity", "network")
        
        monitoring_config = self.config.get('system_monitoring', {})
        test_hosts = monitoring_config.get('network_test_hosts', ['8.8.8.8', 'api.hh.ru'])
        
        connectivity_results = {}
        
        for host in test_hosts:
            try:
                if os.name == 'nt':  # Windows
                    result = subprocess.run(['ping', '-n', '1', host], 
                                          capture_output=True, text=True, timeout=10)
                else:  # Linux/Mac
                    result = subprocess.run(['ping', '-c', '1', host], 
                                          capture_output=True, text=True, timeout=10)
                
                connectivity_results[host] = {
                    'reachable': result.returncode == 0,
                    'response_time': self._extract_ping_time(result.stdout) if result.returncode == 0 else None
                }
                
            except subprocess.TimeoutExpired:
                connectivity_results[host] = {'reachable': False, 'error': 'timeout'}
            except Exception as e:
                connectivity_results[host] = {'reachable': False, 'error': str(e)}
        
        network_result.metrics = connectivity_results
        
        reachable_hosts = sum(1 for r in connectivity_results.values() if r.get('reachable', False))
        total_hosts = len(test_hosts)
        
        if reachable_hosts == total_hosts:
            network_result.status = "OK"
            network_result.message = f"Все тестовые хосты доступны ({reachable_hosts}/{total_hosts})"
        elif reachable_hosts > 0:
            network_result.status = "WARNING"
            network_result.message = f"Частичные проблемы с сетью ({reachable_hosts}/{total_hosts} хостов доступны)"
        else:
            network_result.status = "CRITICAL"
            network_result.message = "Сетевое соединение недоступно"
        
        self.results.append(network_result)
    
    def _diagnose_storage_usage(self):
        """Диагностика использования дискового пространства проектом"""
        print("💾 Использование хранилища...")
        
        storage_result = DiagnosticResult("Storage Usage", "storage")
        
        try:
            project_path = Path(__file__).parent.parent
            
            # Анализ размеров директорий
            dir_sizes = {}
            total_size = 0
            
            for item in ['data', 'logs', 'docs', 'reports']:
                item_path = project_path / item
                if item_path.exists():
                    size = sum(f.stat().st_size for f in item_path.rglob('*') if f.is_file())
                    dir_sizes[item] = size / (1024*1024)  # В мегабайтах
                    total_size += size
                else:
                    dir_sizes[item] = 0
            
            # Поиск крупных файлов
            large_files = []
            for file_path in project_path.rglob('*'):
                if file_path.is_file():
                    size_mb = file_path.stat().st_size / (1024*1024)
                    if size_mb > 10:  # Файлы больше 10 МБ
                        large_files.append({
                            'path': str(file_path.relative_to(project_path)),
                            'size_mb': size_mb
                        })
            
            # Сортируем по размеру
            large_files.sort(key=lambda x: x['size_mb'], reverse=True)
            
            storage_result.metrics = {
                'total_size_mb': total_size / (1024*1024),
                'directory_sizes_mb': dir_sizes,
                'large_files': large_files[:10]  # Топ 10 крупных файлов
            }
            
            total_size_mb = total_size / (1024*1024)
            
            if total_size_mb > 1000:  # Больше 1 ГБ
                storage_result.status = "WARNING"
                storage_result.message = f"Проект занимает {total_size_mb:.1f} МБ (рекомендуется очистка)"
            elif total_size_mb > 500:  # Больше 500 МБ
                storage_result.status = "OK"
                storage_result.message = f"Проект занимает {total_size_mb:.1f} МБ (умеренное использование)"
            else:
                storage_result.status = "OK"
                storage_result.message = f"Проект занимает {total_size_mb:.1f} МБ (оптимально)"
                
        except Exception as e:
            storage_result.status = "ERROR"
            storage_result.message = f"Ошибка анализа хранилища: {e}"
        
        self.results.append(storage_result)
    
    def _extract_ping_time(self, ping_output: str) -> Optional[float]:
        """Извлечение времени отклика из вывода ping"""
        import re
        
        # Для Windows: time<1ms или time=XXms
        windows_pattern = r'time[<=](\d+(?:\.\d+)?)ms'
        # Для Linux/Mac: time=XX.X ms
        unix_pattern = r'time=(\d+(?:\.\d+)?)\s*ms'
        
        for pattern in [windows_pattern, unix_pattern]:
            match = re.search(pattern, ping_output)
            if match:
                return float(match.group(1))
        
        return None
    
    def _generate_report(self, execution_time: float) -> Dict[str, Any]:
        """Генерация итогового отчета"""
        print("\n" + "=" * 50)
        print("          ИТОГИ ДИАГНОСТИКИ")
        print("=" * 50)
        
        # Группировка по статусам
        status_counts = {'OK': 0, 'WARNING': 0, 'CRITICAL': 0, 'ERROR': 0}
        for result in self.results:
            status_counts[result.status] += 1
        
        # Печать результатов по категориям
        categories = {}
        for result in self.results:
            if result.category not in categories:
                categories[result.category] = []
            categories[result.category].append(result)
        
        for category, results in categories.items():
            print(f"\n📋 {category.upper().replace('_', ' ')}")
            print("-" * 30)
            for result in results:
                status_icon = {
                    'OK': '✅',
                    'WARNING': '⚠️',
                    'CRITICAL': '🔴',
                    'ERROR': '❌'
                }.get(result.status, '❓')
                
                print(f"  {status_icon} {result.test_name}: {result.message}")
        
        # Общая статистика
        total_tests = len(self.results)
        health_score = (status_counts['OK'] / total_tests * 100) if total_tests > 0 else 0
        
        print(f"\n📊 ОБЩАЯ СТАТИСТИКА:")
        print(f"   Всего проверок: {total_tests}")
        print(f"   ✅ OK: {status_counts['OK']}")
        print(f"   ⚠️  WARNING: {status_counts['WARNING']}")
        print(f"   🔴 CRITICAL: {status_counts['CRITICAL']}")
        print(f"   ❌ ERROR: {status_counts['ERROR']}")
        print(f"   🏥 Общее здоровье системы: {health_score:.1f}%")
        print(f"   ⏱️  Время диагностики: {execution_time:.2f} сек")
        
        # Рекомендации
        if status_counts['CRITICAL'] > 0:
            print(f"\n🚨 ТРЕБУЮТСЯ КРИТИЧЕСКИЕ ИСПРАВЛЕНИЯ!")
        elif status_counts['ERROR'] > 0:
            print(f"\n⚠️  Обнаружены ошибки системы")
        elif status_counts['WARNING'] > 0:
            print(f"\n💡 Есть рекомендации по улучшению")
        else:
            print(f"\n🎉 Система работает отлично!")
        
        print("=" * 50)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'execution_time': execution_time,
            'total_tests': total_tests,
            'status_counts': status_counts,
            'health_score': health_score,
            'results': [
                {
                    'test_name': r.test_name,
                    'category': r.category,
                    'status': r.status,
                    'message': r.message,
                    'timestamp': r.timestamp.isoformat(),
                    'metrics': r.metrics,
                    'details': r.details
                }
                for r in self.results
            ]
        }


def main():
    """Главная функция CLI"""
    import argparse
    
    parser = argparse.ArgumentParser(description='HH v4 System Diagnostic Suite')
    parser.add_argument('--config', type=str, help='Путь к файлу конфигурации')
    parser.add_argument('--output', type=str, help='Файл для сохранения JSON отчета')
    parser.add_argument('--category', type=str, 
                       help='Конкретная категория диагностики (system_resources, daemon, database, logging, network, storage)')
    
    args = parser.parse_args()
    
    try:
        diagnostic = SystemDiagnostic(args.config)
        
        if args.category:
            # Запуск конкретной категории (если потребуется в будущем)
            print(f"Запуск диагностики категории: {args.category}")
        
        report = diagnostic.run_full_diagnostic()
        
        # Сохранение отчета
        if args.output:
            try:
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(report, f, indent=2, ensure_ascii=False)
                print(f"\n📋 Отчет сохранен в {args.output}")
            except Exception as e:
                print(f"⚠️  Ошибка сохранения отчета: {e}")
        
        # Код возврата на основе результатов
        if report['status_counts']['CRITICAL'] > 0 or report['status_counts']['ERROR'] > 0:
            return 1
        elif report['status_counts']['WARNING'] > 0:
            return 2
        else:
            return 0
            
    except KeyboardInterrupt:
        print("\n⏹️  Диагностика прервана пользователем")
        return 130
    except Exception as e:
        print(f"❌ Критическая ошибка диагностики: {e}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
