#!/usr/bin/env python3
"""
Тесты для CLI v4
"""

import unittest
import tempfile
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

sys.path.insert(0, str(Path(__file__).parent.parent))

from cli_v4 import cli, dispatcher_start, load_vacancies, task_status, task_list, web_interface, cleanup

class TestCLIV4(unittest.TestCase):
    """Тесты для CLI интерфейса v4"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.runner = CliRunner()
        self.temp_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_cli_help(self):
        """Тест вывода справки CLI"""
        result = self.runner.invoke(cli, ['--help'])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('HH Tool v4 CLI', result.output)
        self.assertIn('dispatcher-start', result.output)
        self.assertIn('load-vacancies', result.output)
        self.assertIn('task-status', result.output)
    
    @patch('cli_v4.TaskDispatcher')
    def test_dispatcher_start_command(self, mock_dispatcher_class):
        """Тест команды dispatcher-start"""
        mock_dispatcher = MagicMock()
        mock_dispatcher.start.return_value = True
        mock_dispatcher.get_status.return_value = {
            'workers_count': 3,
            'queue_size': 0,
            'running': True
        }
        mock_dispatcher_class.return_value = mock_dispatcher
        
        result = self.runner.invoke(dispatcher_start, [
            '--workers', '3',
            '--chunk-size', '200'
        ])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Диспетчер запущен', result.output)
        
        # Проверяем что dispatcher был создан с правильными параметрами
        mock_dispatcher_class.assert_called_once_with(max_workers=3, chunk_size=200)
        mock_dispatcher.start.assert_called_once()
    
    @patch('cli_v4.TaskDispatcher')
    def test_load_vacancies_command(self, mock_dispatcher_class):
        """Тест команды load-vacancies"""
        mock_dispatcher = MagicMock()
        mock_dispatcher.add_task.return_value = 'task-123'
        mock_dispatcher_class.return_value = mock_dispatcher
        
        result = self.runner.invoke(load_vacancies, [
            '--filter-id', 'python-jobs',
            '--max-pages', '10'
        ])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Задача загрузки создана', result.output)
        self.assertIn('task-123', result.output)
        
        # Проверяем параметры задачи
        mock_dispatcher.add_task.assert_called_once()
        call_args = mock_dispatcher.add_task.call_args
        self.assertEqual(call_args[1]['task_type'], 'load_vacancies')
        self.assertEqual(call_args[1]['params']['filter_id'], 'python-jobs')
        self.assertEqual(call_args[1]['params']['max_pages'], 10)
    
    @patch('cli_v4.TaskDatabase')
    def test_task_status_command(self, mock_db_class):
        """Тест команды task-status"""
        mock_db = MagicMock()
        mock_task = {
            'id': 'task-456',
            'type': 'load_vacancies',
            'status': 'running',
            'created_at': 1694691000,
            'started_at': 1694691010,
            'progress_json': '{"current_page": 5, "total_pages": 20}'
        }
        mock_db.get_task.return_value = mock_task
        mock_db_class.return_value = mock_db
        
        result = self.runner.invoke(task_status, ['task-456'])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('task-456', result.output)
        self.assertIn('running', result.output)
        self.assertIn('load_vacancies', result.output)
    
    @patch('cli_v4.TaskDatabase')
    def test_task_status_not_found(self, mock_db_class):
        """Тест команды task-status для несуществующей задачи"""
        mock_db = MagicMock()
        mock_db.get_task.return_value = None
        mock_db_class.return_value = mock_db
        
        result = self.runner.invoke(task_status, ['non-existent'])
        
        self.assertEqual(result.exit_code, 1)
        self.assertIn('Задача не найдена', result.output)
    
    @patch('cli_v4.TaskDatabase')
    def test_task_list_command(self, mock_db_class):
        """Тест команды task-list"""
        mock_db = MagicMock()
        mock_tasks = [
            {
                'id': 'task-1',
                'type': 'load_vacancies',
                'status': 'completed',
                'created_at': 1694691000
            },
            {
                'id': 'task-2', 
                'type': 'cleanup',
                'status': 'running',
                'created_at': 1694691100
            }
        ]
        
        # Мокируем разные статусы
        def mock_get_tasks_by_status(status, limit):
            if status == 'all':
                return mock_tasks
            else:
                return [t for t in mock_tasks if t['status'] == status]
        
        mock_db.get_tasks_by_status = mock_get_tasks_by_status
        mock_db_class.return_value = mock_db
        
        # Тест получения всех задач
        result = self.runner.invoke(task_list, ['--status', 'all'])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('task-1', result.output)
        self.assertIn('task-2', result.output)
        self.assertIn('completed', result.output)
        self.assertIn('running', result.output)
    
    @patch('cli_v4.http.server.HTTPServer')
    @patch('cli_v4.TaskDatabase')
    def test_web_interface_command(self, mock_db_class, mock_server_class):
        """Тест команды web-interface"""
        mock_db = MagicMock()
        mock_db_class.return_value = mock_db
        
        mock_server = MagicMock()
        mock_server_class.return_value = mock_server
        
        # Используем отдельный ввод для прерывания сервера
        with patch('builtins.input', side_effect=KeyboardInterrupt):
            result = self.runner.invoke(web_interface, [
                '--port', '8080'
            ])
        
        # Команда должна завершиться нормально после KeyboardInterrupt
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Веб-интерфейс запущен', result.output)
    
    @patch('cli_v4.TaskDatabase')
    def test_cleanup_command(self, mock_db_class):
        """Тест команды cleanup"""
        mock_db = MagicMock()
        mock_db.cleanup_old_tasks.return_value = {
            'cleaned_count': 25,
            'cleaned_bytes': 1048576
        }
        mock_db_class.return_value = mock_db
        
        result = self.runner.invoke(cleanup, [
            '--days', '14'
        ])
        
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Удалено задач: 25', result.output)
        self.assertIn('Освобождено места: 1.0 МБ', result.output)
        
        # Проверяем что вызван cleanup с правильным параметром
        mock_db.cleanup_old_tasks.assert_called_once_with(days_to_keep=14)

class TestCLIValidation(unittest.TestCase):
    """Тесты валидации параметров CLI"""
    
    def setUp(self):
        self.runner = CliRunner()
    
    @patch('cli_v4.TaskDispatcher')
    def test_dispatcher_start_validation(self, mock_dispatcher_class):
        """Тест валидации параметров dispatcher-start"""
        mock_dispatcher = MagicMock()
        mock_dispatcher_class.return_value = mock_dispatcher
        
        # Тест с недопустимым количеством workers
        result = self.runner.invoke(dispatcher_start, [
            '--workers', '0'
        ])
        
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn('должно быть больше 0', result.output)
        
        # Тест с недопустимым chunk-size
        result = self.runner.invoke(dispatcher_start, [
            '--chunk-size', '0'
        ])
        
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn('должен быть больше 0', result.output)
    
    @patch('cli_v4.TaskDispatcher')
    def test_load_vacancies_validation(self, mock_dispatcher_class):
        """Тест валидации параметров load-vacancies"""
        mock_dispatcher = MagicMock()
        mock_dispatcher_class.return_value = mock_dispatcher
        
        # Тест с недопустимым max-pages
        result = self.runner.invoke(load_vacancies, [
            '--filter-id', 'test',
            '--max-pages', '-1'
        ])
        
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn('должно быть больше 0', result.output)

class TestCLIErrorHandling(unittest.TestCase):
    """Тесты обработки ошибок CLI"""
    
    def setUp(self):
        self.runner = CliRunner()
    
    @patch('cli_v4.TaskDispatcher')
    def test_dispatcher_start_error(self, mock_dispatcher_class):
        """Тест обработки ошибок при запуске диспетчера"""
        mock_dispatcher = MagicMock()
        mock_dispatcher.start.side_effect = Exception("Test error")
        mock_dispatcher_class.return_value = mock_dispatcher
        
        result = self.runner.invoke(dispatcher_start)
        
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn('Ошибка при запуске', result.output)
        self.assertIn('Test error', result.output)
    
    @patch('cli_v4.TaskDatabase')
    def test_database_connection_error(self, mock_db_class):
        """Тест обработки ошибок подключения к БД"""
        mock_db_class.side_effect = Exception("Database connection error")
        
        result = self.runner.invoke(task_list)
        
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn('Ошибка подключения к БД', result.output)

if __name__ == '__main__':
    unittest.main()
