#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Системный тест-раннер HH-бота v4
Обновленная версия functional_test_runner.py с полной ревизией

// Chg_SYSTEM_TEST_RUNNER_2009: Комплексное тестирование всех компонентов v4
"""

import sys
import os
import logging
import tempfile
import uuid
import sqlite3
import time
import json
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Any

# Добавляем путь к проекту
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Импорт компонентов для тестирования
try:
    from core.database_v3 import VacancyDatabase
    from core.task_dispatcher import TaskDispatcher
    from core.host2_client import create_host2_client
    from core.host3_client import create_host3_client
    from tests.test_versioning_system import MockVacancy
    from web.server import app
    import cli_v4
except ImportError as e:
    print(f"❌ Ошибка импорта: {e}")
    sys.exit(1)

class SystemTestRunner:
    """Комплексный системный тест-раннер"""
    
    def __init__(self):
        self.results = {
            'total_tests': 0,
            'passed': 0,
            'failed': 0,
            'errors': [],
            'details': {},
            'start_time': datetime.now(),
            'categories': {
                'core': {'passed': 0, 'failed': 0, 'total': 0},
                'integration': {'passed': 0, 'failed': 0, 'total': 0},
                'api': {'passed': 0, 'failed': 0, 'total': 0},
                'hosts': {'passed': 0, 'failed': 0, 'total': 0},
                'performance': {'passed': 0, 'failed': 0, 'total': 0}
            }
        }
        
        # Временные ресурсы для тестов
        self.temp_dbs = []
        
    def log_test_result(self, test_id: str, test_name: str, passed: bool, 
                       execution_time: float, category: str = 'core', 
                       error: str = None, details: Dict = None):
        """Логирование результата теста"""
        self.results['total_tests'] += 1
        
        if passed:
            self.results['passed'] += 1
            self.results['categories'][category]['passed'] += 1
            status = "✅ PASS"
            color = "\033[92m"  # Green
        else:
            self.results['failed'] += 1
            self.results['categories'][category]['failed'] += 1
            status = "❌ FAIL"
            color = "\033[91m"  # Red
            if error:
                self.results['errors'].append(f"{test_id}: {error}")
        
        self.results['categories'][category]['total'] += 1
        
        # Сохраняем детали теста
        self.results['details'][test_id] = {
            'name': test_name,
            'passed': passed,
            'time': execution_time,
            'category': category,
            'error': error,
            'details': details or {}
        }
        
        reset_color = "\033[0m"
        print(f"{color}{status}{reset_color} {test_id}: {test_name} ({execution_time:.4f}s)")
        
        if error and not passed:
            print(f"    💥 {error}")
    
    def create_temp_database(self) -> str:
        """Создание временной БД для тестов"""
        unique_id = uuid.uuid4().hex[:8]
        temp_path = os.path.join(tempfile.gettempdir(), f'test_sys_{unique_id}.sqlite3')
        self.temp_dbs.append(temp_path)
        return temp_path
    
    def cleanup_temp_resources(self):
        """Очистка временных ресурсов"""
        for db_path in self.temp_dbs:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
            except:
                pass  # Игнорируем ошибки очистки
    
    # ТЕСТЫ CORE КОМПОНЕНТОВ
    def test_database_creation(self):
        """CORE001: Создание базы данных"""
        start_time = time.time()
        try:
            temp_path = self.create_temp_database()
            db = VacancyDatabase(temp_path)
            
            # Проверяем таблицы
            with sqlite3.connect(temp_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
            
            expected_tables = ['vacancies', 'employers', 'vacancy_changes', 'employer_changes', 'tasks']
            missing_tables = [t for t in expected_tables if t not in tables]
            
            if missing_tables:
                raise Exception(f"Отсутствуют таблицы: {missing_tables}")
            
            self.log_test_result('CORE001', 'Database Creation', True, time.time() - start_time, 'core',
                               details={'tables_count': len(tables), 'tables': tables})
            
        except Exception as e:
            self.log_test_result('CORE001', 'Database Creation', False, time.time() - start_time, 'core', str(e))
    
    def test_vacancy_operations(self):
        """CORE002: Операции с вакансиями"""
        start_time = time.time()
        try:
            temp_path = self.create_temp_database()
            db = VacancyDatabase(temp_path)
            
            # Создаем тестовую вакансию
            vacancy = MockVacancy(
                hh_id='test_core_002',
                title='Test Developer',
                employer_name='Test Company',
                content_hash='test_hash_core_002'
            )
            
            # Сохраняем вакансию
            vacancy_id = db.save_vacancy(vacancy)
            
            if vacancy_id is None:
                raise Exception("Не удалось сохранить вакансию")
            
            # Проверяем что вакансия сохранилась
            with sqlite3.connect(temp_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM vacancies WHERE hh_id = ?", ('test_core_002',))
                count = cursor.fetchone()[0]
            
            if count != 1:
                raise Exception(f"Ожидалась 1 вакансия, найдено {count}")
            
            self.log_test_result('CORE002', 'Vacancy Operations', True, time.time() - start_time, 'core',
                               details={'vacancy_id': vacancy_id, 'hh_id': 'test_core_002'})
            
        except Exception as e:
            self.log_test_result('CORE002', 'Vacancy Operations', False, time.time() - start_time, 'core', str(e))
    
    def test_versioning_system(self):
        """CORE003: Система версионирования"""
        start_time = time.time()
        try:
            temp_path = self.create_temp_database()
            db = VacancyDatabase(temp_path)
            
            # Создаем две одинаковые вакансии (дубликат)
            v1 = MockVacancy(hh_id='dup_test', title='Dev', employer_name='TestCo', content_hash='same_hash')
            v2 = MockVacancy(hh_id='dup_test', title='Dev', employer_name='TestCo', content_hash='same_hash')
            
            db.stats.reset()
            id1 = db.save_vacancy(v1)
            id2 = db.save_vacancy(v2)
            
            # Проверяем обнаружение дубликата
            if id1 != id2:
                raise Exception(f"Дубликат не обнаружен: {id1} != {id2}")
            
            if db.stats.duplicates_found != 1:
                raise Exception(f"Ожидался 1 дубликат, найдено {db.stats.duplicates_found}")
                
            self.log_test_result('CORE003', 'Versioning System', True, time.time() - start_time, 'core',
                               details={'duplicates_found': db.stats.duplicates_found, 'new_vacancies': db.stats.new_vacancies})
            
        except Exception as e:
            self.log_test_result('CORE003', 'Versioning System', False, time.time() - start_time, 'core', str(e))
    
    # ТЕСТЫ ХОСТОВ
    def test_host2_client(self):
        """HOST001: PostgreSQL клиент (Host2)"""
        start_time = time.time()
        try:
            config = {'mock_mode': True}
            client = create_host2_client(config)
            
            # Тест подключения
            if not client.is_connected():
                raise Exception("Клиент не подключен")
            
            # Тест синхронизации
            result = client.sync_vacancy_data([1, 2, 3])
            if result['status'] != 'success':
                raise Exception(f"Синхронизация провалилась: {result}")
            
            # Тест health check
            health = client.health_check()
            if health['status'] != 'healthy':
                raise Exception(f"Health check провалился: {health}")
            
            self.log_test_result('HOST001', 'PostgreSQL Client', True, time.time() - start_time, 'hosts',
                               details={'mock_mode': True, 'synced_records': result['synced_count']})
            
        except Exception as e:
            self.log_test_result('HOST001', 'PostgreSQL Client', False, time.time() - start_time, 'hosts', str(e))
    
    def test_host3_client(self):
        """HOST002: LLM клиент (Host3)"""
        start_time = time.time()
        try:
            config = {'mock_mode': True}
            client = create_host3_client(config)
            
            # Тест доступности
            if not client.is_available():
                raise Exception("LLM сервис недоступен")
            
            # Тест анализа вакансии
            result = client.analyze_vacancy({'title': 'Python Developer', 'description': 'Great job'})
            if 'analysis' not in result:
                raise Exception(f"Анализ не выполнен: {result}")
            
            # Тест извлечения навыков
            skills = client.extract_skills("Python Django PostgreSQL")
            if 'technical_skills' not in skills:
                raise Exception(f"Навыки не извлечены: {skills}")
            
            self.log_test_result('HOST002', 'LLM Client', True, time.time() - start_time, 'hosts',
                               details={'mock_mode': True, 'skills_extracted': len(skills.get('technical_skills', []))})
            
        except Exception as e:
            self.log_test_result('HOST002', 'LLM Client', False, time.time() - start_time, 'hosts', str(e))
    
    def test_task_dispatcher(self):
        """INT001: Диспетчер задач"""
        start_time = time.time()
        try:
            config = {
                'hosts': {
                    'host2': {'enabled': False, 'mock_mode': True},
                    'host3': {'enabled': False, 'mock_mode': True}
                }
            }
            
            dispatcher = TaskDispatcher(config=config)
            
            # Тест получения статуса хостов
            host_status = dispatcher.get_host_status()
            if 'host1' not in host_status:
                raise Exception("Host1 не найден в статусе")
            
            if host_status['host1']['status'] != 'active':
                raise Exception(f"Host1 неактивен: {host_status['host1']}")
            
            self.log_test_result('INT001', 'Task Dispatcher', True, time.time() - start_time, 'integration',
                               details={'hosts_count': len(host_status)})
            
        except Exception as e:
            self.log_test_result('INT001', 'Task Dispatcher', False, time.time() - start_time, 'integration', str(e))
    
    # ТЕСТЫ API
    def test_cli_commands(self):
        """API001: CLI команды"""
        start_time = time.time()
        try:
            # Тест команды hosts
            import subprocess
            
            result = subprocess.run([
                sys.executable, 'cli_v4.py', 'hosts', '--help'
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"CLI команда провалилась: {result.stderr}")
            
            if 'Управление внешними хостами' not in result.stdout:
                raise Exception("Описание команды hosts не найдено")
            
            self.log_test_result('API001', 'CLI Commands', True, time.time() - start_time, 'api',
                               details={'command': 'hosts --help'})
            
        except Exception as e:
            self.log_test_result('API001', 'CLI Commands', False, time.time() - start_time, 'api', str(e))
    
    # ТЕСТЫ ПРОИЗВОДИТЕЛЬНОСТИ
    def test_database_performance(self):
        """PERF001: Производительность БД"""
        start_time = time.time()
        try:
            temp_path = self.create_temp_database()
            db = VacancyDatabase(temp_path)
            
            # Создаем множество тестовых вакансий
            batch_start = time.time()
            batch_size = 100
            
            for i in range(batch_size):
                vacancy = MockVacancy(
                    hh_id=f'perf_test_{i}',
                    title=f'Developer {i}',
                    employer_name=f'Company {i}',
                    content_hash=f'hash_{i}'
                )
                db.save_vacancy(vacancy)
            
            batch_time = time.time() - batch_start
            avg_time_per_vacancy = batch_time / batch_size
            
            # Проверяем производительность (должно быть < 0.1 сек на вакансию)
            if avg_time_per_vacancy > 0.1:
                raise Exception(f"Слишком медленно: {avg_time_per_vacancy:.4f}s на вакансию")
            
            self.log_test_result('PERF001', 'Database Performance', True, time.time() - start_time, 'performance',
                               details={'batch_size': batch_size, 'total_time': batch_time, 'avg_per_item': avg_time_per_vacancy})
            
        except Exception as e:
            self.log_test_result('PERF001', 'Database Performance', False, time.time() - start_time, 'performance', str(e))
    
    def run_all_tests(self):
        """Запуск всех системных тестов"""
        print("\n" + "="*80)
        print("=== СИСТЕМНОЕ ТЕСТИРОВАНИЕ HH-БОТА v4 ===")
        print("="*80)
        
        # // Chg_TEST_LOG_2109: логируем старт выполнения системных тестов
        try:
            root = logging.getLogger()
            if not root.handlers:
                os.makedirs('logs', exist_ok=True)
                fh = logging.FileHandler('logs/app.log', encoding='utf-8')
                fh.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
                root.addHandler(fh)
                root.setLevel(logging.INFO)
            logging.info("system_tests_start")
        except Exception:
            pass
        
        # Список всех тестов для выполнения
        test_methods = [
            # Core tests
            self.test_database_creation,
            self.test_vacancy_operations, 
            self.test_versioning_system,
            # Host tests
            self.test_host2_client,
            self.test_host3_client,
            # Integration tests
            self.test_task_dispatcher,
            # API tests
            self.test_cli_commands,
            # Performance tests
            self.test_database_performance
        ]
        
        print(f"Запуск {len(test_methods)} тестов...")
        print()
        
        # Выполняем тесты
        for test_func in test_methods:
            try:
                test_func()
            except Exception as e:
                test_id = test_func.__name__.upper().replace('TEST_', '')
                self.log_test_result(test_id, test_func.__doc__ or test_func.__name__, 
                                   False, 0, 'core', f"Критическая ошибка: {e}")
        
        # Очистка ресурсов
        self.cleanup_temp_resources()
        
        # Финальный отчет
        total_time = (datetime.now() - self.results['start_time']).total_seconds()
        success_rate = (self.results['passed'] / self.results['total_tests'] * 100) if self.results['total_tests'] > 0 else 0
        print(f"\nОбщее время выполнения: {total_time:.2f} секунд")
        print(f"Успешность: {success_rate:.1f}% ({self.results['passed']}/{self.results['total_tests']})")
        print(f"✅ Пройдено: {self.results['passed']}")
        print(f"❌ Провалено: {self.results['failed']}")
        
        # Статистика по категориям
        print(f"\nСтатистика по категориям:")
        for category, stats in self.results['categories'].items():
            if stats['total'] > 0:
                cat_success = (stats['passed'] / stats['total'] * 100)
                print(f"  {category.upper()}: {cat_success:.1f}% ({stats['passed']}/{stats['total']})")
        
        # Список ошибок
        if self.results['errors']:
            print(f"\nОшибки ({len(self.results['errors'])}):")
            for error in self.results['errors'][:10]:  # Показываем только первые 10
                print(f"  • {error}")
            if len(self.results['errors']) > 10:
                print(f"  ... и еще {len(self.results['errors']) - 10} ошибок")
        
        # Рекомендации
        print(f"\nРекомендации:")
        if success_rate >= 90:
            print("  Отличный результат! Система готова к продакшену.")
        elif success_rate >= 70:
            print("  Хороший результат, но есть проблемы для исправления.")
        elif success_rate >= 50:
            print("  Требуется серьезная доработка перед использованием.")
        else:
            print("  Критические проблемы! Система не готова к использованию.")
        
        print("\n" + "="*80)
        
        # // Chg_TEST_LOG_2109: логируем завершение системных тестов
        try:
            logging.info(f"system_tests_finish success_rate={success_rate:.1f} passed={self.results['passed']}/{self.results['total_tests']}")
        except Exception:
            pass
        
        # Сохраняем отчет в файл
        self.save_report_to_file()

    def print_final_report(self):
        """Печатает финальный отчет"""
        print("\n" + "="*80)
        print("=== ИТОГОВЫЙ ОТЧЕТ ТЕСТИРОВАНИЯ ===")
        print("="*80)
        print(f"⏰ Время запуска: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}")
        print()
        # // Chg_TEST_LOG_2109: логируем старт выполнения системных тестов
        try:
            root = logging.getLogger()
            if not root.handlers:
                os.makedirs('logs', exist_ok=True)
                fh = logging.FileHandler('logs/app.log', encoding='utf-8')
                fh.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
                root.addHandler(fh)
                root.setLevel(logging.INFO)
            logging.info('system_tests_start')
        except Exception:
            pass
        
        # Группы тестов
        test_groups = [
            ("🔧 CORE КОМПОНЕНТЫ", [
                self.test_database_creation,
                self.test_vacancy_operations,
                self.test_versioning_system,
            ]),
            ("🏠 ХОСТЫ", [
                self.test_host2_client,
                self.test_host3_client,
            ]),
            ("🔗 ИНТЕГРАЦИЯ", [
                self.test_task_dispatcher,
            ]),
            ("🌐 API", [
                self.test_cli_commands,
            ]),
            ("⚡ ПРОИЗВОДИТЕЛЬНОСТЬ", [
                self.test_database_performance,
            ])
        ]
        
        # Выполняем тесты по группам
        for group_name, tests in test_groups:
            print(f"\n{group_name}")
            print("-" * 60)
            
            for test_func in tests:
                try:
                    test_func()
                except Exception as e:
                    test_id = test_func.__name__.upper().replace('TEST_', '')
                    self.log_test_result(test_id, test_func.__doc__ or test_func.__name__, 
                                       False, 0, 'core', f"Критическая ошибка: {e}")
        
        # Очистка ресурсов
        self.cleanup_temp_resources()
        
        # Финальный отчет
        total_time = (datetime.now() - self.results['start_time']).total_seconds()
        success_rate = (self.results['passed'] / self.results['total_tests'] * 100) if self.results['total_tests'] > 0 else 0
        print(f"\nОбщее время выполнения: {total_time:.2f} секунд")
        print(f"Успешность: {success_rate:.1f}% ({self.results['passed']}/{self.results['total_tests']})")
        print(f"✅ Пройдено: {self.results['passed']}")
        print(f"❌ Провалено: {self.results['failed']}")
        
        # Статистика по категориям
        print(f"\n📋 Статистика по категориям:")
        for category, stats in self.results['categories'].items():
            if stats['total'] > 0:
                cat_success = (stats['passed'] / stats['total'] * 100)
                print(f"  {category.upper()}: {cat_success:.1f}% ({stats['passed']}/{stats['total']})")
        
        # Список ошибок
        if self.results['errors']:
            print(f"\n❌ Ошибки ({len(self.results['errors'])}):")
            for error in self.results['errors'][:10]:  # Показываем только первые 10
                print(f"  • {error}")
            if len(self.results['errors']) > 10:
                print(f"  ... и еще {len(self.results['errors']) - 10} ошибок")
        
        # Рекомендации
        print(f"\n💡 Рекомендации:")
        if success_rate >= 90:
            print("  🎉 Отличный результат! Система готова к продакшену.")
        elif success_rate >= 70:
            print("  👍 Хороший результат, но есть проблемы для исправления.")
        elif success_rate >= 50:
            print("  ⚠️  Требуется серьезная доработка перед использованием.")
        else:
            print("  🚨 Критические проблемы! Система не готова к использованию.")
        
        print("\n" + "="*80)
        
        # // Chg_TEST_LOG_2109: логируем завершение системных тестов
        try:
            logging.info(f"system_tests_finish success_rate={success_rate:.1f} passed={self.results['passed']}/{self.results['total_tests']}")
        except Exception:
            pass
        
        # Сохраняем отчет в файл
        self.save_report_to_file()
    
    def save_report_to_file(self):
        """Сохранение отчета в файл"""
        report_file = f"reports/system_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Создаем папку отчетов если не существует
        os.makedirs('reports', exist_ok=True)
        
        # Подготавливаем данные для сохранения
        report_data = {
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_tests': self.results['total_tests'],
                'passed': self.results['passed'],
                'failed': self.results['failed'],
                'success_rate': (self.results['passed'] / self.results['total_tests'] * 100) if self.results['total_tests'] > 0 else 0,
                'duration_seconds': (datetime.now() - self.results['start_time']).total_seconds()
            },
            'categories': self.results['categories'],
            'details': self.results['details'],
            'errors': self.results['errors']
        }
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            print(f"📁 Отчет сохранен: {report_file}")
        except Exception as e:
            print(f"⚠️  Не удалось сохранить отчет: {e}")


def main():
    """Основная функция"""
    runner = SystemTestRunner()
    
    try:
        runner.run_all_tests()
    except KeyboardInterrupt:
        print("\n\n⚠️  Тестирование прервано пользователем")
        runner.cleanup_temp_resources()
    except Exception as e:
        print(f"\n\nКритическая ошибка тестирования: {e}")
        runner.cleanup_temp_resources()


if __name__ == "__main__":
    main()
