"""
Тесты производительности Excel экспорта
Проверка соответствия цели: <50МБ на 1000 вакансий

Автор: AI Assistant (Senior Python Developer)  
Дата: 20.09.2025 08:15:00
"""

import pytest
import tempfile
import time
from pathlib import Path
from typing import Dict, Any
import sys

# Добавляем путь к модулям проекта
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.export import VacancyExporter, EXPORT_FORMATS
    from core.database_v3 import VacancyDatabase
except ImportError as e:
    pytest.skip(f"Модули недоступны: {e}", allow_module_level=True)


class TestExportPerformance:
    """Тесты производительности экспорта"""
    
    @pytest.fixture(scope="class")
    def test_db_path(self) -> str:
        """Путь к тестовой БД"""
        return "data/hh_v4.sqlite3"  # Используем реальную БД для тестов производительности
    
    @pytest.fixture(scope="class")
    def exporter(self, test_db_path: str) -> VacancyExporter:
        """Экспортер для тестов"""
        return VacancyExporter(test_db_path)
    
    def test_export_formats_available(self, exporter: VacancyExporter):
        """Проверка доступности форматов экспорта"""
        formats = exporter.get_export_formats()
        
        assert isinstance(formats, dict), "Форматы должны быть словарем"
        assert len(formats) >= 3, "Должно быть минимум 3 формата"
        
        # Проверяем обязательные форматы
        required_formats = ['brief', 'full', 'analytical']
        for fmt in required_formats:
            assert fmt in formats, f"Формат {fmt} отсутствует"
            assert 'name' in formats[fmt], f"У формата {fmt} нет имени"
            assert 'columns' in formats[fmt], f"У формата {fmt} нет колонок"
    
    def test_vacancy_count(self, exporter: VacancyExporter):
        """Проверка подсчета вакансий"""
        count = exporter.get_vacancy_count()
        
        assert isinstance(count, int), "Количество должно быть числом"
        assert count >= 0, "Количество не может быть отрицательным"
        
        print(f"📊 Вакансий в БД: {count}")
    
    @pytest.mark.parametrize("format_type", ['brief', 'full', 'analytical'])
    def test_small_export_performance(self, exporter: VacancyExporter, format_type: str):
        """
        Тест производительности для малых объемов данных (100 записей)
        
        КРИТЕРИИ:
        - Время экспорта < 10 секунд
        - Размер файла разумный для 100 записей  
        - Файл создается без ошибок
        """
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)
        
        try:
            start_time = time.time()
            
            # Экспорт с ограничением
            result = exporter.export_to_excel(
                output_path=tmp_path,
                format_type=format_type,
                limit=100
            )
            
            export_time = time.time() - start_time
            
            # Проверяем результат
            assert result['success'], f"Экспорт провалился: {result.get('errors', [])}"
            assert result['records_exported'] <= 100, "Экспортировано больше записей чем ожидалось"
            
            # Проверяем производительность
            assert export_time < 10, f"Экспорт занял {export_time:.2f}с (лимит: 10с)"
            assert result['file_size_mb'] < 10, f"Файл слишком большой: {result['file_size_mb']}МБ"
            
            print(f"✅ {format_type}: {result['records_exported']} записей, "
                  f"{result['file_size_mb']}МБ, {export_time:.2f}с")
            
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
    
    def test_medium_export_performance(self, exporter: VacancyExporter):
        """
        Тест производительности для средних объемов данных (500 записей)
        
        КРИТЕРИИ:
        - Время экспорта < 30 секунд
        - Размер файла < 25МБ
        """
        # Проверяем наличие достаточного количества данных
        total_count = exporter.get_vacancy_count()
        if total_count < 500:
            pytest.skip(f"Недостаточно данных для теста: {total_count} < 500")
        
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)
        
        try:
            start_time = time.time()
            
            result = exporter.export_to_excel(
                output_path=tmp_path,
                format_type='brief',  # Самый легкий формат
                limit=500
            )
            
            export_time = time.time() - start_time
            
            # Проверяем результат
            assert result['success'], f"Экспорт провалился: {result.get('errors', [])}"
            
            # Проверяем производительность
            assert export_time < 30, f"Экспорт занял {export_time:.2f}с (лимит: 30с)"
            assert result['file_size_mb'] < 25, f"Файл слишком большой: {result['file_size_mb']}МБ"
            
            print(f"📈 Средний тест: {result['records_exported']} записей, "
                  f"{result['file_size_mb']}МБ, {export_time:.2f}с")
            
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
    
    def test_large_export_performance_goal(self, exporter: VacancyExporter):
        """
        🎯 ОСНОВНОЙ ТЕСТ: проверка цели <50МБ на 1000 вакансий
        
        КРИТЕРИИ УСПЕХА:
        - Размер файла < 50МБ для 1000 записей
        - Время экспорта < 60 секунд
        - Экспорт завершается без ошибок
        """
        # Проверяем наличие достаточного количества данных
        total_count = exporter.get_vacancy_count()
        if total_count < 1000:
            pytest.skip(f"Недостаточно данных для основного теста: {total_count} < 1000")
        
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)
        
        try:
            print(f"\n🎯 ОСНОВНОЙ ТЕСТ ПРОИЗВОДИТЕЛЬНОСТИ")
            print(f"   Цель: <50МБ на 1000 вакансий")
            print(f"   Доступно записей: {total_count}")
            
            start_time = time.time()
            
            result = exporter.export_to_excel(
                output_path=tmp_path,
                format_type='brief',  # Оптимальный формат для цели
                limit=1000
            )
            
            export_time = time.time() - start_time
            
            # Проверяем результат
            assert result['success'], f"Экспорт провалился: {result.get('errors', [])}"
            assert result['records_exported'] <= 1000, "Экспортировано больше записей чем ожидалось"
            
            # 🎯 ГЛАВНАЯ ПРОВЕРКА ЦЕЛИ
            assert result['file_size_mb'] < 50, (
                f"❌ ЦЕЛЬ НЕ ДОСТИГНУТА: файл {result['file_size_mb']}МБ > 50МБ! "
                f"Нужна дополнительная оптимизация."
            )
            
            # Дополнительные проверки производительности
            assert export_time < 60, f"Экспорт занял {export_time:.2f}с (лимит: 60с)"
            
            # Выводим результаты
            print(f"✅ ЦЕЛЬ ДОСТИГНУТА!")
            print(f"   📊 Записей: {result['records_exported']}")
            print(f"   💾 Размер: {result['file_size_mb']}МБ (<50МБ ✓)")
            print(f"   ⏱️  Время: {export_time:.2f}с")
            print(f"   📁 Файл: {tmp_path}")
            
            # Рассчитываем эффективность
            mb_per_1k_records = (result['file_size_mb'] / result['records_exported']) * 1000
            print(f"   📈 Эффективность: {mb_per_1k_records:.1f}МБ/1000записей")
            
        finally:
            # Не удаляем файл для инспекции
            print(f"   🔍 Файл сохранен для проверки: {tmp_path}")
    
    def test_export_with_filters(self, exporter: VacancyExporter):
        """Тест экспорта с фильтрами"""
        filters = {
            'min_salary': 50000,
            'area_name': 'Москва'
        }
        
        filtered_count = exporter.get_vacancy_count(filters)
        
        if filtered_count == 0:
            pytest.skip("Нет данных для фильтрованного экспорта")
        
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)
        
        try:
            result = exporter.export_to_excel(
                output_path=tmp_path,
                format_type='brief',
                filters=filters,
                limit=100
            )
            
            assert result['success'], f"Экспорт с фильтрами провалился: {result.get('errors', [])}"
            assert result['records_exported'] <= filtered_count
            
            print(f"🔍 Фильтрованный экспорт: {result['records_exported']} записей, "
                  f"{result['file_size_mb']}МБ")
            
        finally:
            if tmp_path.exists():
                tmp_path.unlink()


class TestExportFormats:
    """Тесты различных форматов экспорта"""
    
    @pytest.fixture(scope="class")
    def exporter(self) -> VacancyExporter:
        return VacancyExporter()
    
    def test_format_configurations(self):
        """Проверка конфигураций форматов"""
        for format_name, format_config in EXPORT_FORMATS.items():
            # Проверяем структуру
            assert 'name' in format_config
            assert 'description' in format_config
            assert 'columns' in format_config
            assert 'sql_fields' in format_config
            
            # Проверяем соответствие количества полей
            assert len(format_config['columns']) == len(format_config['sql_fields']), (
                f"Формат {format_name}: несоответствие количества колонок и SQL полей"
            )
            
            print(f"✓ Формат {format_name}: {len(format_config['columns'])} колонок")


if __name__ == "__main__":
    # Запуск основного теста цели
    pytest.main([__file__ + "::TestExportPerformance::test_large_export_performance_goal", "-v", "-s"])
