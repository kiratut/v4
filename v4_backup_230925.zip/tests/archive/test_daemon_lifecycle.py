#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тесты жизненного цикла демона планировщика (требование 7.1 из Functional_Tests_Specification.md)

// Chg_DAEMON_TESTS_2009: Реализация тестов 7.1-7.3 для scheduler_daemon.py
"""

import pytest
import subprocess
import time
import psutil
import os
import tempfile
from pathlib import Path
import sys
import json

# Добавляем путь к проекту
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


class TestDaemonLifecycle:
    """Тесты управления жизненным циклом демона (7.1)"""
    
    def setup_method(self):
        """Подготовка перед каждым тестом"""
        self.project_root = project_root
        self.pid_file = Path('data/scheduler_daemon.pid')
        
        # Убеждаемся что демон не запущен
        self._ensure_daemon_stopped()
    
    def teardown_method(self):
        """Очистка после каждого теста"""
        self._ensure_daemon_stopped()
    
    def _ensure_daemon_stopped(self):
        """Гарантированная остановка демона"""
        try:
            result = subprocess.run([
                sys.executable, 'cli_v4.py', 'daemon', 'stop'
            ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
            
            # Ждем немного для корректного завершения
            time.sleep(2)
            
        except subprocess.TimeoutExpired:
            # Принудительная остановка если не отвечает
            if self.pid_file.exists():
                try:
                    pid = int(self.pid_file.read_text().strip())
                    if psutil.pid_exists(pid):
                        psutil.Process(pid).kill()
                        time.sleep(1)
                except:
                    pass
                
                # Удаляем PID файл
                try:
                    self.pid_file.unlink()
                except:
                    pass
    
    def test_daemon_start_background(self):
        """DAEMON001: Тест запуска демона в фоновом режиме"""
        # Запускаем демон в background режиме
        result = subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'start', '--background'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
        
        assert result.returncode == 0, f"Ошибка запуска демона: {result.stderr}"
        assert "запущен в фоновом режиме" in result.stdout, f"Неожиданный вывод: {result.stdout}"
        
        # Проверяем что PID файл создался
        assert self.pid_file.exists(), "PID файл не создался"
        
        # Проверяем что процесс действительно запущен
        pid = int(self.pid_file.read_text().strip())
        assert psutil.pid_exists(pid), f"Процесс с PID {pid} не существует"
    
    def test_daemon_status(self):
        """DAEMON001: Тест проверки статуса демона"""
        # Сначала запускаем демон
        subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'start', '--background'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
        
        time.sleep(3)  # Даем время на запуск
        
        # Проверяем статус
        result = subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'status'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=15)
        
        assert result.returncode == 0, f"Ошибка проверки статуса: {result.stderr}"
        assert "Демон запущен" in result.stdout, f"Демон не запущен: {result.stdout}"
        assert "PID:" in result.stdout, "В статусе отсутствует PID"
    
    def test_daemon_stop(self):
        """DAEMON001: Тест остановки демона"""
        # Запускаем демон
        subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'start', '--background'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
        
        time.sleep(2)
        
        # Останавливаем демон
        result = subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'stop'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
        
        assert result.returncode == 0, f"Ошибка остановки демона: {result.stderr}"
        assert "остановлен" in result.stdout, f"Демон не остановлен: {result.stdout}"
        
        # Проверяем что PID файл удален
        assert not self.pid_file.exists(), "PID файл не удален после остановки"
    
    def test_daemon_restart(self):
        """DAEMON001: Тест перезапуска демона"""
        # Запускаем демон
        subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'start', '--background'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=30)
        
        time.sleep(2)
        old_pid = int(self.pid_file.read_text().strip())
        
        # Перезапускаем
        result = subprocess.run([
            sys.executable, 'cli_v4.py', 'daemon', 'restart'
        ], capture_output=True, text=True, cwd=self.project_root, timeout=45)
        
        assert result.returncode == 0, f"Ошибка перезапуска: {result.stderr}"
        assert "Перезапуск демона" in result.stdout, "Перезапуск не выполнен"
        
        time.sleep(3)
        
        # Проверяем что новый PID отличается от старого
        assert self.pid_file.exists(), "PID файл отсутствует после перезапуска"
        new_pid = int(self.pid_file.read_text().strip())
        assert new_pid != old_pid, "PID не изменился после перезапуска"
        assert psutil.pid_exists(new_pid), "Новый процесс не запущен"


class TestSchedulerTasks:
    """Тесты планировщика задач (7.2)"""
    
    def test_scheduler_initialization(self):
        """DAEMON002: Тест инициализации задач планировщика"""
        try:
            from core.scheduler_daemon import SchedulerDaemon
            
            # Создаем демон с тестовой конфигурацией
            daemon = SchedulerDaemon()
            
            # Проверяем что задачи инициализированы
            task_types = [task.task_type.value for task in daemon.scheduled_tasks.values()]
            
            expected_tasks = [
                'fetch_vacancies',  # 3.2.1-3.2.7: Загрузка вакансий
                'fetch_employers',  # 3.2.8-3.2.11: Загрузка работодателей  
                'cleanup_data',     # Очистка данных
                'system_health'     # Health checks
            ]
            
            for expected in expected_tasks:
                assert expected in task_types, f"Отсутствует обязательная задача: {expected}"
            
            print(f"✅ Инициализировано задач: {len(task_types)}")
            print(f"📋 Типы задач: {sorted(task_types)}")
            
        except ImportError as e:
            pytest.skip(f"Модуль scheduler_daemon недоступен: {e}")
    
    def test_scheduler_task_scheduling(self):
        """DAEMON002: Тест расчета времени выполнения задач"""
        try:
            from core.scheduler_daemon import SchedulerDaemon
            from datetime import datetime
            
            daemon = SchedulerDaemon()
            
            # Проверяем что у всех задач есть next_run время
            for task_id, task in daemon.scheduled_tasks.items():
                if task.enabled:
                    assert task.next_run is not None, f"Задача {task_id} не имеет времени выполнения"
                    assert task.next_run > datetime.now(), f"Задача {task_id} имеет время в прошлом"
            
            print(f"✅ Все активные задачи имеют корректное время выполнения")
            
        except ImportError as e:
            pytest.skip(f"Модуль scheduler_daemon недоступен: {e}")


class TestDaemonHostsIntegration:
    """Тесты интеграции с хостами (7.3)"""
    
    def test_daemon_hosts_initialization(self):
        """DAEMON004: Тест инициализации клиентов хостов"""
        try:
            from core.scheduler_daemon import SchedulerDaemon
            
            daemon = SchedulerDaemon()
            
            # Проверяем инициализацию TaskDispatcher
            assert daemon.dispatcher is not None, "TaskDispatcher не инициализирован"
            
            # Проверяем инициализацию клиентов хостов
            assert hasattr(daemon.dispatcher, 'host2_client'), "Host2 клиент не инициализирован"
            assert hasattr(daemon.dispatcher, 'host3_client'), "Host3 клиент не инициализирован"
            
            print("✅ Клиенты хостов инициализированы")
            
        except ImportError as e:
            pytest.skip(f"Модуль scheduler_daemon недоступен: {e}")
    
    def test_daemon_host_status_check(self):
        """DAEMON003: Тест проверки статуса хостов"""
        try:
            from core.scheduler_daemon import SchedulerDaemon
            
            daemon = SchedulerDaemon()
            
            # Получаем статус хостов
            host_status = daemon.dispatcher.get_host_status()
            
            assert isinstance(host_status, dict), "Статус хостов должен быть словарем"
            
            # Проверяем что есть информация о хосте 1 (основной)
            assert 'host1' in host_status, "Отсутствует статус Host1"
            
            print(f"✅ Статус хостов получен: {list(host_status.keys())}")
            
        except ImportError as e:
            pytest.skip(f"Модуль scheduler_daemon недоступен: {e}")


class TestDaemonHealthChecks:
    """Тесты системных health checks (7.3)"""
    
    def test_system_health_task(self):
        """DAEMON003: Тест задачи проверки здоровья системы"""
        try:
            from core.scheduler_daemon import SchedulerDaemon
            import asyncio
            
            daemon = SchedulerDaemon()
            
            # Находим задачу health check
            health_task = None
            for task in daemon.scheduled_tasks.values():
                if task.task_type.value == 'system_health':
                    health_task = task
                    break
            
            assert health_task is not None, "Задача system_health не найдена"
            assert health_task.enabled, "Задача system_health отключена"
            
            # Проверяем что задача выполняется часто (каждые 5 минут)
            assert "*/5" in health_task.schedule_pattern, "Health check должен выполняться каждые 5 минут"
            
            print("✅ Задача health check настроена корректно")
            
        except ImportError as e:
            pytest.skip(f"Модуль scheduler_daemon недоступен: {e}")


def main():
    """Запуск тестов демона"""
    print("🧪 === ТЕСТЫ ДЕМОНА ПЛАНИРОВЩИКА HH-БОТА v4 ===")
    print(f"⏰ Начало: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Запускаем тесты через pytest
    exit_code = pytest.main([
        __file__,
        '-v',
        '--tb=short',
        '-x'  # Остановка на первой ошибке
    ])
    
    return exit_code


if __name__ == "__main__":
    exit(main())
