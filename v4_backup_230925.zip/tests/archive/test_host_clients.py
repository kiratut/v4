#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тесты клиентов для Host2 и Host3

// Chg_TEST_HOST_CLIENTS_2009: Тестирование заглушек хостов
"""

import pytest
import tempfile
import os
from datetime import datetime
from unittest.mock import Mock, patch

# Импорт тестируемых модулей
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.host2_client import PostgreSQLClient, create_host2_client, AnalyticsQuery
from core.host3_client import LLMClient, create_host3_client, LLMRequest, LLMTaskType


class TestPostgreSQLClient:
    """Тесты PostgreSQL клиента (Host2)"""
    
    def test_init_mock_mode(self):
        """Тест инициализации в mock режиме"""
        config = {
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'mock_mode': True
        }
        
        client = PostgreSQLClient(config)
        
        assert client.host == 'localhost'
        assert client.port == 5432
        assert client.database == 'test_db'
        assert client.username == 'test_user'
        assert client.mock_mode is True
        assert client.connection is None
    
    def test_connect_mock_mode(self):
        """Тест подключения в mock режиме"""
        config = {'mock_mode': True}
        client = PostgreSQLClient(config)
        
        result = client.connect()
        
        assert result is True
        assert client.is_connected() is True
        assert client.connection == "mock_connection"
    
    def test_sync_vacancy_data_mock(self):
        """Тест синхронизации вакансий в mock режиме"""
        config = {'mock_mode': True}
        client = PostgreSQLClient(config)
        client.connect()
        
        vacancy_ids = [1, 2, 3, 4, 5]
        result = client.sync_vacancy_data(vacancy_ids)
        
        assert result['status'] == 'success'
        assert result['synced_count'] == 5
        assert result['failed_count'] == 0
        assert result['mock_data'] is True
        assert 'timestamp' in result
    
    def test_analytics_query_vacancy_stats(self):
        """Тест аналитического запроса статистики вакансий"""
        config = {'mock_mode': True}
        client = PostgreSQLClient(config)
        
        query = AnalyticsQuery(
            query_type='vacancy_stats',
            filters={'experience': 'middle'}
        )
        
        result = client.run_analytics_query(query)
        
        assert result.status == 'success'
        assert result.query_id.startswith('mock_')
        assert 'total_vacancies' in result.data
        assert 'avg_salary' in result.data
        assert 'top_skills' in result.data
        assert result.metadata['mock_mode'] is True
    
    def test_health_check(self):
        """Тест проверки состояния"""
        config = {'mock_mode': True, 'host': 'localhost', 'port': 5432}
        client = PostgreSQLClient(config)
        client.connect()
        
        health = client.health_check()
        
        assert health['service'] == 'postgresql_client'
        assert health['status'] == 'healthy'
        assert health['connection'] is True
        assert health['mock_mode'] is True
        assert health['host'] == 'localhost'
        assert health['port'] == 5432
    
    def test_factory_function(self):
        """Тест factory функции"""
        config = {'mock_mode': True}
        
        client = create_host2_client(config)
        
        assert isinstance(client, PostgreSQLClient)
        assert client.mock_mode is True


class TestLLMClient:
    """Тесты LLM клиента (Host3)"""
    
    def test_init_mock_mode(self):
        """Тест инициализации в mock режиме"""
        config = {
            'api_endpoint': 'http://localhost:8000',
            'api_key': 'test_key',
            'default_model': 'gpt-4',
            'mock_mode': True
        }
        
        client = LLMClient(config)
        
        assert client.api_endpoint == 'http://localhost:8000'
        assert client.api_key == 'test_key'
        assert client.default_model == 'gpt-4'
        assert client.mock_mode is True
        assert client._request_count == 0
    
    def test_is_available_mock_mode(self):
        """Тест проверки доступности в mock режиме"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        assert client.is_available() is True
    
    def test_vacancy_analysis_request(self):
        """Тест анализа вакансии"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        request = LLMRequest(
            task_type=LLMTaskType.VACANCY_ANALYSIS,
            input_data={'title': 'Python Developer', 'description': 'Great job'}
        )
        
        response = client.process_request(request)
        
        assert response.status == 'success'
        assert response.task_type == LLMTaskType.VACANCY_ANALYSIS
        assert 'analysis' in response.result
        assert 'key_requirements' in response.result
        assert 'experience_level' in response.result
        assert response.confidence > 0.7
        assert response.processing_time_ms > 0
    
    def test_skill_extraction(self):
        """Тест извлечения навыков"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        result = client.extract_skills("Требуется Python разработчик с опытом Django")
        
        assert 'technical_skills' in result
        assert 'soft_skills' in result
        assert 'required_experience' in result
        assert 'skill_confidence' in result
        assert isinstance(result['technical_skills'], list)
        assert len(result['technical_skills']) > 0
    
    def test_salary_prediction(self):
        """Тест предсказания зарплаты"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        vacancy_data = {
            'title': 'Senior Python Developer',
            'experience': '5+ years',
            'location': 'Moscow'
        }
        
        result = client.predict_salary(vacancy_data)
        
        assert 'predicted_salary_min' in result
        assert 'predicted_salary_max' in result
        assert 'currency' in result
        assert 'confidence' in result
        assert 'factors' in result
        assert result['predicted_salary_min'] > 0
        assert result['predicted_salary_max'] > result['predicted_salary_min']
    
    def test_matching_score(self):
        """Тест оценки соответствия"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        vacancy_data = {'title': 'Python Developer', 'skills': ['Python', 'Django']}
        user_profile = {'skills': ['Python', 'Flask'], 'experience': '3 years'}
        
        result = client.calculate_matching_score(vacancy_data, user_profile)
        
        assert 'overall_match' in result
        assert 'skill_match' in result
        assert 'experience_match' in result
        assert 'recommendation' in result
        assert 0 <= result['overall_match'] <= 1
        assert result['recommendation'] in ['strongly_recommend', 'recommend', 'consider', 'skip']
    
    def test_batch_processing(self):
        """Тест пакетной обработки"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        requests = [
            LLMRequest(LLMTaskType.SKILL_EXTRACTION, {'description': 'Python job'}),
            LLMRequest(LLMTaskType.SALARY_PREDICTION, {'title': 'Developer'}),
            LLMRequest(LLMTaskType.TEXT_CLASSIFICATION, {'text': 'Web development'})
        ]
        
        responses = client.batch_process(requests)
        
        assert len(responses) == 3
        assert all(r.status == 'success' for r in responses)
        assert responses[0].task_type == LLMTaskType.SKILL_EXTRACTION
        assert responses[1].task_type == LLMTaskType.SALARY_PREDICTION
        assert responses[2].task_type == LLMTaskType.TEXT_CLASSIFICATION
    
    def test_statistics(self):
        """Тест получения статистики"""
        config = {'mock_mode': True}
        client = LLMClient(config)
        
        # Выполняем несколько запросов
        client.extract_skills("Test description")
        client.analyze_vacancy({'title': 'Test'})
        
        stats = client.get_statistics()
        
        assert stats['total_requests'] == 2
        assert stats['mock_mode'] is True
        assert stats['status'] == 'available'
        assert 'last_request' in stats
    
    def test_health_check(self):
        """Тест проверки состояния"""
        config = {
            'mock_mode': True,
            'api_endpoint': 'http://localhost:8000',
            'default_model': 'gpt-3.5-turbo'
        }
        client = LLMClient(config)
        
        health = client.health_check()
        
        assert health['service'] == 'llm_client'
        assert health['status'] == 'healthy'
        assert health['mock_mode'] is True
        assert health['endpoint'] == 'http://localhost:8000'
        assert health['model'] == 'gpt-3.5-turbo'
        assert health['requests_processed'] == 0
    
    def test_factory_function(self):
        """Тест factory функции"""
        config = {'mock_mode': True}
        
        client = create_host3_client(config)
        
        assert isinstance(client, LLMClient)
        assert client.mock_mode is True


class TestIntegration:
    """Интеграционные тесты"""
    
    def test_clients_work_together(self):
        """Тест совместной работы клиентов"""
        # Создаем клиентов
        host2_config = {'mock_mode': True}
        host3_config = {'mock_mode': True}
        
        host2_client = create_host2_client(host2_config)
        host3_client = create_host3_client(host3_config)
        
        # Проверяем что оба работают
        assert host2_client.is_connected()
        assert host3_client.is_available()
        
        # Тестируем типичный workflow
        vacancy_ids = [1, 2, 3]
        
        # 1. Синхронизируем с Host2
        sync_result = host2_client.sync_vacancy_data(vacancy_ids)
        assert sync_result['status'] == 'success'
        
        # 2. Анализируем с Host3
        vacancy_data = {'title': 'Python Developer', 'description': 'Great opportunity'}
        analysis_result = host3_client.analyze_vacancy(vacancy_data)
        assert 'analysis' in analysis_result
        
        # 3. Проверяем статусы
        host2_health = host2_client.health_check()
        host3_health = host3_client.health_check()
        
        assert host2_health['status'] == 'healthy'
        assert host3_health['status'] == 'healthy'


def run_host_tests():
    """Запуск всех тестов хостов"""
    print("🧪 === ТЕСТИРОВАНИЕ КЛИЕНТОВ ХОСТОВ ===")
    print()
    
    # Тестируем Host2
    print("📊 Тестируем PostgreSQL клиент (Host2)...")
    host2_test = TestPostgreSQLClient()
    
    try:
        host2_test.test_init_mock_mode()
        host2_test.test_connect_mock_mode()
        host2_test.test_sync_vacancy_data_mock()
        host2_test.test_analytics_query_vacancy_stats()
        host2_test.test_health_check()
        host2_test.test_factory_function()
        print("✅ Host2 тесты пройдены")
    except Exception as e:
        print(f"❌ Host2 тесты провалились: {e}")
    
    print()
    
    # Тестируем Host3
    print("🤖 Тестируем LLM клиент (Host3)...")
    host3_test = TestLLMClient()
    
    try:
        host3_test.test_init_mock_mode()
        host3_test.test_is_available_mock_mode()
        host3_test.test_vacancy_analysis_request()
        host3_test.test_skill_extraction()
        host3_test.test_salary_prediction()
        host3_test.test_matching_score()
        host3_test.test_batch_processing()
        host3_test.test_statistics()
        host3_test.test_health_check()
        host3_test.test_factory_function()
        print("✅ Host3 тесты пройдены")
    except Exception as e:
        print(f"❌ Host3 тесты провалились: {e}")
    
    print()
    
    # Интеграционные тесты
    print("🔗 Тестируем интеграцию...")
    integration_test = TestIntegration()
    
    try:
        integration_test.test_clients_work_together()
        print("✅ Интеграционные тесты пройдены")
    except Exception as e:
        print(f"❌ Интеграционные тесты провалились: {e}")
    
    print()
    print("🎯 Тестирование клиентов хостов завершено!")


if __name__ == "__main__":
    run_host_tests()
