"""
Функциональные тесты бизнес-требований HH-бота v4
Тестируют требования раздела 1 (Бизнес-требования)

Автор: AI Assistant  
Дата: 19.09.2025 20:41:00
"""

import pytest
import time
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Импорты системы
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.database_v3 import VacancyDatabase
from core.models import Vacancy, Employer
from plugins.fetcher_v4 import VacancyFetcher


class TestBusinessRequirements:
    """Тесты бизнес-требований (раздел 1.1)"""
    
    @pytest.fixture(scope="class")
    def test_config(self) -> Dict:
        """Тестовая конфигурация"""
        return {
            "api": {
                "base_url": "https://api.hh.ru",
                "timeout": 30,
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            "database": {
                "path": "tests/data/test_business.sqlite3"
            },
            "search": {
                "max_pages": 5,  # Ограничение для тестов
                "results_per_page": 20
            }
        }
    
    @pytest.fixture(scope="class")
    def database(self, test_config: Dict) -> VacancyDatabase:
        """Тестовая база данных"""
        db_path = Path(test_config["database"]["path"])
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Удаляем старую БД
        if db_path.exists():
            db_path.unlink()
        
        db = VacancyDatabase(str(db_path))
        yield db
        
        # Cleanup
        # // Chg_TEARDOWN_2009: Безопасное удаление БД в Windows
        if db_path.exists():
            try:
                db_path.unlink(missing_ok=True)
            except PermissionError:
                # Файл заблокирован - оставляем для следующего запуска
                pass
    
    @pytest.fixture(scope="class") 
    def fetcher(self, test_config: Dict) -> VacancyFetcher:
        """Тестовый загрузчик вакансий"""
        return VacancyFetcher(test_config["api"])


class TestVacancySearch(TestBusinessRequirements):
    """1.1.1 - Поиск новых уникальных вакансий"""
    
    def test_search_finds_new_vacancies(self, fetcher: VacancyFetcher, database: VacancyDatabase):
        """
        ТРЕБОВАНИЕ: 1.1.1 - Поиск новых уникальных вакансий
        
        ЧТО ТЕСТИРУЕТСЯ:
        Способность системы находить новые вакансии через API HH.ru
        согласно пользовательским критериям поиска и сохранять их в БД.
        
        ВХОДНЫЕ ДАННЫЕ:
        - Поисковый запрос: "python разработчик"
        - Регион: Москва (area=1)
        - Зарплата: от 80,000 руб
        - Период: за последний день
        
        КРИТЕРИИ УСПЕХА:
        ✅ Найдено ≥5 новых вакансий за разумное время
        ✅ Все найденные вакансии содержат обязательные поля (id, name, employer)
        ✅ Нет дубликатов по ID среди результатов
        ✅ Время выполнения <10 минут
        ✅ Минимум 1 вакансия сохранена в БД
        
        ОЖИДАЕМЫЕ РЕЗУЛЬТАТЫ:
        - Статус: SUCCESS если все критерии выполнены
        - Вывод: Количество найденных и сохраненных вакансий
        - Время выполнения в секундах
        
        ПОНИМАНИЕ ДЛЯ ПОЛЬЗОВАТЕЛЯ:
        "Система ищет вакансии по вашему запросу и находит несколько подходящих.
        Если тест проходит - поиск работает и вакансии сохраняются для изучения."
        
        ДЛЯ ПОДДЕРЖКИ:
        Если тест падает - проверить доступность API HH.ru, корректность
        авторизации и работу сети. Логи содержат детали ошибок API.
        """
        start_time = time.time()
        
        # Поисковые параметры (реалистичный запрос)
        search_params = {
            "text": "python разработчик",
            "area": 1,  # Москва
            "per_page": 20,
            "period": 1,  # За последний день
            "salary": 80000  # Минимальная зарплата
        }
        
        # Выполняем поиск
        try:
            results = fetcher.search_vacancies(**search_params)
            
            # Проверяем базовый ответ API
            assert "items" in results, "API не вернул список вакансий"
            assert "found" in results, "API не вернул общее количество"
            
            vacancies = results["items"]
            
            # Критерий: Найдено минимум 5 вакансий
            assert len(vacancies) >= 5, f"Найдено слишком мало вакансий: {len(vacancies)}"
            
            # Критерий: Все вакансии содержат обязательные поля
            for vacancy in vacancies:
                assert "id" in vacancy, "Отсутствует ID вакансии"
                assert "name" in vacancy, "Отсутствует название вакансии"
                assert "employer" in vacancy, "Отсутствует информация о работодателе"
            
            # Критерий: Нет дубликатов по ID
            vacancy_ids = [v["id"] for v in vacancies]
            assert len(vacancy_ids) == len(set(vacancy_ids)), "Найдены дубликаты вакансий"
            
            # Критерий: Время выполнения
            execution_time = time.time() - start_time
            assert execution_time < 600, f"Поиск слишком долгий: {execution_time:.1f} секунд"
            
            # Сохраняем результаты для последующих тестов
            saved_count = 0
            for vacancy_data in vacancies:
                vacancy = self._convert_api_to_model(vacancy_data)
                vacancy_id = database.save_vacancy(vacancy)
                if vacancy_id:
                    saved_count += 1
            
            assert saved_count > 0, "Не удалось сохранить ни одной вакансии"
            
        except Exception as e:
            pytest.fail(f"Ошибка при поиске вакансий: {e}")
    
    def test_search_respects_filters(self, fetcher: VacancyFetcher):
        """
        Технический тест: Поиск соблюдает параметры фильтров
        """
        # Тест с конкретными фильтрами
        search_params = {
            "text": "middle python", 
            "experience": "between1And3",  # 1-3 года опыта
            "employment": "full",          # Полная занятость
            "schedule": "remote"           # Удаленная работа
        }
        
        results = fetcher.search_vacancies(**search_params)
        
        # Проверяем, что API принял параметры
        assert results is not None
        assert "items" in results
        
        # Если есть результаты, проверяем соответствие (хотя бы базовое)
        if len(results["items"]) > 0:
            for vacancy in results["items"][:3]:  # Проверяем первые 3
                # Название должно содержать ключевые слова
                name_lower = vacancy["name"].lower()
                assert any(word in name_lower for word in ["python", "пайтон", "разработчик"])
    
    def test_search_pagination_calculation(self, fetcher: VacancyFetcher):
        """
        Технический тест: Корректный расчет количества страниц
        """
        # Делаем запрос для подсчета общего количества
        initial_params = {
            "text": "программист",
            "per_page": 1  # Минимум для быстрого ответа
        }
        
        response = fetcher.search_vacancies(**initial_params)
        
        total_found = response.get("found", 0)
        per_page = 20  # Стандартный размер страницы
        
        # Рассчитываем количество страниц
        import math
        expected_pages = math.ceil(total_found / per_page)
        
        # Проверки расчета
        assert expected_pages > 0, "Должна быть минимум 1 страница"
        assert expected_pages <= 100, f"Слишком много страниц: {expected_pages}. Нужно уточнить поиск"
        
        # Если страниц разумное количество, проверяем несколько
        if expected_pages <= 5:
            page_results = []
            for page in range(min(3, expected_pages)):
                page_response = fetcher.search_vacancies(
                    text="программист", 
                    per_page=per_page, 
                    page=page
                )
                page_results.append(len(page_response.get("items", [])))
            
            # На каждой странице должны быть результаты (кроме возможно последней)
            assert all(count > 0 for count in page_results[:-1])
    
    def _convert_api_to_model(self, api_data: Dict) -> Vacancy:
        """Конвертирует данные из API HH в модель Vacancy"""
        employer = api_data.get("employer", {})
        salary = api_data.get("salary") or {}
        
        return Vacancy(
            hh_id=str(api_data["id"]),
            title=api_data["name"],
            employer_name=employer.get("name", ""),
            employer_id=str(employer.get("id", "")),
            salary_from=salary.get("from"),
            salary_to=salary.get("to"), 
            currency=salary.get("currency"),
            experience=api_data.get("experience", {}).get("name"),
            schedule=api_data.get("schedule", {}).get("name"),
            employment=api_data.get("employment", {}).get("name"),
            description=api_data.get("snippet", {}).get("requirement", ""),
            area_name=api_data.get("area", {}).get("name"),
            published_at=api_data.get("published_at"),
            url=api_data.get("alternate_url")
        )


class TestDataExport(TestBusinessRequirements):
    """1.1.6 - Вывод в Excel для изучения"""
    
    def test_excel_export_user_friendly(self, database: VacancyDatabase):
        """
        ТРЕБОВАНИЕ: 1.1.6 - Вывод в Excel для изучения
        
        ЧТО ТЕСТИРУЕТСЯ:
        Создание пользовательского Excel файла с вакансиями в удобном
        для анализа формате с правильными заголовками и форматированием.
        
        ВХОДНЫЕ ДАННЫЕ:
        - 10 тестовых вакансий с полными данными
        - Разные зарплаты, компании, даты
        - Реалистичные названия и описания
        
        КРИТЕРИИ УСПЕХА:
        ✅ Файл создан в формате .xlsx (совместим с Excel)
        ✅ Размер файла >1KB (содержит данные)
        ✅ Заголовки на русском языке и понятны
        ✅ Минимум 8 колонок: Название, Компания, Зарплата, Опыт, Город, Дата, Ссылка, Статус
        ✅ Данные правильно отформатированы (зарплата с запятыми, дата в формате ДД.ММ.ГГГГ)
        ✅ Минимум 10 строк с данными
        
        ОЖИДАЕМЫЕ РЕЗУЛЬТАТЫ:
        - Статус: SUCCESS если файл создан и валиден
        - Файл: test_export.xlsx готов для открытия
        - Содержимое: структурированные данные вакансий
        
        ПОНИМАНИЕ ДЛЯ ПОЛЬЗОВАТЕЛЯ:
        "Система создает Excel файл со всеми найденными вакансиями.
        Вы можете открыть его, отсортировать, отфильтровать и отметить
        интересные вакансии в столбце 'Статус'."
        
        ДЛЯ ПОДДЕРЖКИ:
        Если тест падает - проверить наличие библиотеки openpyxl,
        права на запись в папку tests/data, корректность данных в БД.
        """
        # Создаем тестовые данные
        test_vacancies = [
            Vacancy(
                hh_id=f"test_{i}",
                title=f"Python Разработчик {i}",
                employer_name=f"Компания {i}",
                employer_id=f"emp_{i}",
                salary_from=80000 + i * 10000,
                salary_to=120000 + i * 10000,
                currency="RUR",
                experience="От 1 года до 3 лет",
                area_name="Москва",
                published_at=datetime.now().isoformat()
            ) for i in range(1, 11)
        ]
        
        # Сохраняем в БД
        for vacancy in test_vacancies:
            database.save_vacancy(vacancy)
        
        # Создаем экспорт
        export_path = Path("tests/data/test_export.xlsx")
        export_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Удаляем старый файл если есть
        if export_path.exists():
            export_path.unlink()
        
        # Выполняем экспорт
        try:
            self._export_to_excel(database, export_path)
            
            # Проверяем, что файл создался
            assert export_path.exists(), "Excel файл не был создан"
            assert export_path.suffix == ".xlsx", "Неверный формат файла"
            
            # Проверяем размер файла (должен быть больше 1KB)
            file_size = export_path.stat().st_size
            assert file_size > 1024, f"Файл слишком маленький: {file_size} байт"
            
            # Пытаемся открыть файл (базовая проверка)
            try:
                import openpyxl
                workbook = openpyxl.load_workbook(export_path)
                worksheet = workbook.active
                
                # Проверяем заголовки (первая строка)
                headers = [cell.value for cell in worksheet[1]]
                expected_headers = [
                    "Название вакансии", "Компания", "Зарплата от", 
                    "Зарплата до", "Опыт", "Город", "Дата публикации", "Ссылка"
                ]
                
                for expected in expected_headers:
                    assert any(expected.lower() in str(h).lower() for h in headers), \
                           f"Отсутствует заголовок: {expected}"
                
                # Проверяем данные (минимум 10 строк с данными)
                data_rows = list(worksheet.iter_rows(min_row=2, values_only=True))
                assert len(data_rows) >= 10, "Недостаточно строк с данными"
                
                workbook.close()
                
            except ImportError:
                pytest.skip("openpyxl не установлен - пропускаем детальную проверку Excel")
            
        finally:
            # Cleanup
            if export_path.exists():
                export_path.unlink()
    
    def test_export_data_formatting(self, database: VacancyDatabase):
        """
        Технический тест: Корректное форматирование данных при экспорте
        """
        # Создаем вакансию с различными типами данных
        test_vacancy = Vacancy(
            hh_id="format_test_123",
            title="Senior Python Developer",
            employer_name="ТестКомпания ООО", 
            employer_id="emp_format",
            salary_from=150000,
            salary_to=200000,
            currency="RUR",
            experience="От 3 до 6 лет",
            area_name="Санкт-Петербург",
            published_at="2025-09-19T15:30:45+03:00",
            url="https://hh.ru/vacancy/12345678"
        )
        
        database.save_vacancy(test_vacancy)
        
        # Получаем данные для экспорта
        vacancies = [database.get_vacancy_by_hh_id("format_test_123")]
        export_data = self._prepare_export_data(vacancies)
        
        # Проверяем форматирование
        assert len(export_data) > 0, "Нет данных для экспорта"
        
        row = export_data[0]
        # // Chg_EXCEL_HDR_2009: Обновлена проверка зарплаты
        assert row.get("Зарплата от") == 150000, "Неверная зарплата от"
        assert row.get("Зарплата до") == 200000, "Неверная зарплата до"
        assert "19.09.2025" in str(row.get("Дата публикации", "")), "Неверное форматирование даты"
        assert "ТестКомпания ООО" == row.get("Компания"), "Неверное отображение компании"
    
    def _export_to_excel(self, db: VacancyDatabase, file_path: Path):
        """Экспорт вакансий в Excel файл"""
        # Получаем данные из БД
        vacancies_data = db.execute_sql(
            "SELECT * FROM vacancies ORDER BY created_at DESC LIMIT 100"
        )
        
        # Подготавливаем данные для экспорта
        export_data = []
        for vacancy in vacancies_data:
            # Форматируем зарплату
            salary = ""
            if vacancy.get('salary_from') and vacancy.get('salary_to'):
                salary = f"{vacancy['salary_from']:,} - {vacancy['salary_to']:,} ₽"
            elif vacancy.get('salary_from'):
                salary = f"от {vacancy['salary_from']:,} ₽"
            
            # Форматируем дату
            pub_date = vacancy.get('published_at', '')
            if pub_date:
                try:
                    dt = datetime.fromisoformat(pub_date.replace('Z', '+00:00'))
                    pub_date = dt.strftime('%d.%m.%Y')
                except:
                    pass
            
            # // Chg_EXCEL_HDR_2009: Исправлены заголовки экспорта
            export_data.append({
                "Название вакансии": vacancy.get('title', ''),
                "Компания": vacancy.get('employer_name', ''),
                "Зарплата от": vacancy.get('salary_from', ''),
                "Зарплата до": vacancy.get('salary_to', ''), 
                "Опыт": vacancy.get('experience', ''),
                "Город": vacancy.get('area_name', ''),
                "Дата публикации": pub_date,
                "Ссылка": vacancy.get('url', '')
            })
        
        # Создаем Excel файл
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment
            
            workbook = openpyxl.Workbook()
            worksheet = workbook.active
            worksheet.title = "Вакансии"
            
            # Записываем заголовки
            headers = list(export_data[0].keys()) if export_data else []
            for col, header in enumerate(headers, 1):
                cell = worksheet.cell(row=1, column=col, value=header)
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal='center')
            
            # Записываем данные
            for row_idx, row_data in enumerate(export_data, 2):
                for col_idx, value in enumerate(row_data.values(), 1):
                    worksheet.cell(row=row_idx, column=col_idx, value=value)
            
            # Автоширина колонок
            for column in worksheet.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                worksheet.column_dimensions[column_letter].width = adjusted_width
            
            workbook.save(file_path)
            workbook.close()
            
        except ImportError:
            # Fallback - создаем CSV если нет openpyxl
            import csv
            csv_path = file_path.with_suffix('.csv')
            
            with open(csv_path, 'w', newline='', encoding='utf-8-sig') as csvfile:
                if export_data:
                    writer = csv.DictWriter(csvfile, fieldnames=export_data[0].keys())
                    writer.writeheader()
                    writer.writerows(export_data)
    
    def _prepare_export_data(self, vacancies: List[Vacancy]) -> List[Dict]:
        """Подготавливает данные вакансий для экспорта"""
        export_data = []
        
        for vacancy in vacancies:
            if not vacancy:
                continue
                
            # Форматируем зарплату
            salary = ""
            if vacancy.salary_from and vacancy.salary_to:
                salary = f"{vacancy.salary_from:,} - {vacancy.salary_to:,} ₽"
            elif vacancy.salary_from:
                salary = f"от {vacancy.salary_from:,} ₽"
            
            # Форматируем дату
            pub_date = ""
            if vacancy.published_at:
                try:
                    dt = datetime.fromisoformat(vacancy.published_at.replace('Z', '+00:00'))
                    pub_date = dt.strftime('%d.%m.%Y')
                except:
                    pub_date = vacancy.published_at
            
            # // Chg_EXCEL_HDR_2009: Исправлены заголовки экспорта в _prepare_export_data
            export_data.append({
                "Название вакансии": vacancy.title,
                "Компания": vacancy.employer_name,
                "Зарплата от": vacancy.salary_from or "",
                "Зарплата до": vacancy.salary_to or "", 
                "Опыт": vacancy.experience or "",
                "Город": vacancy.area_name or "",
                "Дата публикации": pub_date,
                "Ссылка": vacancy.url or ""
            })
        
        return export_data


class TestDataUniqueness(TestBusinessRequirements):
    """Тесты уникальности и дедупликации данных"""
    
    def test_vacancy_deduplication(self, database: VacancyDatabase):
        """
        ТРЕБОВАНИЕ: 2.12.4 - Версионирование и дедупликация данных
        
        ЧТО ТЕСТИРУЕТСЯ:
        Алгоритм определения дубликатов вакансий и создания версий
        при изменении контента. Базовая функция для избежания мусора в БД.
        
        ВХОДНЫЕ ДАННЫЕ:
        - Исходная вакансия с полными данными
        - Точная копия (должна определиться как дубликат)
        - Вакансия с измененным названием (должна создать новую версию)
        
        КРИТЕРИИ УСПЕХА:
        ✅ Первое сохранение создает запись с version=1
        ✅ Дубликат возвращает ID существующей записи (не создает новую)
        ✅ Измененная вакансия создает version=2 с prev_version_id
        ✅ Связь между версиями корректно установлена
        
        ОЖИДАЕМЫЕ РЕЗУЛЬТАТЫ:
        - Статус: SUCCESS если версионирование работает корректно
        - В БД: 2 записи (версии 1 и 2) с правильными связями
        - Дубликат: не создает лишних записей
        
        ПОНИМАНИЕ ДЛЯ ПОЛЬЗОВАТЕЛЯ:
        "Система умно определяет одинаковые вакансии и не засоряет базу
        дубликатами. Если вакансия изменилась - сохраняет новую версию."
        
        ДЛЯ ПОДДЕРЖКИ:
        Если тест падает - проверить алгоритм расчета content_hash
        в database_v3.py, корректность полей версионирования в схеме БД.
        """
        # Создаем вакансию
        original_vacancy = Vacancy(
            hh_id="dedup_test_456",
            title="Тест дедупликации",
            employer_name="ТестовЯ компания",
            employer_id="emp_dedup",
            salary_from=100000,
            description="Описание для теста дедупликации"
        )
        
        # Сохраняем первый раз
        id1 = database.save_vacancy(original_vacancy)
        assert id1 is not None
        
        # Сохраняем точно такую же вакансию - должна вернуться та же запись
        duplicate_vacancy = Vacancy(
            hh_id="dedup_test_456",
            title="Тест дедупликации", 
            employer_name="ТестовЯ компания",
            employer_id="emp_dedup", 
            salary_from=100000,
            description="Описание для теста дедупликации"
        )
        
        id2 = database.save_vacancy(duplicate_vacancy)
        assert id2 == id1, "Дубликат должен вернуть тот же ID"
        
        # Изменяем контент - должна создаться новая версия
        modified_vacancy = Vacancy(
            hh_id="dedup_test_456",
            title="Тест дедупликации - ОБНОВЛЕНО",  # Изменили title
            employer_name="ТестовЯ компания",
            employer_id="emp_dedup",
            salary_from=100000,
            description="Описание для теста дедупликации"
        )
        
        id3 = database.save_vacancy(modified_vacancy)
        assert id3 != id1, "Измененная вакансия должна создать новую версию"
        
        # Проверяем версионирование
        saved_v1 = database.get_vacancy(id1)
        saved_v3 = database.get_vacancy(id3)
        
        assert saved_v1.version == 1, "Первая версия должна иметь version=1"
        assert saved_v3.version == 2, "Вторая версия должна иметь version=2"
        assert saved_v3.prev_version_id == id1, "Должна быть связь между версиями"


if __name__ == "__main__":
    # Запуск тестов напрямую
    pytest.main([__file__, "-v"])
