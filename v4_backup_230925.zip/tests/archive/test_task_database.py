#!/usr/bin/env python3
"""
Тесты для TaskDatabase v4
"""

import unittest
import tempfile
import time
import json
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.task_database import TaskDatabase

class TestTaskDatabase(unittest.TestCase):
    """Тесты для TaskDatabase"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_db_path = Path(self.temp_dir) / 'test_task_db.sqlite3'
        
        self.db = TaskDatabase()
        self.db.db_path = self.test_db_path
        self.db.init_database()
        
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_database_initialization(self):
        """Тест инициализации базы данных"""
        self.assertTrue(self.test_db_path.exists())
        
        # Проверяем что таблицы созданы
        with self.db.get_connection() as conn:
            tables = conn.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name IN ('tasks', 'vacancies')
            """).fetchall()
            
            table_names = {row[0] for row in tables}
            self.assertIn('tasks', table_names)
            self.assertIn('vacancies', table_names)
    
    def test_create_task(self):
        """Тест создания задачи"""
        task_id = 'test-task-123'
        
        self.db.create_task(
            task_id=task_id,
            task_type='test_task',
            params={'key': 'value'},
            timeout_sec=300
        )
        
        # Проверяем что задача создана
        task = self.db.get_task(task_id)
        self.assertIsNotNone(task)
        self.assertEqual(task['id'], task_id)
        self.assertEqual(task['type'], 'test_task')
        self.assertEqual(task['status'], 'pending')
        self.assertIsNotNone(task['created_at'])
    
    def test_update_task_status(self):
        """Тест обновления статуса задачи"""
        task_id = 'test-update-123'
        
        # Создаём задачу
        self.db.create_task(task_id, 'test', {})
        
        # Обновляем статус
        progress = {'step': 1, 'total': 5}
        self.db.update_task_status(
            task_id=task_id,
            status='running',
            progress=progress
        )
        
        # Проверяем обновление
        task = self.db.get_task(task_id)
        self.assertEqual(task['status'], 'running')
        self.assertIsNotNone(task['started_at'])
        
        # Проверяем прогресс
        task_progress = json.loads(task['progress_json'])
        self.assertEqual(task_progress['step'], 1)
        self.assertEqual(task_progress['total'], 5)
    
    def test_complete_task(self):
        """Тест завершения задачи"""
        task_id = 'test-complete-123'
        
        # Создаём и запускаем задачу
        self.db.create_task(task_id, 'test', {})
        self.db.update_task_status(task_id, 'running')
        
        # Завершаем задачу
        result = {'processed': 100, 'errors': 0}
        self.db.complete_task(task_id, result)
        
        # Проверяем завершение
        task = self.db.get_task(task_id)
        self.assertEqual(task['status'], 'completed')
        self.assertIsNotNone(task['finished_at'])
        
        # Проверяем результат
        task_result = json.loads(task['result_json'])
        self.assertEqual(task_result['processed'], 100)
        self.assertEqual(task_result['errors'], 0)
    
    def test_fail_task(self):
        """Тест неуспешного завершения задачи"""
        task_id = 'test-fail-123'
        
        # Создаём и запускаем задачу
        self.db.create_task(task_id, 'test', {})
        self.db.update_task_status(task_id, 'running')
        
        # Помечаем как неуспешную
        error_msg = "Test error message"
        self.db.fail_task(task_id, error_msg)
        
        # Проверяем
        task = self.db.get_task(task_id)
        self.assertEqual(task['status'], 'failed')
        self.assertEqual(task['error'], error_msg)
        self.assertIsNotNone(task['finished_at'])
    
    def test_get_pending_tasks(self):
        """Тест получения pending задач"""
        # Создаём несколько задач
        for i in range(3):
            self.db.create_task(f'pending-{i}', 'test', {})
        
        # Одну помечаем как running
        self.db.update_task_status('pending-1', 'running')
        
        # Получаем pending задачи
        pending_tasks = self.db.get_pending_tasks(limit=10)
        
        self.assertEqual(len(pending_tasks), 2)
        for task in pending_tasks:
            self.assertEqual(task['status'], 'pending')
    
    def test_save_vacancy(self):
        """Тест сохранения вакансии"""
        vacancy_data = {
            'hh_id': '12345',
            'title': 'Test Developer',
            'company': 'Test Company',
            'salary_from': 100000,
            'salary_to': 150000,
            'currency': 'RUR',
            'area': 'Москва',
            'published_at': '2025-09-14T10:00:00+03:00',
            'url': 'https://hh.ru/vacancy/12345',
            'description': 'Test description',
            'filter_id': 'test-filter',
            'raw_json': '{"id": "12345", "name": "Test Developer"}'
        }
        
        vacancy_id = self.db.save_vacancy(vacancy_data)
        self.assertIsNotNone(vacancy_id)
        
        # Проверяем что вакансия сохранена
        with self.db.get_connection() as conn:
            vacancy = conn.execute("""
                SELECT * FROM vacancies WHERE id = ?
            """, (vacancy_id,)).fetchone()
            
            self.assertIsNotNone(vacancy)
            self.assertEqual(vacancy['hh_id'], '12345')
            self.assertEqual(vacancy['title'], 'Test Developer')
            self.assertEqual(vacancy['filter_id'], 'test-filter')
    
    def test_get_stats(self):
        """Тест получения статистики"""
        # Создаём тестовые данные
        for i in range(5):
            task_id = f'stat-task-{i}'
            self.db.create_task(task_id, 'test', {})
            
            if i < 2:
                self.db.update_task_status(task_id, 'completed')
            elif i < 4:
                self.db.update_task_status(task_id, 'running')
            # Одну оставляем pending
        
        # Добавляем вакансии
        for i in range(3):
            self.db.save_vacancy({
                'hh_id': f'test-{i}',
                'title': f'Test Job {i}',
                'filter_id': 'test-filter'
            })
        
        stats = self.db.get_stats()
        
        # Проверяем статистику задач
        self.assertIn('tasks', stats)
        task_stats = stats['tasks']
        self.assertEqual(task_stats.get('pending', 0), 1)
        self.assertEqual(task_stats.get('running', 0), 2)
        self.assertEqual(task_stats.get('completed', 0), 2)
        
        # Проверяем статистику вакансий
        self.assertIn('vacancies', stats)
        vacancy_stats = stats['vacancies']
        self.assertEqual(vacancy_stats['total_vacancies'], 3)
    
    def test_get_vacancy_count_by_filter(self):
        """Тест подсчёта вакансий по фильтрам"""
        # Добавляем вакансии с разными фильтрами
        filters_data = [
            ('python-filter', 3),
            ('java-filter', 2),
            ('js-filter', 1)
        ]
        
        for filter_id, count in filters_data:
            for i in range(count):
                self.db.save_vacancy({
                    'hh_id': f'{filter_id}-{i}',
                    'title': f'Job {filter_id} {i}',
                    'filter_id': filter_id
                })
        
        filter_counts = self.db.get_vacancy_count_by_filter()
        
        self.assertEqual(filter_counts.get('python-filter', 0), 3)
        self.assertEqual(filter_counts.get('java-filter', 0), 2)
        self.assertEqual(filter_counts.get('js-filter', 0), 1)
    
    def test_cleanup_old_tasks(self):
        """Тест очистки старых задач"""
        current_time = time.time()
        old_time = current_time - (8 * 86400)  # 8 дней назад
        
        # Создаём старые задачи
        for i in range(3):
            task_id = f'old-task-{i}'
            self.db.create_task(task_id, 'test', {})
            self.db.complete_task(task_id, {})
            
            # Устанавливаем старое время создания
            with self.db.get_connection() as conn:
                conn.execute("""
                    UPDATE tasks SET created_at = ? WHERE id = ?
                """, (old_time, task_id))
        
        # Создаём новые задачи
        for i in range(2):
            self.db.create_task(f'new-task-{i}', 'test', {})
        
        # Очищаем задачи старше 7 дней
        result = self.db.cleanup_old_tasks(days_to_keep=7)
        
        self.assertEqual(result['cleaned_count'], 3)
        
        # Проверяем что новые задачи остались
        remaining_tasks = self.db.get_pending_tasks(limit=10)
        self.assertEqual(len(remaining_tasks), 2)

if __name__ == '__main__':
    unittest.main()
