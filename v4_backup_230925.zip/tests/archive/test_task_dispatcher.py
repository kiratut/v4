#!/usr/bin/env python3
"""
Тесты для TaskDispatcher v4
"""

import unittest
import tempfile
import threading
import time
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.task_dispatcher import TaskDispatcher, Task
from core.task_database import TaskDatabase

class TestTaskDispatcher(unittest.TestCase):
    """Тесты диспетчера задач"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_db_path = Path(self.temp_dir) / 'test_v4.sqlite3'
        
        # Подменяем путь к БД для тестов
        self.original_db_path = None
        
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_task_creation(self):
        """Тест создания задачи"""
        task = Task(
            id='test-123',
            type='test_task',
            params={'test': 'data'},
            timeout_sec=60
        )
        
        self.assertEqual(task.id, 'test-123')
        self.assertEqual(task.type, 'test_task')
        self.assertEqual(task.params, {'test': 'data'})
        self.assertEqual(task.timeout_sec, 60)
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_dispatcher_init(self, mock_db_class):
        """Тест инициализации диспетчера"""
        mock_db = MagicMock()
        mock_db_class.return_value = mock_db
        
        dispatcher = TaskDispatcher(max_workers=2, chunk_size=100)
        
        self.assertEqual(dispatcher.max_workers, 2)
        self.assertEqual(dispatcher.chunk_size, 100)
        self.assertFalse(dispatcher.running)
        self.assertEqual(len(dispatcher.workers), 0)
        mock_db_class.assert_called_once()
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_add_task(self, mock_db_class):
        """Тест добавления задачи"""
        mock_db = MagicMock()
        mock_db_class.return_value = mock_db
        
        dispatcher = TaskDispatcher(max_workers=1)
        
        task_id = dispatcher.add_task(
            task_type='test_task',
            params={'key': 'value'},
            timeout_sec=30
        )
        
        # Проверяем что task_id это валидный UUID
        self.assertIsInstance(task_id, str)
        self.assertEqual(len(task_id), 36)  # UUID length
        
        # Проверяем что задача создана в БД
        mock_db.create_task.assert_called_once()
        call_args = mock_db.create_task.call_args[1]
        self.assertEqual(call_args['task_type'], 'test_task')
        self.assertEqual(call_args['params'], {'key': 'value'})
        self.assertEqual(call_args['timeout_sec'], 30)
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_get_status(self, mock_db_class):
        """Тест получения статуса диспетчера"""
        mock_db = MagicMock()
        mock_db.get_stats.return_value = {'tasks': {'pending': 5}}
        mock_db_class.return_value = mock_db
        
        dispatcher = TaskDispatcher(max_workers=3)
        
        status = dispatcher.get_status()
        
        self.assertIn('workers_count', status)
        self.assertIn('queue_size', status)
        self.assertIn('stats', status)
        self.assertEqual(status['workers_count'], 0)  # Не запущен
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_handle_test_task(self, mock_db_class):
        """Тест обработки тестовой задачи"""
        mock_db = MagicMock()
        mock_db_class.return_value = mock_db
        
        dispatcher = TaskDispatcher()
        
        task = Task(
            id='test-123',
            type='test',
            params={'message': 'Hello Test'},
            timeout_sec=60
        )
        
        result = dispatcher._handle_test(worker_id='test-worker', task=task)
        
        self.assertIn('message', result)
        self.assertIn('timestamp', result)
        self.assertEqual(result['message'], 'Hello Test')
    
    @patch('core.task_dispatcher.TaskDatabase')  
    @patch('plugins.fetcher_v4.VacancyFetcher')
    def test_handle_load_vacancies_task(self, mock_fetcher_class, mock_db_class):
        """Тест обработки задачи загрузки вакансий"""
        mock_db = MagicMock()
        mock_db_class.return_value = mock_db
        
        mock_fetcher = MagicMock()
        mock_fetcher.load_chunk.return_value = {'loaded_count': 100}
        mock_fetcher_class.return_value = mock_fetcher
        
        dispatcher = TaskDispatcher()
        
        task = Task(
            id='load-123',
            type='load_vacancies',
            params={'filter': {'id': 'test-filter'}, 'max_pages': 4},
            timeout_sec=3600,
            chunk_size=200
        )
        
        result = dispatcher._handle_load_vacancies(worker_id='worker-1', task=task)
        
        self.assertIn('loaded_count', result)
        self.assertIn('chunks_processed', result)
        # Проверяем что fetcher вызывался
        mock_fetcher_class.assert_called_once()
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_handle_cleanup_task(self, mock_db_class):
        """Тест обработки задачи очистки"""
        mock_db = MagicMock()
        mock_db.cleanup_old_tasks.return_value = {'cleaned_count': 50, 'cleaned_bytes': 1024000}
        mock_db_class.return_value = mock_db
        
        dispatcher = TaskDispatcher()
        
        task = Task(
            id='cleanup-123',
            type='cleanup',
            params={},
            timeout_sec=300
        )
        
        result = dispatcher._handle_cleanup(worker_id='worker-1', task=task)
        
        self.assertEqual(result['cleaned_tasks'], 50)
        self.assertEqual(result['cleaned_bytes'], 1024000)
        mock_db.cleanup_old_tasks.assert_called_once_with(days_to_keep=7)

class TestTaskDispatcherIntegration(unittest.TestCase):
    """Интеграционные тесты диспетчера"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_db_path = Path(self.temp_dir) / 'test_integration.sqlite3'
        
        # Создаём тестовую БД
        self.db = TaskDatabase()
        # Подменяем путь к БД
        self.db.db_path = self.test_db_path
        self.db.init_database()
        
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @patch('core.task_dispatcher.TaskDatabase')
    def test_dispatcher_lifecycle(self, mock_db_class):
        """Тест полного жизненного цикла диспетчера"""
        mock_db_class.return_value = self.db
        
        dispatcher = TaskDispatcher(max_workers=1, chunk_size=50)
        
        # Добавляем тестовую задачу
        task_id = dispatcher.add_task(
            task_type='test',
            params={'message': 'Integration Test'},
            timeout_sec=10
        )
        
        self.assertIsNotNone(task_id)
        
        # Проверяем что задача есть в БД
        task = self.db.get_task(task_id)
        self.assertIsNotNone(task)
        self.assertEqual(task['status'], 'pending')
        
        # Получаем статус диспетчера
        status = dispatcher.get_status()
        self.assertGreater(status['queue_size'], 0)
    
    @patch('core.task_dispatcher.TaskDatabase')
    @patch('time.sleep')  # Ускоряем тест
    def test_worker_execution(self, mock_sleep, mock_db_class):
        """Тест выполнения задачи worker'ом"""
        mock_db_class.return_value = self.db
        
        dispatcher = TaskDispatcher(max_workers=1)
        
        # Добавляем тестовую задачу
        task_id = dispatcher.add_task(
            task_type='test',
            params={'message': 'Worker Test'},
            timeout_sec=5
        )
        
        # Создаём тестовый worker
        worker_thread = threading.Thread(
            target=dispatcher._worker_loop,
            args=('test-worker',)
        )
        
        # Запускаем worker на короткое время
        dispatcher.running = True
        worker_thread.daemon = True
        worker_thread.start()
        
        # Даём время на обработку
        time.sleep(0.1)
        dispatcher.running = False
        
        # Проверяем что задача обработана
        task = self.db.get_task(task_id)
        # В зависимости от скорости выполнения может быть completed или running
        self.assertIn(task['status'], ['completed', 'running'])

if __name__ == '__main__':
    unittest.main()
