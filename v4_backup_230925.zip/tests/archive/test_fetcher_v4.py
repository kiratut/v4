#!/usr/bin/env python3
"""
Тесты для VacancyFetcher v4
"""

import unittest
import tempfile
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from plugins.fetcher_v4 import VacancyFetcher, FilterManager, estimate_total_pages

class TestFilterManager(unittest.TestCase):
    """Тесты для FilterManager"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_filters_path = Path(self.temp_dir) / 'test_filters.json'
        
        # Создаём тестовые фильтры
        test_filters = {
            'python-developer': {
                'name': 'Python Developer',
                'text': 'python',
                'area': 1,  # Москва
                'salary': 100000,
                'currency': 'RUR',
                'only_with_salary': True,
                'experience': 'between1And3'
            },
            'java-developer': {
                'name': 'Java Developer',
                'text': 'java',
                'area': 2,  # Санкт-Петербург
                'salary': 120000
            }
        }
        
        with open(self.test_filters_path, 'w', encoding='utf-8') as f:
            json.dump(test_filters, f, ensure_ascii=False, indent=2)
    
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_load_filters(self):
        """Тест загрузки фильтров"""
        filter_manager = FilterManager(self.test_filters_path)
        filters = filter_manager.get_all_filters()
        
        self.assertEqual(len(filters), 2)
        self.assertIn('python-developer', filters)
        self.assertIn('java-developer', filters)
        
        python_filter = filters['python-developer']
        self.assertEqual(python_filter['name'], 'Python Developer')
        self.assertEqual(python_filter['text'], 'python')
        self.assertEqual(python_filter['area'], 1)
    
    def test_get_filter_by_id(self):
        """Тест получения фильтра по ID"""
        filter_manager = FilterManager(self.test_filters_path)
        
        python_filter = filter_manager.get_filter('python-developer')
        self.assertIsNotNone(python_filter)
        self.assertEqual(python_filter['name'], 'Python Developer')
        
        non_existent = filter_manager.get_filter('non-existent')
        self.assertIsNone(non_existent)
    
    def test_build_search_params(self):
        """Тест построения параметров поиска"""
        filter_manager = FilterManager(self.test_filters_path)
        
        params = filter_manager.build_search_params('python-developer', page=5)
        
        expected_params = {
            'text': 'python',
            'area': 1,
            'salary': 100000,
            'currency': 'RUR',
            'only_with_salary': True,
            'experience': 'between1And3',
            'page': 5,
            'per_page': 100
        }
        
        self.assertEqual(params, expected_params)

class TestVacancyFetcher(unittest.TestCase):
    """Тесты для VacancyFetcher"""
    
    def setUp(self):
        """Настройка тестового окружения"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_config = {
            'database': {
                'path': str(Path(self.temp_dir) / 'test.sqlite3')
            },
            'fetcher': {
                'base_url': 'https://api.hh.ru/vacancies',
                'request_delay': 0.1,
                'timeout': 30,
                'max_retries': 2,
                'retry_delay': 1
            }
        }
        
        # Создаём тестовую БД
        from core.task_database import TaskDatabase
        self.db = TaskDatabase()
        self.db.db_path = Path(self.test_config['database']['path'])
        self.db.init_database()
        
    def tearDown(self):
        """Очистка после тестов"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @patch('plugins.fetcher_v4.FilterManager')
    def test_fetcher_init(self, mock_filter_manager):
        """Тест инициализации fetcher"""
        mock_filter_manager.return_value = MagicMock()
        
        fetcher = VacancyFetcher(
            config=self.test_config,
            database=self.db,
            filters_path='/test/filters.json'
        )
        
        self.assertEqual(fetcher.config, self.test_config)
        self.assertEqual(fetcher.database, self.db)
        mock_filter_manager.assert_called_once_with('/test/filters.json')
    
    @patch('requests.get')
    def test_fetch_page_success(self, mock_get):
        """Тест успешной загрузки страницы"""
        # Мокируем ответ HH API
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'items': [
                {
                    'id': '12345',
                    'name': 'Python Developer',
                    'employer': {'name': 'Test Company'},
                    'salary': {'from': 100000, 'to': 150000, 'currency': 'RUR'},
                    'area': {'name': 'Москва'},
                    'published_at': '2025-09-14T10:00:00+03:00',
                    'alternate_url': 'https://hh.ru/vacancy/12345',
                    'snippet': {'responsibility': 'Test responsibility'}
                }
            ],
            'found': 1234,
            'pages': 13,
            'page': 0
        }
        mock_get.return_value = mock_response
        
        filter_manager = MagicMock()
        filter_manager.build_search_params.return_value = {'text': 'python', 'page': 0}
        
        with patch('plugins.fetcher_v4.FilterManager', return_value=filter_manager):
            fetcher = VacancyFetcher(
                config=self.test_config,
                database=self.db,
                filters_path='/test/filters.json'
            )
            
            result = fetcher._fetch_page(
                filter_data={'id': 'test-filter', 'name': 'Test Filter'},
                page=0
            )
        
        self.assertEqual(result['found'], 1234)
        self.assertEqual(result['pages'], 13)
        self.assertEqual(len(result['items']), 1)
        
        # Проверяем что был сделан запрос
        mock_get.assert_called_once()
    
    @patch('requests.get')
    def test_fetch_page_error_handling(self, mock_get):
        """Тест обработки ошибок при загрузке"""
        # Мокируем ошибку 403
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.text = 'Forbidden'
        mock_get.return_value = mock_response
        
        filter_manager = MagicMock()
        filter_manager.build_search_params.return_value = {'text': 'python', 'page': 0}
        
        with patch('plugins.fetcher_v4.FilterManager', return_value=filter_manager):
            fetcher = VacancyFetcher(
                config=self.test_config,
                database=self.db,
                filters_path='/test/filters.json'
            )
            
            result = fetcher._fetch_page(
                filter_data={'id': 'test-filter', 'name': 'Test Filter'},
                page=0
            )
        
        self.assertIsNone(result)
    
    def test_parse_vacancy(self):
        """Тест парсинга вакансии"""
        raw_vacancy = {
            'id': '67890',
            'name': 'Senior Python Developer',
            'employer': {'name': 'Great Company'},
            'salary': {'from': 200000, 'to': 250000, 'currency': 'RUR'},
            'area': {'name': 'Санкт-Петербург'},
            'published_at': '2025-09-14T15:30:00+03:00',
            'alternate_url': 'https://hh.ru/vacancy/67890',
            'snippet': {'responsibility': 'Develop great software', 'requirement': 'Python 3.8+'}
        }
        
        filter_manager = MagicMock()
        
        with patch('plugins.fetcher_v4.FilterManager', return_value=filter_manager):
            fetcher = VacancyFetcher(
                config=self.test_config,
                database=self.db,
                filters_path='/test/filters.json'
            )
            
            parsed = fetcher._parse_vacancy(raw_vacancy, 'test-filter')
        
        self.assertEqual(parsed['hh_id'], '67890')
        self.assertEqual(parsed['title'], 'Senior Python Developer')
        self.assertEqual(parsed['company'], 'Great Company')
        self.assertEqual(parsed['salary_from'], 200000)
        self.assertEqual(parsed['salary_to'], 250000)
        self.assertEqual(parsed['currency'], 'RUR')
        self.assertEqual(parsed['area'], 'Санкт-Петербург')
        self.assertEqual(parsed['filter_id'], 'test-filter')
        self.assertIn('Develop great software', parsed['description'])
    
    @patch('plugins.fetcher_v4.VacancyFetcher._fetch_page')
    def test_load_chunk(self, mock_fetch_page):
        """Тест загрузки chunk'а вакансий"""
        # Мокируем ответ для первой страницы
        mock_fetch_page.return_value = {
            'found': 100,
            'pages': 4,
            'items': [
                {
                    'id': f'vacancy-{i}',
                    'name': f'Job {i}',
                    'employer': {'name': 'Company'},
                    'area': {'name': 'Москва'},
                    'published_at': '2025-09-14T10:00:00+03:00',
                    'alternate_url': f'https://hh.ru/vacancy/vacancy-{i}'
                }
                for i in range(10)  # 10 вакансий на страницу
            ]
        }
        
        filter_manager = MagicMock()
        filter_data = {'id': 'test-filter', 'name': 'Test Filter'}
        filter_manager.get_filter.return_value = filter_data
        
        with patch('plugins.fetcher_v4.FilterManager', return_value=filter_manager):
            fetcher = VacancyFetcher(
                config=self.test_config,
                database=self.db,
                filters_path='/test/filters.json'
            )
            
            result = fetcher.load_chunk(
                filter_id='test-filter',
                max_pages=4,
                chunk_start_page=0,
                chunk_size=4
            )
        
        self.assertIn('loaded_count', result)
        self.assertIn('total_found', result)
        self.assertIn('pages_processed', result)
        self.assertEqual(result['total_found'], 100)
        self.assertEqual(result['pages_processed'], 4)
        
        # Проверяем что было сделано 4 запроса (по количеству страниц)
        self.assertEqual(mock_fetch_page.call_count, 4)

class TestUtilities(unittest.TestCase):
    """Тесты вспомогательных функций"""
    
    def test_estimate_total_pages(self):
        """Тест оценки общего количества страниц"""
        # Типичные значения HH
        self.assertEqual(estimate_total_pages(50), 1)      # 50 вакансий = 1 страница
        self.assertEqual(estimate_total_pages(150), 2)     # 150 вакансий = 2 страницы
        self.assertEqual(estimate_total_pages(1000), 10)   # 1000 вакансий = 10 страниц
        self.assertEqual(estimate_total_pages(2500), 25)   # 2500 вакансий = 25 страниц
        
        # Граничные случаи
        self.assertEqual(estimate_total_pages(0), 0)
        self.assertEqual(estimate_total_pages(100), 1)     # Ровно 100 = 1 страница
        self.assertEqual(estimate_total_pages(101), 2)     # 101 = 2 страницы

if __name__ == '__main__':
    unittest.main()
