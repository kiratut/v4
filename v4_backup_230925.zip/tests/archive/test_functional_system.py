"""
Функциональные тесты системных требований HH-бота v4
Тестируют требования раздела 2 (Функциональные требования)

Автор: AI Assistant  
Дата: 19.09.2025 20:42:00
"""

import pytest
import time
import psutil
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Dict, List

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.database_v3 import VacancyDatabase
from core.models import SystemMonitor, Host2Client, Host3Client


class TestSelfDiagnostics:
    """2.1 - Тесты самодиагностики системы"""
    
    def test_resource_monitoring_critical_thresholds(self):
        """
        2.1.1 Пользовательский тест: Система предупреждает о критических ресурсах
        
        Что пользователь видит:
        ✅ Диск: 45% (норма)  
        ⚠️ Память: 85% (предупреждение)
        ❌ Процессор: 95% (критично)
        """
        monitor = SystemMonitor()
        metrics = monitor.get_system_metrics()
        
        # Проверяем, что метрики получены
        assert 'cpu_percent' in metrics
        assert 'memory_percent' in metrics  
        assert 'disk_usage' in metrics
        
        # Критические пороги из требований
        disk_critical = 90  # >90% критично
        memory_critical = 90  # >90% критично  
        cpu_critical = 95   # >95% критично
        
        # Формируем отчет как для пользователя
        status_report = []
        
        # Проверка диска
        disk_percent = metrics['disk_usage']['percent']
        if disk_percent > disk_critical:
            status_report.append(f"❌ Диск: {disk_percent}% (критично)")
        elif disk_percent > 80:
            status_report.append(f"⚠️ Диск: {disk_percent}% (предупреждение)")
        else:
            status_report.append(f"✅ Диск: {disk_percent}% (норма)")
        
        # Проверка памяти
        memory_percent = metrics['memory_percent']
        if memory_percent > memory_critical:
            status_report.append(f"❌ Память: {memory_percent}% (критично)")
        elif memory_percent > 80:
            status_report.append(f"⚠️ Память: {memory_percent}% (предупреждение)")
        else:
            status_report.append(f"✅ Память: {memory_percent}% (норма)")
        
        # Для тестов устанавливаем менее строгие ограничения
        test_disk_limit = 95
        test_memory_limit = 95
        test_cpu_limit = 98
        
        assert disk_percent < test_disk_limit, f"Диск переполнен: {disk_percent}%"
        assert memory_percent < test_memory_limit, f"Память переполнена: {memory_percent}%"
        
        # Вывод отчета (в реальной системе это будет в UI)
        print("\n📊 Статус ресурсов системы:")
        for line in status_report:
            print(f"   {line}")
    
    def test_service_status_response(self):
        """
        2.1.2 Пользовательский тест: Сервис отвечает и показывает статус
        
        Что пользователь видит:
        🟢 Сервис запущен
        📅 Время запуска: 19.09.2025 15:30
        🔧 Версия: v4.1.0
        ⏱️ Время работы: 4ч 23м
        """
        monitor = SystemMonitor()
        
        # Проверяем базовую информацию о процессе
        process_info = monitor.get_process_info()
        
        assert 'pid' in process_info, "Не удается получить PID процесса"
        assert 'name' in process_info, "Не удается получить имя процесса"
        assert 'status' in process_info, "Не удается получить статус процесса"
        
        # Проверяем uptime
        metrics = monitor.get_system_metrics() 
        uptime_minutes = metrics.get('uptime_minutes', 0)
        
        # Форматируем время работы для пользователя
        hours = int(uptime_minutes // 60)
        minutes = int(uptime_minutes % 60)
        
        # Формируем отчет о статусе
        status_display = [
            "🟢 Сервис запущен",
            f"🆔 PID процесса: {process_info['pid']}",
            f"⏱️ Время работы: {hours}ч {minutes}м",
            f"💾 Использование памяти: {process_info.get('memory_mb', 0):.1f} МБ"
        ]
        
        print("\n🔍 Статус сервиса:")
        for line in status_display:
            print(f"   {line}")
        
        # Проверки для автоматического теста
        assert uptime_minutes >= 0, "Некорректное время работы"
        assert process_info['pid'] > 0, "Некорректный PID"


class TestDatabaseOperations:
    """2.10 - Тесты операций с базой данных"""
    
    @pytest.fixture
    def test_database(self) -> VacancyDatabase:
        """Тестовая база данных"""
        db_path = Path("tests/data/test_db_operations.sqlite3")
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        if db_path.exists():
            db_path.unlink()
        
        db = VacancyDatabase(str(db_path))
        yield db
        
        if db_path.exists():
            db_path.unlink()
    
    def test_database_health_check(self, test_database: VacancyDatabase):
        """
        2.10.1 Технический тест: Диагностика здоровья БД
        
        Что специалист видит:
        ✅ Целостность данных: OK
        ✅ Размер БД: 45.2 МБ  
        ✅ Скорость запросов: 0.03с
        ✅ Свободное место: 15.8 ГБ
        """
        # Проверка подключения
        tables = test_database.get_table_names()
        assert len(tables) > 0, "БД не содержит таблиц"
        
        expected_tables = ['vacancies', 'employers', 'tasks', 'system_stats']
        for table in expected_tables:
            assert table in tables, f"Отсутствует обязательная таблица: {table}"
        
        # Проверка целостности через SQLite PRAGMA
        with test_database.get_connection() as conn:
            cursor = conn.cursor()
            
            # Проверка целостности
            integrity_result = cursor.execute("PRAGMA integrity_check").fetchone()
            assert integrity_result[0] == "ok", f"Нарушена целостность БД: {integrity_result[0]}"
            
            # Получение размера БД
            page_count = cursor.execute("PRAGMA page_count").fetchone()[0]
            page_size = cursor.execute("PRAGMA page_size").fetchone()[0] 
            db_size_bytes = page_count * page_size
            db_size_mb = db_size_bytes / (1024 * 1024)
        
        # Тест скорости запроса
        start_time = time.time()
        stats = test_database.get_stats()
        query_time = time.time() - start_time
        
        # Проверки производительности
        assert query_time < 1.0, f"Медленные запросы: {query_time:.3f}с"
        assert db_size_mb < 100, f"БД слишком большая: {db_size_mb:.1f} МБ"
        
        # Отчет для специалиста
        health_report = {
            "integrity": "OK",
            "size_mb": f"{db_size_mb:.1f}",
            "query_time": f"{query_time:.3f}с",
            "tables_count": len(tables)
        }
        
        print(f"\n🗄️ Здоровье БД: {health_report}")
    
    def test_database_statistics_calculation(self, test_database: VacancyDatabase):
        """
        2.10.6 Пользовательский тест: Расчет понятной статистики
        
        Что пользователь видит:
        📊 Всего вакансий: 1,247
        📅 Сегодня добавлено: 45  
        ⭐ Высокорейтинговых: 123
        📈 Средний рейтинг: 6.7
        """
        # Добавляем тестовые данные
        from core.models import Vacancy
        
        test_vacancies = []
        for i in range(20):
            vacancy = Vacancy(
                hh_id=f"stats_test_{i}",
                title=f"Тестовая вакансия {i}",
                employer_name=f"Компания {i}",
                employer_id=f"emp_{i}",
                relevance_score=5.0 + (i % 5)  # Рейтинги от 5 до 9
            )
            test_database.save_vacancy(vacancy)
            test_vacancies.append(vacancy)
        
        # Получаем статистику
        stats = test_database.get_stats()
        
        # Проверяем базовые метрики
        assert stats['total_vacancies'] >= 20, "Неверный подсчет общего количества"
        assert stats['today_vacancies'] >= 20, "Неверный подсчет сегодняшних вакансий"
        
        # Проверяем расчет среднего рейтинга
        if stats.get('avg_relevance_score'):
            assert 5.0 <= stats['avg_relevance_score'] <= 10.0, "Неверный средний рейтинг"
        
        # Формируем пользовательский отчет
        user_stats = {
            "Всего вакансий": f"{stats['total_vacancies']:,}",
            "Сегодня добавлено": stats['today_vacancies'],
            "Высокорейтинговых": stats.get('relevant_vacancies', 0),
            "Средний рейтинг": f"{stats.get('avg_relevance_score', 0):.1f}",
            "Размер БД": f"{stats.get('db_size_mb', 0)} МБ"
        }
        
        print("\n📊 Статистика вакансий:")
        for key, value in user_stats.items():
            print(f"   {key}: {value}")


class TestStubHostsIntegration:
    """3.1 - Тесты заглушек для Хостов 2 и 3"""
    
    def test_host2_postgresql_stub(self):
        """
        3.1.2 Технический тест: Заглушка PostgreSQL клиента
        
        Проверяет готовность к подключению БД2 в будущем
        """
        # Создаем заглушку Host 2
        host2_client = Host2Client(enabled=False)
        
        assert not host2_client.enabled, "Заглушка должна быть выключена"
        
        # Тестируем методы заглушки
        sync_result = host2_client.sync_vacancies([
            {"id": "test_1", "title": "Test Vacancy 1"},
            {"id": "test_2", "title": "Test Vacancy 2"}
        ])
        
        assert sync_result['status'] == 'skipped', "Заглушка должна пропускать операции"
        assert sync_result['synced'] == 0, "Заглушка не должна обрабатывать данные"
        
        # Тест получения статистики
        stats = host2_client.get_shared_stats()
        assert stats['status'] == 'disabled', "Статус заглушки должен быть disabled"
        
        print("\n🔌 Тест заглушки Host 2 (PostgreSQL):")
        print(f"   Статус: {sync_result['status']}")
        print(f"   Сообщение: {sync_result['message']}")
    
    def test_host3_llm_stub(self):
        """
        3.1.3 Технический тест: Заглушка LLM клиента
        
        Проверяет готовность к LLM интеграции в будущем
        """
        # Создаем заглушку Host 3
        host3_client = Host3Client(enabled=False)
        
        assert not host3_client.enabled, "LLM заглушка должна быть выключена"
        
        # Тест классификации вакансии
        test_vacancy = {
            "title": "Python Developer",
            "description": "Looking for experienced Python developer...",
            "requirements": "3+ years Python, Django, PostgreSQL"
        }
        
        classification_result = host3_client.classify_vacancy(test_vacancy)
        
        assert classification_result['status'] == 'skipped', "Заглушка должна пропускать LLM операции"
        assert classification_result['work_format'] == 'UNKNOWN', "Заглушка не должна определять формат работы"
        
        # Тест генерации письма
        cover_letter_result = host3_client.generate_cover_letter(
            test_vacancy, 
            {"name": "Test User", "experience": "5 years Python"}
        )
        
        assert cover_letter_result['status'] == 'skipped', "Генерация письма должна быть пропущена"
        
        print("\n🤖 Тест заглушки Host 3 (LLM):")
        print(f"   Классификация: {classification_result['status']}")
        print(f"   Генерация письма: {cover_letter_result['status']}")


class TestIntegrationFlow:
    """Тесты интеграции компонентов"""
    
    def test_end_to_end_data_flow(self):
        """
        Интеграционный тест: Полный поток данных от поиска до сохранения
        
        Пользовательский сценарий:
        1. Запуск поиска вакансий ✅
        2. Обработка результатов ✅  
        3. Сохранение в БД ✅
        4. Проверка качества данных ✅
        """
        # Настройка тестового окружения
        db_path = Path("tests/data/test_integration.sqlite3")
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        if db_path.exists():
            db_path.unlink()
        
        try:
            # 1. Инициализация компонентов
            database = VacancyDatabase(str(db_path))
            
            config = {
                "base_url": "https://api.hh.ru",
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            
            # 2. Имитация поиска (без реальных API вызовов для стабильности тестов)
            mock_search_results = [
                {
                    "id": "integration_test_1",
                    "name": "Python Developer Integration Test",
                    "employer": {"id": "emp_int_1", "name": "Integration Test Company"},
                    "salary": {"from": 100000, "to": 150000, "currency": "RUR"},
                    "area": {"name": "Москва"},
                    "published_at": datetime.now().isoformat()
                }
            ]
            
            # 3. Обработка и сохранение
            processed_count = 0
            for vacancy_data in mock_search_results:
                from core.models import Vacancy
                
                vacancy = Vacancy(
                    hh_id=str(vacancy_data["id"]),
                    title=vacancy_data["name"],
                    employer_name=vacancy_data["employer"]["name"],
                    employer_id=str(vacancy_data["employer"]["id"]),
                    salary_from=vacancy_data["salary"]["from"],
                    salary_to=vacancy_data["salary"]["to"],
                    currency=vacancy_data["salary"]["currency"],
                    area_name=vacancy_data["area"]["name"],
                    published_at=vacancy_data["published_at"]
                )
                
                vacancy_id = database.save_vacancy(vacancy)
                if vacancy_id:
                    processed_count += 1
            
            # 4. Проверка результатов
            assert processed_count > 0, "Не обработано ни одной вакансии"
            
            # Проверка сохранения в БД
            stats = database.get_stats()
            assert stats['total_vacancies'] >= processed_count, "Данные не сохранились в БД"
            
            # Проверка целостности сохраненных данных
            saved_vacancy = database.get_vacancy_by_hh_id("integration_test_1")
            assert saved_vacancy is not None, "Вакансия не найдена в БД"
            assert saved_vacancy.title == "Python Developer Integration Test"
            assert saved_vacancy.employer_name == "Integration Test Company"
            
            # Отчет для пользователя
            integration_report = {
                "Найдено вакансий": len(mock_search_results),
                "Обработано успешно": processed_count,
                "Сохранено в БД": stats['total_vacancies'],
                "Статус": "✅ Успешно"
            }
            
            print("\n🔄 Интеграционный тест:")
            for key, value in integration_report.items():
                print(f"   {key}: {value}")
        
        finally:
            # Cleanup
            if db_path.exists():
                db_path.unlink()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
