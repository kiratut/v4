"""
Тесты для HH Tool v4

Этот пакет содержит все тесты для компонентов v4:
- test_task_dispatcher.py - тесты диспетчера задач
- test_task_database.py - тесты базы данных задач
- test_fetcher_v4.py - тесты загрузчика вакансий
- test_cli_v4.py - тесты CLI интерфейса
- test_run_v4.py - тесты скрипта проверки готовности

Для запуска всех тестов:
    python -m pytest tests/

Для запуска конкретного теста:
    python -m pytest tests/test_task_dispatcher.py

Для запуска с покрытием кода:
    python -m pytest --cov=core --cov=plugins tests/
"""
