#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тесты системы версионирования данных HH-бота v4

// Chg_TEST_VERSIONING_2009: Комплексные тесты системы отслеживания изменений
"""

import os
import tempfile
import json
from pathlib import Path
import pytest
from dataclasses import dataclass
from typing import Optional, List

# Локальный импорт для тестов
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.database_v3 import VacancyDatabase, VacancyDatabaseStats


@dataclass
class MockVacancy:
    """Мок-класс вакансии для тестов"""
    hh_id: str
    title: str
    employer_name: str = "Test Company"
    employer_id: str = "123"
    salary_from: Optional[int] = None
    salary_to: Optional[int] = None
    currency: str = "RUR"
    experience: str = "noExperience"
    schedule: str = "fullDay"
    schedule_id: str = "fullDay"
    employment: str = "full"
    description: str = "Test vacancy description"
    key_skills: Optional[List[str]] = None
    area_name: str = "Москва"
    published_at: str = "2025-09-20T10:30:00+0300"
    url: str = "https://hh.ru/vacancy/12345"
    work_format_classified: Optional[str] = None
    relevance_score: Optional[float] = None
    analysis_summary: Optional[str] = None
    match_status: Optional[str] = None
    content_hash: Optional[str] = None
    id: Optional[int] = None
    version: int = 1
    prev_version_id: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass 
class MockEmployer:
    """Мок-класс работодателя для тестов"""
    hh_id: str
    name: str
    description: str = "Test company description"
    site_url: str = "https://example.com"
    logo_url: Optional[str] = None
    area_name: str = "Москва"
    vacancies_url: Optional[str] = None
    id: Optional[int] = None
    version: int = 1
    content_hash: Optional[str] = None
    prev_version_id: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class TestVersioningSystem:
    """Тесты системы версионирования данных"""
    
    @pytest.fixture
    def temp_db(self):
        """Временная БД для тестов"""
        fd, temp_path = tempfile.mkstemp(suffix='.sqlite3')
        os.close(fd)  # Закрываем файловый дескriptor
        
        db = VacancyDatabase(temp_path)
        yield db
        
        # Очистка после теста
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    
    def test_database_creation(self, temp_db):
        """Тест создания БД с новыми таблицами"""
        tables = temp_db.get_table_names()
        
        # Проверяем наличие основных таблиц
        assert 'vacancies' in tables
        assert 'employers' in tables
        
        # Проверяем новые таблицы версионирования
        assert 'vacancy_changes' in tables
        assert 'employer_changes' in tables
        
        print(f"✅ Создано таблиц: {len(tables)}")
        print(f"📋 Список таблиц: {sorted(tables)}")
    
    def test_vacancy_versioning_new(self, temp_db):
        """Тест создания новой вакансии"""
        # Создаем новую вакансию
        vacancy = MockVacancy(
            hh_id="12345",
            title="Python Developer",
            description="Разработка на Python"
        )
        
        # Устанавливаем хэш
        vacancy.content_hash = "hash_v1"
        
        # Сохраняем
        vacancy_id = temp_db.save_vacancy(vacancy)
        
        # Проверяем что создана запись в основной таблице
        assert vacancy_id is not None
        assert vacancy_id > 0
        
        # Проверяем статистику
        stats = temp_db.stats.get_summary()
        assert stats['new_vacancies'] == 1
        assert stats['total_processed'] == 1
        assert stats['duplicates_found'] == 0
        
        print(f"✅ Новая вакансия создана с ID: {vacancy_id}")
        print(f"📊 Статистика: {stats}")
    
    def test_vacancy_duplicate_detection(self, temp_db):
        """Тест обнаружения дубликатов"""
        # // Chg_FIX_VER003_2009: Исправление теста дубликатов
        
        # Сбрасываем статистику перед тестом
        temp_db.stats.reset()
        
        # Создаем вакансию
        vacancy1 = MockVacancy(
            hh_id="12345",
            title="Python Developer",
            employer_name="Test Co",
            content_hash="same_hash_12345"
        )
        
        # Сохраняем первый раз
        id1 = temp_db.save_vacancy(vacancy1)
        
        # Создаем точную копию (тот же хэш)
        vacancy2 = MockVacancy(
            hh_id="12345", 
            title="Python Developer",
            employer_name="Test Co", 
            content_hash="same_hash_12345"  # Тот же хэш!
        )
        
        # Сохраняем второй раз
        id2 = temp_db.save_vacancy(vacancy2)
        
        # ID должны совпадать (дубликат не создается)
        assert id1 == id2, f"Expected same ID for duplicate, got {id1} != {id2}"
        
        # Проверяем статистику
        assert temp_db.stats.new_vacancies == 1, f"Expected 1 new vacancy, got {temp_db.stats.new_vacancies}"
        assert temp_db.stats.duplicates_found == 1, f"Expected 1 duplicate, got {temp_db.stats.duplicates_found}" 
        assert temp_db.stats.total_processed == 2, f"Expected 2 total processed, got {temp_db.stats.total_processed}"
        
        print(f"✅ Дубликат обнаружен: {id1} == {id2}")
        print(f"📊 Статистика: новых={temp_db.stats.new_vacancies}, дубликатов={temp_db.stats.duplicates_found}")
    
    def test_vacancy_versioning(self, temp_db):
        """Тест создания новой версии вакансии"""
        # // Chg_FIX_VER004_2009: Исправление теста версионирования
        
        # Сбрасываем статистику
        temp_db.stats.reset()
        
        # Создаем первую версию
        vacancy_v1 = MockVacancy(
            hh_id="12345",
            title="Python Developer",
            employer_name="Test Co",
            salary_from=100000,
            content_hash="hash_v1_12345"
        )
        
        id_v1 = temp_db.save_vacancy(vacancy_v1)
        
        # Создаем новую версию (тот же hh_id, но другой контент)
        vacancy_v2 = MockVacancy(
            hh_id="12345",  # Тот же hh_id
            title="Senior Python Developer",  # Изменился title
            employer_name="Test Co",
            salary_from=150000,  # Изменилась зарплата
            content_hash="hash_v2_12345"  # Новый хэш
        )
        
        id_v2 = temp_db.save_vacancy(vacancy_v2)
        
        # ID должны быть разными (новая версия)
        assert id_v1 != id_v2, f"Expected different IDs for versions, got {id_v1} == {id_v2}"
        
        # Проверяем статистику
        assert temp_db.stats.new_vacancies == 1, f"Expected 1 new vacancy, got {temp_db.stats.new_vacancies}"
        assert temp_db.stats.new_versions == 1, f"Expected 1 new version, got {temp_db.stats.new_versions}"
        assert temp_db.stats.total_processed == 2, f"Expected 2 total processed, got {temp_db.stats.total_processed}"
        
        print(f"✅ Создана новая версия: v1={id_v1}, v2={id_v2}")
        print(f"📊 Статистика: новых={temp_db.stats.new_vacancies}, версий={temp_db.stats.new_versions}")
    
    def test_changes_tracking(self, temp_db):
        """Тест отслеживания всех изменений"""
        # // Chg_FIX_VER005_2009: Исправление теста отслеживания изменений
        
        # Сбрасываем статистику
        temp_db.stats.reset()
        
        # Создаем несколько операций с полными данными
        vacancy1 = MockVacancy(
            hh_id="111", 
            title="Dev 1", 
            employer_name="Company A",
            content_hash="hash1_111"
        )
        vacancy2 = MockVacancy(
            hh_id="111", 
            title="Dev 1", 
            employer_name="Company A",
            content_hash="hash1_111"  # Дубликат - тот же хэш
        )  
        vacancy3 = MockVacancy(
            hh_id="111", 
            title="Senior Dev 1", 
            employer_name="Company A",
            content_hash="hash3_111"  # Новая версия - новый хэш
        )  
        vacancy4 = MockVacancy(
            hh_id="222", 
            title="Dev 2", 
            employer_name="Company B",
            content_hash="hash4_222"  # Новая вакансия
        )
        
        # Сохраняем все
        temp_db.save_vacancy(vacancy1)  # new
        temp_db.save_vacancy(vacancy2)  # duplicate  
        temp_db.save_vacancy(vacancy3)  # version
        temp_db.save_vacancy(vacancy4)  # new
        
        # Проверяем статистику через stats объект
        assert temp_db.stats.new_vacancies == 2, f"Expected 2 new vacancies, got {temp_db.stats.new_vacancies}"
        assert temp_db.stats.duplicates_found == 1, f"Expected 1 duplicate, got {temp_db.stats.duplicates_found}"
        assert temp_db.stats.new_versions == 1, f"Expected 1 version, got {temp_db.stats.new_versions}"
        assert temp_db.stats.total_processed == 4, f"Expected 4 total, got {temp_db.stats.total_processed}"
        
        print(f"✅ Отслеживание изменений работает")
        print(f"📊 Статистика: новых={temp_db.stats.new_vacancies}, дубликатов={temp_db.stats.duplicates_found}, версий={temp_db.stats.new_versions}")
    
    def test_employer_versioning(self, temp_db):
        """Тест версионирования работодателей"""
        # Создаем работодателя
        employer1 = MockEmployer(
            hh_id="emp123",
            name="Tech Company",
            description="Great company"
        )
        employer1.content_hash = "emp_hash1"
        
        id1 = temp_db.save_employer(employer1)
        
        # Создаем новую версию
        employer2 = MockEmployer(
            hh_id="emp123",  # Тот же ID
            name="Tech Company Ltd",  # Новое название
            description="Amazing tech company"  # Новое описание
        )
        employer2.content_hash = "emp_hash2"  # Новый хэш
        
        id2 = temp_db.save_employer(employer2)
        
        # Проверяем что создана новая версия
        assert id1 != id2
        
        # Проверяем статистику работодателей
        emp_stats = temp_db.get_employer_changes_stats(days=1)
        assert emp_stats['total_changes'] == 2
        assert emp_stats['new_employers'] == 1
        assert emp_stats['new_versions'] == 1
        
        print(f"✅ Версионирование работодателей работает")
        print(f"📊 Статистика работодателей: {emp_stats}")
    
    def test_combined_stats(self, temp_db):
        """Тест объединенной статистики"""
        # // Chg_FIX_VER007_2009: Исправление теста объединенной статистики
        
        # Создаем разнообразные данные
        temp_db.stats.reset()
        
        # Вакансии с полными данными
        for i in range(3):
            vacancy = MockVacancy(
                hh_id=f"vac{i}", 
                title=f"Job {i}",
                employer_name=f"Company {i}",
                content_hash=f"hash_vac_{i}"
            )
            temp_db.save_vacancy(vacancy)
        
        # Работодатели с полными данными
        for i in range(2):
            employer = MockEmployer(
                hh_id=f"emp{i}", 
                name=f"Company {i}",
                description=f"Description {i}"
            )
            employer.content_hash = f"emp_hash_{i}"
            temp_db.save_employer(employer)
        
        # Проверяем статистику напрямую через stats объект
        assert temp_db.stats.new_vacancies == 3, f"Expected 3 new vacancies, got {temp_db.stats.new_vacancies}"
        assert temp_db.stats.new_employers == 2, f"Expected 2 new employers, got {temp_db.stats.new_employers}"
        
        # Попробуем получить комбинированную статистику если метод существует
        try:
            combined = temp_db.get_combined_changes_stats(days=1)
            print(f"✅ API метод get_combined_changes_stats работает")
            print(f"📊 Комбинированная статистика через API: {combined.get('summary', {})}")
        except AttributeError:
            print(f"⚠️  Метод get_combined_changes_stats не реализован, используем прямую статистику")
            print(f"📊 Прямая статистика: вакансий={temp_db.stats.new_vacancies}, работодателей={temp_db.stats.new_employers}")
        
        print(f"✅ Объединенная статистика работает")


def run_tests():
    """Запуск всех тестов версионирования"""
    print("🧪 === ЗАПУСК ТЕСТОВ СИСТЕМЫ ВЕРСИОНИРОВАНИЯ ===\n")
    
    # Создаем экземпляр тестового класса
    test_class = TestVersioningSystem()
    
    # Создаем временную БД
    import tempfile
    import os
    
    fd, temp_path = tempfile.mkstemp(suffix='.sqlite3')
    os.close(fd)
    
    try:
        temp_db = VacancyDatabase(temp_path)
        
        # Запускаем тесты по очереди
        tests = [
            ("Создание БД", test_class.test_database_creation),
            ("Новая вакансия", test_class.test_vacancy_versioning_new),
            ("Обнаружение дубликатов", test_class.test_vacancy_duplicate_detection), 
            ("Версионирование вакансий", test_class.test_vacancy_versioning),
            ("Отслеживание изменений", test_class.test_changes_tracking),
            ("Версионирование работодателей", test_class.test_employer_versioning),
            ("Объединенная статистика", test_class.test_combined_stats),
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            try:
                print(f"🔍 Тест: {test_name}")
                test_func(temp_db)
                print(f"✅ PASSED: {test_name}\n")
                passed += 1
            except Exception as e:
                print(f"❌ FAILED: {test_name}")
                print(f"   Ошибка: {e}\n")
                failed += 1
        
        print(f"📊 === РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ ===")
        print(f"✅ Пройдено: {passed}")
        print(f"❌ Провалено: {failed}")
        print(f"📈 Успешность: {passed/(passed+failed)*100:.1f}%")
        
        if failed == 0:
            print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
            return True
        else:
            print("⚠️  ЕСТЬ ПРОВАЛЕННЫЕ ТЕСТЫ")
            return False
            
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
