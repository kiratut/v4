#!/usr/bin/env python3
"""
Тесты для скрипта run_v4.py
"""

import unittest
import tempfile
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent))

import run_v4

class TestRunV4Dependencies(unittest.TestCase):
    """Тесты проверки зависимостей"""
    
    def test_check_dependencies_success(self):
        """Тест успешной проверки зависимостей"""
        with patch('importlib.import_module') as mock_import:
            mock_import.return_value = MagicMock()
            
            result = run_v4.check_dependencies()
            
            self.assertTrue(result)
    
    def test_check_dependencies_missing(self):
        """Тест при отсутствии зависимостей"""
        with patch('importlib.import_module') as mock_import:
            mock_import.side_effect = ImportError("Module not found")
            
            with patch('builtins.print') as mock_print:
                result = run_v4.check_dependencies()
                
                self.assertFalse(result)
                mock_print.assert_called()

class TestRunV4Configuration(unittest.TestCase):
    """Тесты проверки конфигурации"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_check_config_files_success(self):
        """Тест успешной проверки конфигурационных файлов"""
        # Создаём тестовые файлы
        config_path = Path(self.temp_dir) / 'config.json'
        filters_path = Path(self.temp_dir) / 'filters.json'
        
        config_path.write_text('{"database": {"path": "test.db"}}')
        filters_path.write_text('{"test-filter": {"name": "Test"}}')
        
        with patch('run_v4.CONFIG_PATH', config_path):
            with patch('run_v4.FILTERS_PATH', filters_path):
                result = run_v4.check_config_files()
                
                self.assertTrue(result)
    
    def test_check_config_files_missing(self):
        """Тест при отсутствии конфигурационных файлов"""
        missing_path = Path(self.temp_dir) / 'missing.json'
        
        with patch('run_v4.CONFIG_PATH', missing_path):
            with patch('builtins.print') as mock_print:
                result = run_v4.check_config_files()
                
                self.assertFalse(result)
                mock_print.assert_called()

class TestRunV4Directories(unittest.TestCase):
    """Тесты создания директорий"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_create_directories_success(self):
        """Тест успешного создания директорий"""
        data_dir = Path(self.temp_dir) / 'data'
        logs_dir = Path(self.temp_dir) / 'logs'
        
        with patch('run_v4.DATA_DIR', data_dir):
            with patch('run_v4.LOGS_DIR', logs_dir):
                result = run_v4.create_directories()
                
                self.assertTrue(result)
                self.assertTrue(data_dir.exists())
                self.assertTrue(logs_dir.exists())

class TestRunV4Database(unittest.TestCase):
    """Тесты проверки базы данных"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.temp_dir) / 'test.sqlite3'
        
    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @patch('run_v4.TaskDatabase')
    def test_check_database_success(self, mock_db_class):
        """Тест успешной проверки БД"""
        mock_db = MagicMock()
        mock_db.init_database.return_value = None
        mock_db.get_stats.return_value = {'tasks': {'total': 0}}
        mock_db_class.return_value = mock_db
        
        result = run_v4.check_database()
        
        self.assertTrue(result)
        mock_db.init_database.assert_called_once()
        mock_db.get_stats.assert_called_once()
    
    @patch('run_v4.TaskDatabase')
    def test_check_database_error(self, mock_db_class):
        """Тест ошибки при проверке БД"""
        mock_db_class.side_effect = Exception("DB Error")
        
        with patch('builtins.print') as mock_print:
            result = run_v4.check_database()
            
            self.assertFalse(result)
            mock_print.assert_called()

class TestRunV4Dispatcher(unittest.TestCase):
    """Тесты проверки диспетчера"""
    
    @patch('run_v4.TaskDispatcher')
    def test_check_dispatcher_success(self, mock_dispatcher_class):
        """Тест успешной проверки диспетчера"""
        mock_dispatcher = MagicMock()
        mock_dispatcher.add_task.return_value = 'test-task-id'
        mock_dispatcher.get_status.return_value = {
            'workers_count': 0,
            'queue_size': 1,
            'running': False
        }
        mock_dispatcher_class.return_value = mock_dispatcher
        
        result = run_v4.check_dispatcher()
        
        self.assertTrue(result)
        mock_dispatcher.add_task.assert_called_once()
        mock_dispatcher.get_status.assert_called_once()
    
    @patch('run_v4.TaskDispatcher')
    def test_check_dispatcher_error(self, mock_dispatcher_class):
        """Тест ошибки при проверке диспетчера"""
        mock_dispatcher_class.side_effect = Exception("Dispatcher Error")
        
        with patch('builtins.print') as mock_print:
            result = run_v4.check_dispatcher()
            
            self.assertFalse(result)
            mock_print.assert_called()

class TestRunV4Integration(unittest.TestCase):
    """Интеграционные тесты run_v4"""
    
    @patch('run_v4.check_dependencies')
    @patch('run_v4.check_config_files') 
    @patch('run_v4.create_directories')
    @patch('run_v4.check_database')
    @patch('run_v4.check_dispatcher')
    def test_main_all_success(self, mock_dispatcher, mock_database, 
                             mock_directories, mock_config, mock_deps):
        """Тест успешного выполнения всех проверок"""
        # Все проверки успешны
        mock_deps.return_value = True
        mock_config.return_value = True
        mock_directories.return_value = True
        mock_database.return_value = True
        mock_dispatcher.return_value = True
        
        with patch('builtins.print') as mock_print:
            result = run_v4.main()
            
            self.assertEqual(result, 0)
            # Проверяем что все функции вызывались
            mock_deps.assert_called_once()
            mock_config.assert_called_once()
            mock_directories.assert_called_once()
            mock_database.assert_called_once()
            mock_dispatcher.assert_called_once()
    
    @patch('run_v4.check_dependencies')
    @patch('run_v4.check_config_files')
    def test_main_early_failure(self, mock_config, mock_deps):
        """Тест раннего завершения при неудачной проверке"""
        # Первая проверка неуспешна
        mock_deps.return_value = False
        mock_config.return_value = True
        
        with patch('builtins.print') as mock_print:
            result = run_v4.main()
            
            self.assertNotEqual(result, 0)
            mock_deps.assert_called_once()
            # Вторая проверка не должна вызываться
            mock_config.assert_not_called()

if __name__ == '__main__':
    unittest.main()
