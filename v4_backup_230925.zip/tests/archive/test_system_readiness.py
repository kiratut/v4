"""
Система автоматических тестов для проверки готовности HH-бота v4

Этот модуль содержит комплексные тесты для валидации готовности системы
к работе, включая проверку всех критических компонентов.

Использование:
    python -m pytest tests/test_system_readiness.py -v
    python cli_v4.py test --suite readiness

Автор: AI Assistant
Дата: 19.09.2025 17:31:00
"""

import pytest
import sqlite3
import json
import os
import sys
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

# Добавляем корневую папку в path для импортов
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.database_v3 import VacancyDatabase
from core.models import Vacancy, Employer
from plugins.fetcher_v4 import VacancyFetcher


class TestSystemReadiness:
    """Основной класс тестов готовности системы"""
    
    @pytest.fixture(scope="class")
    def test_db_path(self) -> Path:
        """Путь к тестовой базе данных"""
        return Path("tests/data/test_readiness.sqlite3")
    
    @pytest.fixture(scope="class")
    def test_config(self) -> Dict:
        """Тестовая конфигурация"""
        return {
            "database": {
                "path": "tests/data/test_readiness.sqlite3",
                "timeout": 30,
                "check_same_thread": False
            },
            "api": {
                "base_url": "https://api.hh.ru",
                "timeout": 30,
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            "paths": {
                "data": "data",
                "logs": "logs",
                "config": "config"
            }
        }
    
    @pytest.fixture(scope="class")
    def database(self, test_db_path: Path, test_config: Dict) -> VacancyDatabase:
        """Инициализированная тестовая база данных"""
        # Создаем директорию если нужно
        test_db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Удаляем старую БД если есть
        if test_db_path.exists():
            test_db_path.unlink()
        
        db = VacancyDatabase(str(test_db_path))
        yield db
        
        # Cleanup после тестов
        if test_db_path.exists():
            test_db_path.unlink()


class TestDatabaseVersioning(TestSystemReadiness):
    """Тесты версионирования базы данных"""
    
    def test_01_database_schema_created(self, database: VacancyDatabase):
        """Проверка создания схемы БД с поддержкой версионирования"""
        # Проверяем наличие всех необходимых таблиц
        tables = database.get_table_names()
        required_tables = ['vacancies', 'employers', 'tasks', 'system_stats']
        
        for table in required_tables:
            assert table in tables, f"Отсутствует таблица {table}"
    
    def test_02_vacancy_versioning_fields(self, database: VacancyDatabase):
        """Проверка полей версионирования в таблице вакансий"""
        schema = database.get_table_schema('vacancies')
        
        required_fields = ['version', 'content_hash', 'prev_version_id']
        for field in required_fields:
            assert field in schema, f"Отсутствует поле версионирования {field}"
    
    def test_03_content_hash_calculation(self, database: VacancyDatabase):
        """Проверка корректности расчета content_hash"""
        # Тестовые данные вакансии
        vacancy_data = {
            'hh_id': 'test_123',
            'title': 'Python Developer',
            'description': 'Test description',
            'salary_from': 100000,
            'salary_to': 150000,
            'salary_currency': 'RUR',
            'employer_id': 'emp_123'
        }
        
        # Создаем вакансию
        vacancy = Vacancy(**vacancy_data)
        content_hash = database.calculate_content_hash(vacancy)
        
        # Проверяем, что хэш генерируется и имеет правильный формат
        assert content_hash is not None
        assert len(content_hash) == 64  # SHA256
        assert isinstance(content_hash, str)
        
        # Проверяем детерминизм - одинаковые данные = одинаковый хэш
        content_hash2 = database.calculate_content_hash(vacancy)
        assert content_hash == content_hash2
    
    def test_04_vacancy_deduplication(self, database: VacancyDatabase):
        """Проверка дедупликации вакансий"""
        vacancy_data = {
            'hh_id': 'test_dedup_123',
            'title': 'Python Developer',
            'description': 'Test description',
            'salary_from': 100000,
            'salary_to': 150000,
            'salary_currency': 'RUR',
            'employer_id': 'emp_123'
        }
        
        # Сохраняем первую версию
        vacancy1 = Vacancy(**vacancy_data)
        id1 = database.save_vacancy(vacancy1)
        assert id1 is not None
        
        # Сохраняем идентичную вакансию - должна вернуться та же запись
        vacancy2 = Vacancy(**vacancy_data)
        id2 = database.save_vacancy(vacancy2)
        assert id2 == id1, "Идентичные вакансии должны дедуплицироваться"
        
        # Изменяем данные и сохраняем - должна создаться новая версия
        vacancy_data['title'] = 'Senior Python Developer'
        vacancy3 = Vacancy(**vacancy_data)
        id3 = database.save_vacancy(vacancy3)
        assert id3 != id1, "Измененная вакансия должна создать новую версию"


class TestAPIIntegration(TestSystemReadiness):
    """Тесты интеграции с API"""
    
    def test_01_api_client_initialization(self, test_config: Dict):
        """Проверка инициализации API клиента"""
        fetcher = VacancyFetcher(test_config['api'])
        assert fetcher is not None
        assert fetcher.base_url == test_config['api']['base_url']
    
    def test_02_api_auth_headers(self, test_config: Dict):
        """Проверка заголовков авторизации"""
        fetcher = VacancyFetcher(test_config['api'])
        headers = fetcher.get_headers()
        
        # Проверяем обязательные заголовки
        assert 'User-Agent' in headers
        assert headers['User-Agent'] == test_config['api']['user_agent']
    
    @pytest.mark.integration
    def test_03_api_connectivity(self, test_config: Dict):
        """Проверка подключения к API (интеграционный тест)"""
        fetcher = VacancyFetcher(test_config['api'])
        
        # Простой запрос на получение вакансий (лимит 1)
        try:
            response = fetcher.search_vacancies(text="python", per_page=1)
            assert response is not None
            assert 'items' in response
        except Exception as e:
            pytest.skip(f"API недоступен: {e}")


class TestCLIInterface(TestSystemReadiness):
    """Тесты CLI интерфейса"""
    
    def test_01_cli_import(self):
        """Проверка импорта CLI модуля"""
        try:
            import cli_v4
            assert hasattr(cli_v4, 'cli')
        except ImportError as e:
            pytest.fail(f"Не удается импортировать CLI: {e}")
    
    def test_02_cli_commands_available(self):
        """Проверка доступности основных CLI команд"""
        import cli_v4
        
        # Получаем список команд из CLI
        commands = [cmd.name for cmd in cli_v4.cli.commands.values()]
        
        required_commands = ['start', 'status', 'stop', 'migrate', 'export']
        for cmd in required_commands:
            assert cmd in commands, f"Отсутствует CLI команда {cmd}"


class TestFileSystemStructure(TestSystemReadiness):
    """Тесты структуры файловой системы"""
    
    def test_01_required_directories(self):
        """Проверка наличия обязательных директорий"""
        base_path = Path(__file__).parent.parent
        required_dirs = ['core', 'plugins', 'config', 'data', 'logs', 'tests', 'web']
        
        for dir_name in required_dirs:
            dir_path = base_path / dir_name
            assert dir_path.exists(), f"Отсутствует директория {dir_name}"
    
    def test_02_config_files_structure(self):
        """Проверка структуры конфигурационных файлов"""
        config_path = Path(__file__).parent.parent / 'config'
        
        config_files = ['config_v4.json', 'filters.json']
        for config_file in config_files:
            file_path = config_path / config_file
            assert file_path.exists(), f"Отсутствует конфиг {config_file}"
            
            # Проверяем, что это валидный JSON
            with open(file_path, 'r', encoding='utf-8') as f:
                try:
                    json.load(f)
                except json.JSONDecodeError:
                    pytest.fail(f"Невалидный JSON в {config_file}")
    
    def test_03_cross_platform_paths(self):
        """Проверка кроссплатформенной работы путей"""
        from core.models import PathManager
        
        path_mgr = PathManager()
        
        # Проверяем, что пути корректно создаются для текущей ОС
        data_path = path_mgr.get_data_path("test_file.txt")
        assert isinstance(data_path, Path)
        
        config_path = path_mgr.get_config_path("test_config.json")
        assert isinstance(config_path, Path)


class TestStubHosts(TestSystemReadiness):
    """Тесты заглушек для Хостов 2 и 3"""
    
    def test_01_host2_stub_client(self):
        """Проверка заглушки клиента для Хоста 2 (PostgreSQL)"""
        from core.models import Host2Client
        
        client = Host2Client(enabled=False)
        assert not client.enabled
        
        # Методы заглушки должны возвращать пустые результаты
        result = client.sync_vacancies([])
        assert result is not None
        assert isinstance(result, dict)
    
    def test_02_host3_stub_client(self):
        """Проверка заглушки клиента для Хоста 3 (LLM)"""
        from core.models import Host3Client
        
        client = Host3Client(enabled=False)
        assert not client.enabled
        
        # Методы заглушки должны возвращать пустые результаты
        result = client.classify_vacancy({})
        assert result is not None


class TestSystemIntegration(TestSystemReadiness):
    """Интеграционные тесты системы"""
    
    def test_01_end_to_end_vacancy_processing(self, database: VacancyDatabase, test_config: Dict):
        """Сквозной тест обработки вакансии"""
        # 1. Создаем тестовую вакансию
        vacancy_data = {
            'hh_id': 'e2e_test_123',
            'title': 'Test Developer',
            'description': 'End-to-end test vacancy',
            'salary_from': 80000,
            'salary_to': 120000,
            'salary_currency': 'RUR',
            'employer_id': 'emp_e2e'
        }
        
        vacancy = Vacancy(**vacancy_data)
        
        # 2. Сохраняем в БД
        vacancy_id = database.save_vacancy(vacancy)
        assert vacancy_id is not None
        
        # 3. Читаем из БД
        saved_vacancy = database.get_vacancy_by_id(vacancy_id)
        assert saved_vacancy is not None
        assert saved_vacancy.hh_id == vacancy_data['hh_id']
        
        # 4. Проверяем версионирование
        assert saved_vacancy.version == 1
        assert saved_vacancy.content_hash is not None
    
    def test_02_system_metrics_collection(self):
        """Проверка сбора системных метрик"""
        from core.models import SystemMonitor
        
        monitor = SystemMonitor()
        metrics = monitor.get_system_metrics()
        
        required_metrics = ['cpu_percent', 'memory_percent', 'disk_usage', 'timestamp']
        for metric in required_metrics:
            assert metric in metrics, f"Отсутствует метрика {metric}"


def run_readiness_tests() -> Dict[str, bool]:
    """
    Запускает все тесты готовности и возвращает результаты
    
    Returns:
        Dict[str, bool]: Результаты тестов по категориям
    """
    results = {
        'database_versioning': False,
        'api_integration': False,
        'cli_interface': False,
        'file_structure': False,
        'stub_hosts': False,
        'system_integration': False
    }
    
    try:
        # Запускаем pytest программно
        import subprocess
        test_file = __file__
        
        # Тестируем каждую категорию отдельно
        test_classes = {
            'database_versioning': 'TestDatabaseVersioning',
            'api_integration': 'TestAPIIntegration',
            'cli_interface': 'TestCLIInterface',
            'file_structure': 'TestFileSystemStructure',
            'stub_hosts': 'TestStubHosts',
            'system_integration': 'TestSystemIntegration'
        }
        
        for category, test_class in test_classes.items():
            cmd = [
                sys.executable, '-m', 'pytest',
                f"{test_file}::{test_class}",
                '-v', '--tb=short'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            results[category] = (result.returncode == 0)
            
    except Exception as e:
        print(f"Ошибка при запуске тестов: {e}")
    
    return results


if __name__ == "__main__":
    """Прямой запуск тестов"""
    print("🧪 Запуск системы автоматических тестов готовности HH-бота v4")
    print("=" * 60)
    
    results = run_readiness_tests()
    
    print("\n📊 Результаты тестов:")
    print("-" * 30)
    
    all_passed = True
    for category, passed in results.items():
        status = "✅ ПРОЙДЕН" if passed else "❌ ПРОВАЛЕН"
        print(f"{category:20s}: {status}")
        if not passed:
            all_passed = False
    
    print("-" * 30)
    overall_status = "🎉 ВСЕ ТЕСТЫ ПРОШЛИ" if all_passed else "⚠️  ЕСТЬ ПРОБЛЕМЫ"
    print(f"Общий статус: {overall_status}")
    
    if not all_passed:
        print("\n🔧 Запустите pytest с -v для детальной диагностики")
        sys.exit(1)
    else:
        print("\n🚀 Система готова к работе!")
        sys.exit(0)
