#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Пайплайн функциональных тестов HH-бота v4

// Chg_FUNC_TESTS_2009: Автоматизация запуска функциональных тестов с отчетом
Решает проблемы с кодировкой Windows и длинным выводом в терминале
"""

import sys
import os
import json
import time
import traceback
import logging
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

# Настройка кодировки для Windows
if sys.platform.startswith('win'):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Добавляем путь к проекту
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


@dataclass
class TestResult:
    """Результат выполнения теста"""
    test_id: str
    name: str
    status: str  # PASS, FAIL, SKIP, PARTIAL
    duration: float
    message: str
    details: Optional[str] = None
    category: str = "functional"


class FunctionalTestRunner:
    """Запускает функциональные тесты по спецификации"""
    
    def __init__(self):
        self.results: List[TestResult] = []
        self.start_time = time.time()

    def _add_result(self, test_id: str, name: str, status: str, message: str, duration: float, details: Optional[str] = None, category: str = "functional"):
        self.results.append(TestResult(
            test_id=test_id,
            name=name,
            status=status,
            duration=duration,
            message=message,
            details=details,
            category=category
        ))

    def _generate_report(self, verbose: bool = False) -> Dict[str, Any]:
        total_time = time.time() - self.start_time
        stats = {
            'total': len(self.results),
            'passed': len([r for r in self.results if r.status == 'PASS']),
            'failed': len([r for r in self.results if r.status == 'FAIL']),
            'partial': len([r for r in self.results if r.status == 'PARTIAL']),
            'skipped': len([r for r in self.results if r.status == 'SKIP']),
        }
        success_rate = (stats['passed'] / stats['total'] * 100) if stats['total'] > 0 else 0

        # Краткий вывод
        print()
        print("📊 === ИТОГИ ТЕСТИРОВАНИЯ ===")
        print(f"⏱️  Общее время: {total_time:.2f}s")
        print(f"📈 Успешность: {success_rate:.1f}%")
        print()
        print(f"✅ Пройдено: {stats['passed']}")
        print(f"❌ Провалено: {stats['failed']}")
        print(f"⚠️  Частично: {stats['partial']}")
        print(f"⏸️  Пропущено: {stats['skipped']}")
        print(f"📊 Всего: {stats['total']}")

        if verbose and stats['failed'] > 0:
            print()
            print("❌ ПРОВАЛЕННЫЕ ТЕСТЫ:")
            for r in self.results:
                if r.status == 'FAIL':
                    print(f"  • {r.test_id}: {r.name} - {r.message}")

        # // Chg_TEST_LOG_2109: логируем завершение функциональных тестов
        try:
            root = logging.getLogger()
            if not root.handlers:
                os.makedirs('logs', exist_ok=True)
                fh = logging.FileHandler('logs/app.log', encoding='utf-8')
                fh.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
                root.addHandler(fh)
                root.setLevel(logging.INFO)
            logging.info(f"functional_tests_finish success_rate={success_rate:.1f} passed={stats['passed']}/{stats['total']}")
        except Exception:
            pass

        return {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'duration': total_time,
            'statistics': stats,
            'success_rate': success_rate,
            'results': [
                {
                    'id': r.test_id,
                    'name': r.name,
                    'status': r.status,
                    'duration': r.duration,
                    'message': r.message
                }
                for r in self.results
            ]
        }
        
    def run_all_tests(self, verbose: bool = False) -> Dict[str, Any]:
        """Запускает все функциональные тесты"""
        print("🧪 === ФУНКЦИОНАЛЬНЫЕ ТЕСТЫ HH-БОТА v4 ===")
        print(f"⏰ Начало: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # 1. Тесты базовой системы
        self._run_system_tests()
        
        # 2. Тесты версионирования
        self._run_versioning_tests()
        
        # 3. Тесты API интеграции
        self._run_api_tests()
        
        # 4. Тесты производительности (быстрые)
        self._run_performance_tests()
        
        # 5. Тесты демона планировщика
        self._run_daemon_tests()
        
        # Генерируем отчет
        return self._generate_report(verbose)
    
    def _run_system_tests(self):
        """Базовые системные тесты"""
        print("📦 [1/4] Системные тесты...")
        
        # Тест 1.1: Создание БД
        import uuid
        import tempfile
        
        try:
            from core.database_v3 import VacancyDatabase
            # // Chg_FIX_TESTS_2009: Уникальные пути для каждого теста 
            unique_id = uuid.uuid4().hex[:8]
            temp_dir = tempfile.gettempdir()
            test_db_path = os.path.join(temp_dir, f'test_sys_{unique_id}.sqlite3')
            
            db = VacancyDatabase(test_db_path)
            tables = db.get_table_names()
            
            if len(tables) >= 7:  # Минимум ожидаемых таблиц
                self._add_result("SYS001", "Database Creation", "PASS", 
                               f"Created {len(tables)} tables", 0.1)
            else:
                self._add_result("SYS001", "Database Creation", "FAIL", 
                               f"Only {len(tables)} tables created", 0.1)
                               
            # Принудительная очистка
            db._conn = None  # Закрываем соединение
            time.sleep(0.1)  # Небольшая задержка для Windows
            
            try:
                if os.path.exists(test_db_path):
                    os.remove(test_db_path)
            except Exception as cleanup_error:
                print(f"  Warning: Could not cleanup {test_db_path}: {cleanup_error}")
                
        except Exception as e:
            self._add_result("SYS001", "Database Creation", "FAIL", str(e), 0.1)
        
        # Тест 1.2: CLI команды
        try:
            import subprocess
            result = subprocess.run([
                sys.executable, 'cli_v4.py', 'stats', '--help'
            ], capture_output=True, text=True, cwd=project_root)
            
            if result.returncode == 0 and 'статистика' in result.stdout.lower():
                self._add_result("CLI001", "CLI Stats Command", "PASS", 
                               "CLI команда работает", 0.2)
            else:
                self._add_result("CLI001", "CLI Stats Command", "FAIL", 
                               f"Exit code: {result.returncode}", 0.2)
        except Exception as e:
            self._add_result("CLI001", "CLI Stats Command", "FAIL", str(e), 0.2)
    
    def _run_versioning_tests(self):
        """Тесты системы версионирования"""
        print("📊 [2/4] Тесты версионирования...")
        
        try:
            # Импорт и запуск встроенных тестов версионирования
            from tests.test_versioning_system import TestVersioningSystem
            import tempfile
            
            # // Chg_FIX_VER000_2009: Исправление последнего WinError 32
            # Создаем временную БД с уникальным именем
            import uuid
            unique_id = uuid.uuid4().hex[:8]
            temp_dir = tempfile.gettempdir()
            temp_path = os.path.join(temp_dir, f'test_versioning_{unique_id}.sqlite3')
            
            try:
                from core.database_v3 import VacancyDatabase
                temp_db = VacancyDatabase(temp_path)
                test_class = TestVersioningSystem()
                
                # Список тестов из нашего test_versioning_system.py
                versioning_tests = [
                    ("VER001", "Database Schema", test_class.test_database_creation),
                    ("VER002", "New Vacancy", test_class.test_vacancy_versioning_new),
                    ("VER003", "Duplicate Detection", test_class.test_vacancy_duplicate_detection),
                    ("VER004", "Version Creation", test_class.test_vacancy_versioning),
                    ("VER005", "Change Tracking", test_class.test_changes_tracking),
                    ("VER006", "Employer Versioning", test_class.test_employer_versioning),
                    ("VER007", "Combined Stats", test_class.test_combined_stats),
                ]
                
                passed = 0
                for test_id, test_name, test_func in versioning_tests:
                    try:
                        start_time = time.time()
                        test_func(temp_db)
                        duration = time.time() - start_time
                        
                        self._add_result(test_id, test_name, "PASS", 
                                       "Тест пройден", duration)
                        passed += 1
                    except Exception as e:
                        duration = time.time() - start_time
                        self._add_result(test_id, test_name, "FAIL", 
                                       str(e)[:100], duration)
                
                # Общий результат
                if passed == len(versioning_tests):
                    print(f"  ✅ Все {passed} тестов версионирования пройдены")
                else:
                    print(f"  ⚠️  Пройдено {passed}/{len(versioning_tests)} тестов")
                    
            finally:
                # Принудительная очистка БД
                try:
                    temp_db._conn = None  # Закрываем соединение
                    time.sleep(0.1)  # Задержка для Windows
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
                except Exception as cleanup_error:
                    print(f"  Warning: Could not cleanup {temp_path}: {cleanup_error}")
                    
        except Exception as e:
            self._add_result("VER000", "Versioning Tests Setup", "FAIL", str(e), 0.1)
    
    def _run_api_tests(self):
        """Тесты API интеграции"""  
        print("🌐 [3/4] Тесты API...")
        
        # Тест конфигурации
        try:
            config_path = project_root / 'config' / 'config_v4.json'
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    
                if 'api' in config and 'user_agent' in config.get('api', {}):
                    self._add_result("API001", "Config Validation", "PASS", 
                                   "Конфигурация API найдена", 0.1)
                else:
                    self._add_result("API001", "Config Validation", "PARTIAL", 
                                   "Конфигурация неполная", 0.1)
            else:
                self._add_result("API001", "Config Validation", "FAIL", 
                               "Конфигурация не найдена", 0.1)
        except Exception as e:
            self._add_result("API001", "Config Validation", "FAIL", str(e), 0.1)
        
        # Тест импорта fetcher
        try:
            from plugins.fetcher_v4 import VacancyFetcher
            fetcher = VacancyFetcher(rate_limit_delay=0.1)
            
            if hasattr(fetcher, 'search_vacancies'):
                self._add_result("API002", "Fetcher Import", "PASS", 
                               "Fetcher импортирован успешно", 0.1)
            else:
                self._add_result("API002", "Fetcher Import", "PARTIAL", 
                               "Fetcher без основных методов", 0.1)
        except Exception as e:
            self._add_result("API002", "Fetcher Import", "FAIL", str(e), 0.1)
    
    def _run_daemon_tests(self):
        """Тесты демона планировщика"""
        print("🧭 [5/5] Тесты демона планировщика...")
        start_time = time.time()
        try:
            import subprocess
            result = subprocess.run([
                sys.executable, 'cli_v4.py', 'daemon', 'status'
            ], capture_output=True, text=True, cwd=project_root, timeout=30)
            out = (result.stdout or '').lower()
            if result.returncode == 0 and ('демон' in out or 'running' in out):
                self._add_result("DAEMON001", "Daemon Status", "PASS", "Демон отвечает", time.time() - start_time, category='integration')
            else:
                self._add_result("DAEMON001", "Daemon Status", "PARTIAL", "Не удалось подтвердить статус демона", time.time() - start_time, category='integration')
        except Exception as e:
            self._add_result("DAEMON001", "Daemon Status", "FAIL", str(e), time.time() - start_time, category='integration')
    
    def _run_performance_tests(self):
        """Быстрые тесты производительности"""
        print("⚡ [4/4] Тесты производительности...")
        
        # Тест скорости создания БД
        import uuid
        import tempfile
        
        try:
            # // Chg_FIX_TESTS_2009: Уникальный путь для каждого теста
            unique_id = uuid.uuid4().hex[:8]
            temp_dir = tempfile.gettempdir()
            test_db_path = os.path.join(temp_dir, f'test_perf_{unique_id}.sqlite3')
            
            start_time = time.time()
            from core.database_v3 import VacancyDatabase
            db = VacancyDatabase(test_db_path)
            duration = time.time() - start_time
            
            if duration < 1.0:  # Менее 1 секунды
                self._add_result("PERF001", "DB Creation Speed", "PASS", 
                               f"Создание БД: {duration:.3f}s", duration)
            elif duration < 3.0:  # Менее 3 секунд
                self._add_result("PERF001", "DB Creation Speed", "PARTIAL", 
                               f"Медленное создание: {duration:.3f}s", duration)
            else:
                self._add_result("PERF001", "DB Creation Speed", "FAIL", 
                               f"Слишком медленно: {duration:.3f}s", duration)
                
            # Принудительная очистка
            db._conn = None
            time.sleep(0.1)
            
            try:
                if os.path.exists(test_db_path):
                    os.remove(test_db_path)
            except Exception as cleanup_error:
                print(f"  Warning: Could not cleanup {test_db_path}: {cleanup_error}")
        except Exception as e:
            self._add_result("PERF001", "DB Creation Speed", "FAIL", str(e), 0.0)


def main():
    """Основная функция запуска тестов"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Функциональные тесты HH-бота v4')
    parser.add_argument('--verbose', '-v', action='store_true', help='Подробный вывод')
    parser.add_argument('--json', '-j', action='store_true', help='JSON отчет')
    parser.add_argument('--output', '-o', help='Файл для сохранения отчета')
    
    args = parser.parse_args()
    
    # Запускаем тесты
    runner = FunctionalTestRunner()
    # // Chg_TEST_LOG_2109: логируем старт выполнения функциональных тестов
    try:
        root = logging.getLogger()
        if not root.handlers:
            os.makedirs('logs', exist_ok=True)
            fh = logging.FileHandler('logs/app.log', encoding='utf-8')
            fh.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            root.addHandler(fh)
            root.setLevel(logging.INFO)
        logging.info('functional_tests_start')
    except Exception:
        pass
    report = runner.run_all_tests(verbose=args.verbose)
    
    # Сохраняем отчет при необходимости
    if args.json or args.output:
        # // Chg_REPORTS_DIR_2109: сохраняем отчеты в папку reports/
        os.makedirs('reports', exist_ok=True)
        filename = args.output or f"functional_test_report_{int(time.time())}.json"
        if not os.path.isabs(filename):
            output_file = os.path.join('reports', filename)
        else:
            output_file = filename

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
            
        print(f"\n💾 Отчет сохранен: {output_file}")
    
    # Возвращаем код завершения
    success_rate = report['success_rate']
    if success_rate >= 90:
        return 0  # Успех
    elif success_rate >= 50:
        return 1  # Частичный успех
    else:
        return 2  # Провал


if __name__ == "__main__":
    exit(main())
