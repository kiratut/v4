# -*- coding: utf-8 -*-
"""
E2E runner for HH Tool v4
- Проверяет доступность веб-сервера (стартует uvicorn, если нужно)
- Запускает /api/tests/smoke, /api/tests/functional, /api/tests/system
- Проверяет /api/tests/history, /api/tasks, /api/vacancies/recent
- Пишет подробные логи в logs/union_test.log (UTF-8)
"""

import os
import sys
import time
import json
import subprocess
from pathlib import Path

try:
    import requests
except ImportError:
    print("[E2E] Требуется библиотека 'requests' (pip install requests)")
    sys.exit(2)

BASE_URL = os.environ.get("HH_BASE_URL", "http://127.0.0.1:5000").rstrip('/')
LOGS_DIR = Path("logs")
UNION_LOG = LOGS_DIR / "union_test.log"


def _log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    text = f"[{ts}] {msg}"
    print(text)
    try:
        with open(UNION_LOG, 'a', encoding='utf-8') as f:
            f.write(text + "\n")
    except Exception:
        pass


def _try_get(url: str, timeout=10):
    try:
        return requests.get(url, timeout=timeout)
    except Exception as e:
        _log(f"GET {url} failed: {e}")
        return None


def _try_post(url: str, json_data=None, timeout=60):
    try:
        return requests.post(url, json=json_data or {}, timeout=timeout)
    except Exception as e:
        _log(f"POST {url} failed: {e}")
        return None


def ensure_server():
    """Гарантируем, что веб-сервер поднят. Если нет — поднимаем uvicorn."""
    LOGS_DIR.mkdir(exist_ok=True)
    # Очистка union_test.log в начале
    try:
        with open(UNION_LOG, 'w', encoding='utf-8') as f:
            f.write('')
    except Exception:
        pass

    _log("E2E start: ensure server is up")
    resp = _try_get(f"{BASE_URL}/api/stats", timeout=3)
    if resp and resp.ok:
        _log("Web server is already running")
        return None  # не запускали новый процесс

    _log("Starting uvicorn web.server:app on 127.0.0.1:5000 ...")
    # Стартуем uvicorn в фоне
    # Примечание: на Windows используем shell=True для корректного старта
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "web.server:app", "--host", "127.0.0.1", "--port", "5000"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        shell=False,
        cwd=Path.cwd(),
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if hasattr(subprocess, 'CREATE_NEW_PROCESS_GROUP') else 0,
    )

    # Ждём готовность
    for _ in range(30):
        time.sleep(1)
        resp = _try_get(f"{BASE_URL}/api/stats", timeout=2)
        if resp and resp.ok:
            _log("Web server started and is responsive")
            return proc
    _log("Web server failed to start within timeout")
    return proc


def maybe_start_daemon():
    _log("Checking scheduler daemon status")
    resp = _try_get(f"{BASE_URL}/api/daemon/status", timeout=5)
    if not resp or not resp.ok:
        _log("/api/daemon/status unavailable; skip daemon check")
        return False
    data = {}
    try:
        data = resp.json()
    except Exception:
        pass
    if data.get('running'):
        _log(f"Daemon already running (pid={data.get('pid')})")
        return True

    _log("Starting daemon via cli_v4.py ...")
    try:
        r = subprocess.run([sys.executable, 'cli_v4.py', 'daemon', 'start', '--background'], capture_output=True, text=True, timeout=60)
        _log(f"cli_v4.py start rc={r.returncode}; out={r.stdout.strip()} err={r.stderr.strip()}")
        time.sleep(2)
        resp2 = _try_get(f"{BASE_URL}/api/daemon/status", timeout=5)
        if resp2 and resp2.ok and (resp2.json().get('running')):
            _log("Daemon is running")
            return True
    except Exception as e:
        _log(f"Failed to start daemon: {e}")
    return False


def run_suite():
    ok = True

    # 1) Smoke
    _log("POST /api/tests/smoke")
    r = _try_post(f"{BASE_URL}/api/tests/smoke")
    if not r or not r.ok:
        _log("Smoke: HTTP error")
        ok = False
    else:
        jd = r.json()
        _log(f"Smoke result: status={jd.get('status')} items={jd.get('items_count')} saved={jd.get('loaded_count')}")
        if jd.get('status') != 'ok':
            ok = False

    # 2) Functional tests
    _log("POST /api/tests/functional")
    r = _try_post(f"{BASE_URL}/api/tests/functional")
    if r and r.ok:
        jd = r.json()
        sr = jd.get('success_rate') or (jd.get('summary') or {}).get('success_rate')
        _log(f"Functional success_rate={sr}")
    else:
        _log("Functional: HTTP error")
        ok = False

    # 3) System tests
    _log("POST /api/tests/system")
    r = _try_post(f"{BASE_URL}/api/tests/system")
    if r and r.ok:
        jd = r.json()
        summary = jd.get('summary') or {}
        _log(f"System: passed={summary.get('passed')}/{summary.get('total')} sr={summary.get('success_rate')}")
    else:
        _log("System: HTTP error")
        ok = False

    # 4) History
    _log("GET /api/tests/history")
    r = _try_get(f"{BASE_URL}/api/tests/history?limit=10")
    if r and r.ok:
        jd = r.json()
        _log(f"History count={len(jd.get('history') or [])}")
    else:
        _log("History: HTTP error")
        ok = False

    # 5) Tasks
    _log("GET /api/tasks")
    r = _try_get(f"{BASE_URL}/api/tasks?status=completed,running,pending&limit=3")
    if r and r.ok:
        jd = r.json()
        tasks = jd.get('tasks') or []
        _log(f"Tasks total={len(tasks)}; sample={[t.get('type') for t in tasks]}")
    else:
        _log("Tasks: HTTP error")
        ok = False

    # 6) Vacancies
    _log("GET /api/vacancies/recent")
    r = _try_get(f"{BASE_URL}/api/vacancies/recent?limit=5")
    if r and r.ok:
        jd = r.json()
        vac = jd.get('vacancies') or []
        _log(f"Vacancies recent count={len(vac)}")
    else:
        _log("Vacancies recent: HTTP error")
        ok = False

    return ok


def main():
    server_proc = ensure_server()
    # Попытаться запустить демон (не критично для успеха, но желательно)
    maybe_start_daemon()

    ok = run_suite()

    # Вывести хвост основного лога
    try:
        _log("Tail logs/app.log (last 60 lines):")
        with open('logs/app.log', 'r', encoding='utf-8') as f:
            lines = f.readlines()
        tail = ''.join(lines[-60:])
        for ln in tail.splitlines():
            _log("APPLOG: " + ln)
    except Exception:
        _log("No app.log available")

    # Останавливаем сервер, если мы его поднимали сами
    if server_proc is not None:
        _log("Stopping temporary uvicorn server ...")
        try:
            server_proc.terminate()
        except Exception:
            pass

    if ok:
        _log("E2E SUCCESS")
        sys.exit(0)
    else:
        _log("E2E FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
