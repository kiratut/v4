# Database layer для HH Tool v3
import json
import sqlite3
import hashlib
from pathlib import Path
from typing import List, Optional, Dict, Any
from dataclasses import asdict
import logging  # // Chg_DB_LOG_1309: логирование операций БД

logger = logging.getLogger(__name__)

# Прямые импорты моделей (будут доступны после создания models.py)
try:
    from core.models import Vacancy, Employer, PluginResult
except ImportError:
    # Заглушки для случая, если models.py еще не создан
    Vacancy = None
    Employer = None 
    PluginResult = None

class VacancyDatabaseStats:  # // Chg_DUP_2009: Класс для статистики дубликатов
    """Класс для накопления статистики дубликатов"""

    def __init__(self):
        self.duplicates_found = 0          # Дубликаты по content_hash
        self.new_vacancies = 0             # Новые уникальные вакансии
        self.new_versions = 0              # Новые версии существующих
        self.total_processed = 0           # Всего обработано
        # // Chg_DUP_2009: Добавляем счетчики для работодателей
        self.employer_duplicates = 0       # Дубликаты работодателей
        self.new_employers = 0            # Новые работодатели
        self.employer_versions = 0        # Новые версии работодателей

    def reset(self):
        """Сброс счетчиков"""
        self.duplicates_found = 0
        self.new_vacancies = 0
        self.new_versions = 0
        self.total_processed = 0
        # // Chg_DUP_2009: Сброс счетчиков работодателей
        self.employer_duplicates = 0
        self.new_employers = 0
        self.employer_versions = 0

    def get_summary(self) -> Dict[str, Any]:
        """Получить сводку статистики"""
        total_saved = self.new_vacancies + self.new_versions
        return {
            'duplicates_found': self.duplicates_found,
            'new_vacancies': self.new_vacancies,
            'new_versions': self.new_versions,
            'total_processed': self.total_processed,
            'total_saved': total_saved,
            'duplicate_percentage': (self.duplicates_found / self.total_processed * 100) if self.total_processed > 0 else 0,
            # // Chg_DUP_2009: Статистика работодателей
            'employer_duplicates': self.employer_duplicates,
            'new_employers': self.new_employers,
            'employer_versions': self.employer_versions
        }


class VacancyDatabase:
    """SQLite база данных для хранения вакансий и результатов плагинов"""
    
    def __init__(self, db_path: str = "data/hh_v3.sqlite3"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()
        # // Chg_DUP_2009: Инициализация статистики дубликатов
        self.stats = VacancyDatabaseStats()
    
    # // Chg_DB_CONN_1309: централизованное подключение с безопасными PRAGMA
    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=15)
        try:
            cur = conn.cursor()
            cur.execute("PRAGMA busy_timeout=5000")
            # Синий журнал для устойчивости и скорости, совместимо с checkpoint
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()
        except Exception as _e:
            # Безопасно игнорируем ошибки PRAGMA (например, в старых SQLite)
            logger.debug(f"PRAGMA setup skipped/failed: {_e}")
        return conn
    # // Chg_DB_CONN_1309 end

    def _init_schema(self):
        """Создание схемы БД v3"""
        with self._connect() as conn:  # // Chg_DB_CONN_USE_1309
            cursor = conn.cursor()
            # Сначала создаем только таблицы (без индексов)
            cursor.executescript("""
                -- Main job vacancies table with versioning support
                -- Supports deduplication and change tracking
                CREATE TABLE IF NOT EXISTS vacancies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique ID
                    
                    -- Core HH.ru data fields
                    hh_id TEXT NOT NULL,                  -- HH.ru vacancy ID (external)
                    title TEXT NOT NULL,                  -- Job title/position name
                    employer_name TEXT,                   -- Company name
                    employer_id TEXT,                     -- HH.ru employer ID
                    salary_from INTEGER,                  -- Salary range minimum (in currency units)
                    salary_to INTEGER,                    -- Salary range maximum (in currency units)
                    currency TEXT,                        -- Salary currency code (RUR, USD, EUR)
                    experience TEXT,                      -- Required experience level
                    schedule TEXT,                        -- Work schedule description
                    schedule_id TEXT,                     -- HH.ru schedule type ID
                    employment TEXT,                      -- Employment type (full-time, part-time, etc)
                    description TEXT,                     -- Full job description
                    key_skills TEXT,                      -- JSON array of required skills
                    area_name TEXT,                       -- Location/city name
                    published_at TEXT,                    -- Publication timestamp (ISO format)
                    url TEXT,                            -- Direct link to vacancy on HH.ru
                    
                    -- Plugin analysis fields
                    work_format_classified TEXT,          -- Classified work format (REMOTE/OFFICE/HYBRID)
                    relevance_score REAL,                -- AI-calculated relevance score (0-10)
                    analysis_summary TEXT,                -- Summary of automated analysis
                    match_status TEXT,                    -- Match status for user profile
                    
                    -- Data versioning fields (for change tracking)
                    version INTEGER DEFAULT 1,           -- Version number (1, 2, 3...)
                    content_hash TEXT,                    -- SHA256 hash of key content fields
                    prev_version_id INTEGER,              -- Link to previous version ID
                    
                    -- System audit fields
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Record creation time
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Last modification time
                    
                    -- Constraints
                    UNIQUE(hh_id, version),               -- One version per HH.ru ID
                    FOREIGN KEY (prev_version_id) REFERENCES vacancies (id)
                );
                
                -- Plugin execution results and analysis data
                -- Stores output from AI/ML processing plugins
                CREATE TABLE IF NOT EXISTS plugin_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique ID
                    vacancy_id INTEGER NOT NULL,          -- Reference to processed vacancy
                    plugin_name TEXT NOT NULL,            -- Name of executed plugin
                    status TEXT NOT NULL,                 -- Execution status: completed/failed/skipped
                    result_data TEXT,                     -- JSON result data from plugin
                    error TEXT,                           -- Error message if failed
                    execution_time REAL,                  -- Processing time in seconds
                    metadata TEXT,                        -- JSON metadata (config, versions, etc)
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Execution timestamp
                    
                    FOREIGN KEY (vacancy_id) REFERENCES vacancies (id),
                    UNIQUE (vacancy_id, plugin_name)      -- One result per plugin per vacancy
                );
                
                -- Employer/company information with versioning
                -- Tracks changes in company data over time
                CREATE TABLE IF NOT EXISTS employers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique ID
                    
                    -- Core employer data from HH.ru
                    hh_id TEXT NOT NULL,                  -- HH.ru employer ID (external)
                    name TEXT NOT NULL,                   -- Company name
                    description TEXT,                     -- Company description
                    site_url TEXT,                       -- Company website URL
                    logo_url TEXT,                       -- Company logo image URL
                    area_name TEXT,                      -- Company location/city
                    vacancies_url TEXT,                  -- Link to company's vacancies page
                    
                    -- Data versioning fields (for change tracking)
                    version INTEGER DEFAULT 1,           -- Version number (1, 2, 3...)
                    content_hash TEXT,                   -- SHA256 hash of key content fields
                    prev_version_id INTEGER,             -- Link to previous version ID
                    
                    -- System audit fields
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Record creation time
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Last modification time
                    
                    -- Constraints
                    UNIQUE(hh_id, version),              -- One version per HH.ru employer ID
                    FOREIGN KEY (prev_version_id) REFERENCES employers (id)
                );
                
                -- Task queue and job management system
                -- Handles asynchronous processing of data collection tasks
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique task ID
                    task_type TEXT NOT NULL,              -- Task type: search/download/analyze/export
                    status TEXT NOT NULL DEFAULT 'pending', -- Task status: pending/running/completed/failed
                    priority INTEGER DEFAULT 0,           -- Task priority (higher = more important)
                    payload TEXT,                         -- JSON task parameters and configuration
                    result TEXT,                          -- JSON task execution results
                    error TEXT,                           -- Error message if task failed
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Task creation time
                    started_at TEXT,                      -- Task execution start time
                    finished_at TEXT,                     -- Task completion time
                    retry_count INTEGER DEFAULT 0,        -- Number of retry attempts
                    max_retries INTEGER DEFAULT 3         -- Maximum allowed retries
                );
                
                -- System performance and health metrics
                -- Stores monitoring data for system diagnostics
                CREATE TABLE IF NOT EXISTS system_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique metric ID
                    metric_name TEXT NOT NULL,            -- Metric name: cpu_usage/memory_usage/disk_usage/api_calls
                    metric_value REAL,                    -- Numeric metric value (percentage, count, etc)
                    metric_text TEXT,                     -- Text metric value or additional info
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP -- Measurement timestamp
                );
                
                -- Long-running process tracking and progress monitoring
                -- Provides real-time status updates for data collection operations
                CREATE TABLE IF NOT EXISTS process_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal unique process ID
                    process_id TEXT,                      -- External process identifier (UUID)
                    name TEXT NOT NULL,                   -- Human-readable process name
                    status TEXT NOT NULL,                 -- Process status: running/completed/failed/stopped
                    started_at TEXT NOT NULL,             -- Process start timestamp
                    finished_at TEXT,                     -- Process completion timestamp
                    progress REAL DEFAULT 0,              -- Progress percentage (0.0 - 100.0)
                    total_items INTEGER DEFAULT 0,        -- Total number of items to process
                    processed_items INTEGER DEFAULT 0,    -- Number of items already processed
                    current_item TEXT,                    -- Currently processing item description
                    eta_minutes INTEGER,                  -- Estimated time to completion (minutes)
                    speed_per_minute REAL,               -- Processing speed (items per minute)
                    errors_count INTEGER DEFAULT 0,       -- Number of errors encountered
                    last_error TEXT,                      -- Last error message
                    config TEXT,                          -- JSON process configuration
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP, -- Record creation time
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP  -- Last status update time
                );
            """)
            
            # // Chg_007_0909 Миграция: гарантируем наличие столбца process_id в process_status
            try:
                info = cursor.execute("PRAGMA table_info(process_status)").fetchall()
                existing_cols = {row[1] for row in info}
                if 'process_id' not in existing_cols:
                    cursor.execute("ALTER TABLE process_status ADD COLUMN process_id TEXT")
            except Exception:
                # Безопасно игнорируем, если миграция не требуется или окружение не позволяет
                pass
            # // Chg_007_0909 end

            # // Chg_008_0909 Расширенная миграция: добавляем недостающие столбцы process_status
            try:
                info = cursor.execute("PRAGMA table_info(process_status)").fetchall()
                existing_cols = {row[1] for row in info}
                required = {
                    'name': 'TEXT',
                    'status': 'TEXT',
                    'started_at': 'TEXT',
                    'finished_at': 'TEXT',
                    'progress': 'REAL DEFAULT 0',
                    'total_items': 'INTEGER DEFAULT 0',
                    'processed_items': 'INTEGER DEFAULT 0',
                    'current_item': 'TEXT',
                    'eta_minutes': 'INTEGER',
                    'speed_per_minute': 'REAL',
                    'errors_count': 'INTEGER DEFAULT 0',
                    'last_error': 'TEXT',
                    'config': 'TEXT',
                    'created_at': "TEXT DEFAULT CURRENT_TIMESTAMP",
                    'updated_at': "TEXT DEFAULT CURRENT_TIMESTAMP",
                }
                for col, decl in required.items():
                    if col not in existing_cols:
                        try:
                            cursor.execute(f"ALTER TABLE process_status ADD COLUMN {col} {decl}")
                        except sqlite3.OperationalError:
                            # Продолжаем миграцию остальных столбцов
                            pass
            except Exception:
                pass
            # // Chg_008_0909 end

            # // Chg_VER_MIGRATION_2009: Миграция столбцов версионирования
            try:
                # Проверяем наличие столбцов версионирования в vacancies
                info = cursor.execute("PRAGMA table_info(vacancies)").fetchall()
                existing_cols = {row[1] for row in info}
                
                if 'version' not in existing_cols:
                    cursor.execute("ALTER TABLE vacancies ADD COLUMN version INTEGER DEFAULT 1")
                    logger.info("Добавлен столбец version в vacancies")
                    
                if 'prev_version_id' not in existing_cols:
                    cursor.execute("ALTER TABLE vacancies ADD COLUMN prev_version_id INTEGER")
                    logger.info("Добавлен столбец prev_version_id в vacancies")
                    
                # Проверяем наличие столбцов версионирования в employers
                info = cursor.execute("PRAGMA table_info(employers)").fetchall()
                existing_cols = {row[1] for row in info}
                
                if 'version' not in existing_cols:
                    cursor.execute("ALTER TABLE employers ADD COLUMN version INTEGER DEFAULT 1")
                    logger.info("Добавлен столбец version в employers")
                    
                if 'prev_version_id' not in existing_cols:
                    cursor.execute("ALTER TABLE employers ADD COLUMN prev_version_id INTEGER")
                    logger.info("Добавлен столбец prev_version_id в employers")
                    
            except Exception as e:
                logger.warning(f"Ошибка миграции версионирования: {e}")
            # // Chg_VER_MIGRATION_2009 end

            # // Chg_CHANGES_MIGRATION_2009: Миграция таблиц истории изменений
            try:
                # Проверяем наличие таблиц vacancy_changes и employer_changes
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='vacancy_changes'")
                if not cursor.fetchone():
                    cursor.execute("""
                        CREATE TABLE vacancy_changes (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            hh_id TEXT NOT NULL,                      -- HH.ru vacancy ID
                            hh_updated_at TEXT,                       -- Date from API HH.ru 
                            recorded_at TEXT DEFAULT CURRENT_TIMESTAMP, -- When we processed it
                            change_type TEXT NOT NULL,                 -- 'new', 'duplicate', 'version'
                            content_hash TEXT NOT NULL,               -- Content hash at time of save
                            vacancy_id INTEGER,                       -- Link to vacancies table (NULL for duplicates)
                            prev_vacancy_id INTEGER,                  -- Previous version if 'version' type
                            
                            FOREIGN KEY (vacancy_id) REFERENCES vacancies (id),
                            FOREIGN KEY (prev_vacancy_id) REFERENCES vacancies (id)
                        )
                    """)
                    logger.info("Создана таблица vacancy_changes")
                
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='employer_changes'")
                if not cursor.fetchone():
                    cursor.execute("""
                        CREATE TABLE employer_changes (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            hh_id TEXT NOT NULL,                      -- HH.ru employer ID
                            hh_updated_at TEXT,                       -- Date from API HH.ru
                            recorded_at TEXT DEFAULT CURRENT_TIMESTAMP, -- When we processed it
                            change_type TEXT NOT NULL,                 -- 'new', 'duplicate', 'version'
                            content_hash TEXT NOT NULL,               -- Content hash at time of save
                            employer_id INTEGER,                      -- Link to employers table (NULL for duplicates)
                            prev_employer_id INTEGER,                 -- Previous version if 'version' type
                            
                            FOREIGN KEY (employer_id) REFERENCES employers (id),
                            FOREIGN KEY (prev_employer_id) REFERENCES employers (id)
                        )
                    """)
                    logger.info("Создана таблица employer_changes")
                    
            except Exception as e:
                logger.warning(f"Ошибка создания таблиц истории изменений: {e}")
            # // Chg_CHANGES_MIGRATION_2009 end

            # Performance indexes - create one by one safely
            # Optimizes common query patterns for fast data retrieval
            index_statements = [
                # Vacancies table indexes
                "CREATE INDEX IF NOT EXISTS idx_vacancies_hh_id ON vacancies (hh_id)",        # Fast lookup by HH.ru ID
                "CREATE INDEX IF NOT EXISTS idx_vacancies_hash ON vacancies (content_hash)",  # Deduplication queries
                "CREATE INDEX IF NOT EXISTS idx_vacancies_published ON vacancies (published_at)", # Date range queries
                "CREATE INDEX IF NOT EXISTS idx_vacancies_relevance ON vacancies (relevance_score)", # Relevance sorting
                
                # Vacancy changes table indexes
                "CREATE INDEX IF NOT EXISTS idx_vacancy_changes_hh_id ON vacancy_changes (hh_id)", # Lookup by HH ID
                "CREATE INDEX IF NOT EXISTS idx_vacancy_changes_recorded ON vacancy_changes (recorded_at)", # Date queries
                "CREATE INDEX IF NOT EXISTS idx_vacancy_changes_type ON vacancy_changes (change_type)", # Filter by type
                "CREATE INDEX IF NOT EXISTS idx_vacancy_changes_hash ON vacancy_changes (content_hash)", # Hash queries
                
                # Employer changes table indexes  
                "CREATE INDEX IF NOT EXISTS idx_employer_changes_hh_id ON employer_changes (hh_id)", # Lookup by HH ID
                "CREATE INDEX IF NOT EXISTS idx_employer_changes_recorded ON employer_changes (recorded_at)", # Date queries
                "CREATE INDEX IF NOT EXISTS idx_employer_changes_type ON employer_changes (change_type)", # Filter by type
                "CREATE INDEX IF NOT EXISTS idx_employer_changes_hash ON employer_changes (content_hash)", # Hash queries
                
                # Plugin results table indexes
                "CREATE INDEX IF NOT EXISTS idx_plugin_results_vacancy ON plugin_results (vacancy_id)", # Join with vacancies
                "CREATE INDEX IF NOT EXISTS idx_plugin_results_plugin ON plugin_results (plugin_name)", # Filter by plugin type
                
                # Process status table indexes
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_process_status_id ON process_status (process_id)", # Unique process lookup
            ]
            for stmt in index_statements:
                try:
                    cursor.execute(stmt)
                except sqlite3.OperationalError:
                    # Например, если столбца еще нет — пропускаем создание индекса
                    pass
    
    def save_vacancy(self, vacancy) -> int:
        """Сохранение вакансии с дедупликацией по content_hash"""
        # Chg_005_0809 Исправлена логика дедупликации - проверяем content_hash вместо hh_id
        # // Chg_DB_COMMIT_1309: явный commit и подробное логирование
        # // Chg_FIX_CONN_2009: исправление управления соединениями
        with self._connect() as conn:
            cursor = conn.cursor()
            logger.debug(f"save_vacancy: upsert start hh_id={vacancy.hh_id} hash={vacancy.content_hash}")

            # СНАЧАЛА проверяем по content_hash (основная дедупликация)
            if vacancy.content_hash:
                cursor.execute("SELECT id, hh_id FROM vacancies WHERE content_hash = ?", (vacancy.content_hash,))
                existing_by_hash = cursor.fetchone()

                if existing_by_hash:
                    # Вакансия с таким хэшем уже есть - это дубликат, обновляем последнюю активность
                    cursor.execute(
                        """
                        UPDATE vacancies SET updated_at = CURRENT_TIMESTAMP WHERE id = ?
                        """,
                        (existing_by_hash[0],)
                    )
                    
                    # // Chg_CHANGES_TRACK_2009: Записываем дубликат в историю изменений
                    cursor.execute(
                        """
                        INSERT INTO vacancy_changes (
                            hh_id, hh_updated_at, change_type, content_hash, vacancy_id
                        ) VALUES (?, ?, ?, ?, ?)
                        """,
                        (vacancy.hh_id, vacancy.published_at, 'duplicate', vacancy.content_hash, existing_by_hash[0])
                    )
                    
                    conn.commit()  # // Chg_DB_COMMIT_1309
                    # // Chg_DUP_2009: Подсчет дубликата
                    self.stats.duplicates_found += 1
                    self.stats.total_processed += 1
                    logger.info(f"save_vacancy: duplicate by hash -> id={existing_by_hash[0]} (committed)")
                    return existing_by_hash[0]
            
            # Проверяем по hh_id (для случаев изменения контента)
            cursor.execute("SELECT id, content_hash FROM vacancies WHERE hh_id = ?", (vacancy.hh_id,))
            existing_by_hh_id = cursor.fetchone()
            
            if existing_by_hh_id:
                # // Chg_VER_VAC_2009: Есть вакансия с таким hh_id, но другим хэшем - создаём НОВУЮ версию
                # Получаем максимальную версию для этого hh_id
                cursor.execute(
                    "SELECT MAX(version) FROM vacancies WHERE hh_id = ?",
                    (vacancy.hh_id,)
                )
                max_version = cursor.fetchone()[0] or 0
                new_version = max_version + 1
                
                # Создаём новую версию с ссылкой на предыдущую
                cursor.execute(
                    """
                    INSERT INTO vacancies (
                        hh_id, title, employer_name, employer_id,
                        salary_from, salary_to, currency,
                        experience, schedule, schedule_id,
                        employment, description, key_skills,
                        area_name, published_at, url,
                        work_format_classified, relevance_score,
                        analysis_summary, match_status, content_hash,
                        version, prev_version_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        vacancy.hh_id, vacancy.title, vacancy.employer_name, vacancy.employer_id,
                        vacancy.salary_from, vacancy.salary_to, vacancy.currency,
                        vacancy.experience, vacancy.schedule, vacancy.schedule_id,
                        vacancy.employment, vacancy.description,
                        json.dumps(vacancy.key_skills) if vacancy.key_skills else None,
                        vacancy.area_name, vacancy.published_at, vacancy.url,
                        vacancy.work_format_classified, vacancy.relevance_score,
                        vacancy.analysis_summary, vacancy.match_status, vacancy.content_hash,
                        new_version, existing_by_hh_id[0]
                    )
                )
                new_id = cursor.lastrowid
                
                # // Chg_CHANGES_TRACK_2009: Записываем новую версию в историю изменений
                cursor.execute(
                    """
                    INSERT INTO vacancy_changes (
                        hh_id, hh_updated_at, change_type, content_hash, vacancy_id, prev_vacancy_id
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (vacancy.hh_id, vacancy.published_at, 'version', vacancy.content_hash, new_id, existing_by_hh_id[0])
                )
                
                conn.commit()  # // Chg_DB_COMMIT_1309
                # // Chg_DUP_2009: Подсчет новой версии
                self.stats.new_versions += 1
                self.stats.total_processed += 1
                logger.info(f"save_vacancy: created new version id={new_id} v{new_version} prev_id={existing_by_hh_id[0]} (committed)")
                return new_id
            else:
                # Новая уникальная вакансия - создаем
                # // Chg_VER_VAC_2009: Новая вакансия с version=1 по умолчанию
                cursor.execute(
                    """
                    INSERT INTO vacancies (
                        hh_id, title, employer_name, employer_id,
                        salary_from, salary_to, currency,
                        experience, schedule, schedule_id,
                        employment, description, key_skills,
                        area_name, published_at, url,
                        work_format_classified, relevance_score,
                        analysis_summary, match_status, content_hash, version
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        vacancy.hh_id, vacancy.title, vacancy.employer_name, vacancy.employer_id,
                        vacancy.salary_from, vacancy.salary_to, vacancy.currency,
                        vacancy.experience, vacancy.schedule, vacancy.schedule_id,
                        vacancy.employment, vacancy.description,
                        json.dumps(vacancy.key_skills) if vacancy.key_skills else None,
                        vacancy.area_name, vacancy.published_at, vacancy.url,
                        vacancy.work_format_classified, vacancy.relevance_score,
                        vacancy.analysis_summary, vacancy.match_status, vacancy.content_hash, 1
                    )
                )
                new_id = cursor.lastrowid
                
                # // Chg_CHANGES_TRACK_2009: Записываем новую вакансию в историю изменений
                cursor.execute(
                    """
                    INSERT INTO vacancy_changes (
                        hh_id, hh_updated_at, change_type, content_hash, vacancy_id
                    ) VALUES (?, ?, ?, ?, ?)
                    """,
                    (vacancy.hh_id, vacancy.published_at, 'new', vacancy.content_hash, new_id)
                )
                
                conn.commit()  # // Chg_DB_COMMIT_1309
                # // Chg_DUP_2009: Подсчет новой вакансии
                self.stats.new_vacancies += 1
                self.stats.total_processed += 1
                logger.info(f"save_vacancy: inserted id={new_id} v1 (committed)")
                return new_id
            # // Chg_FIX_CONN_2009: connection автоматически закрывается в with блоке
        # Chg_005_0809
        # // Chg_DB_COMMIT_1309 end
    
    def calculate_content_hash(self, vacancy_data: dict, config: dict = None) -> str:
        """Вычислить hash контента вакансии для обнаружения изменений."""
        # Chg_001_0809 Добавлен метод хэширования из v2 в v3
        # // Chg_HASH_2009: Обновлены поля под схему v3
        default_fields = [
            'title', 'employer_name', 'salary_from', 'salary_to', 'currency',
            'experience', 'schedule', 'employment', 'area_name', 'description', 'key_skills'
        ]
        
        hash_config = config.get('content_hash', {}) if config else {}
        fields = hash_config.get('fields', default_fields)
        algorithm = hash_config.get('algorithm', 'md5')
        encoding = hash_config.get('encoding', 'utf-8')
        
        # Сбор значений полей для hash
        values = []
        for field in fields:
            value = vacancy_data.get(field)
            if value is None:
                values.append('')
            elif isinstance(value, (list, dict)):
                values.append(json.dumps(value, sort_keys=True, ensure_ascii=False))
            else:
                values.append(str(value))
        
        # Объединение всех значений
        content = '|'.join(values)
        
        # Вычисление hash
        if algorithm == 'md5':
            return hashlib.md5(content.encode(encoding)).hexdigest()
        elif algorithm == 'sha256':
            return hashlib.sha256(content.encode(encoding)).hexdigest()
        else:
            raise ValueError(f"Неподдерживаемый алгоритм hash: {algorithm}")
        # Chg_001_0809
    
    # // Chg_DB_CKPT_1309: чекпоинт WAL для фиксации данных в основной файл
    def checkpoint(self) -> bool:
        """Выполняет PRAGMA wal_checkpoint(TRUNCATE) для принудительной фиксации WAL.
        Возвращает True при успехе, иначе False."""
        try:
            with self._connect() as conn:
                logger.info("Requesting WAL checkpoint (TRUNCATE)...")
                cur = conn.cursor()
                try:
                    cur.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    # Возвращаемые значения PRAGMA нам не критичны; просто логируем успех
                    logger.info("WAL checkpoint completed")
                finally:
                    cur.close()
            return True
        except Exception as e:
            logger.warning(f"WAL checkpoint failed: {e}")
            return False
    # // Chg_DB_CKPT_1309 end
    
    def get_vacancy(self, vacancy_id: int):
        """Получение вакансии по ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM vacancies WHERE id = ?", (vacancy_id,))
            row = cursor.fetchone()
            
            if row:
                return Vacancy(
                    id=row['id'],
                    hh_id=row['hh_id'],
                    title=row['title'],
                    employer_name=row['employer_name'],
                    employer_id=row['employer_id'],
                    salary_from=row['salary_from'],
                    salary_to=row['salary_to'],
                    currency=row['currency'],
                    experience=row['experience'],
                    schedule=row['schedule'],
                    schedule_id=row['schedule_id'],
                    employment=row['employment'],
                    description=row['description'],
                    key_skills=json.loads(row['key_skills']) if row['key_skills'] else None,
                    area_name=row['area_name'],
                    published_at=row['published_at'],
                    url=row['url'],
                    work_format_classified=row['work_format_classified'],
                    relevance_score=row['relevance_score'],
                    analysis_summary=row['analysis_summary'],
                    match_status=row['match_status'],
                    content_hash=row['content_hash'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at'],
                    version=row['version'] if 'version' in row.keys() else 1,
                    prev_version_id=row['prev_version_id'] if 'prev_version_id' in row.keys() else None
                )
        return None
    
    def save_plugin_result(self, vacancy_id: int, plugin_name: str, result):
        """Сохранение результата плагина"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO plugin_results 
                (vacancy_id, plugin_name, status, result_data, error, execution_time, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                vacancy_id, plugin_name, result.status,
                json.dumps(result.data), result.error, result.execution_time,
                json.dumps(result.metadata)
            ))
    
    def get_plugin_results(self, vacancy_id: int) -> Dict[str, Any]:
        """Получение всех результатов плагинов для вакансии"""
        results = {}
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM plugin_results WHERE vacancy_id = ?
            """, (vacancy_id,))
            
            for row in cursor.fetchall():
                results[row['plugin_name']] = PluginResult(
                    status=row['status'],
                    data=json.loads(row['result_data']) if row['result_data'] else {},
                    error=row['error'],
                    execution_time=row['execution_time'],
                    metadata=json.loads(row['metadata']) if row['metadata'] else {}
                )
                
        return results
    
    def get_vacancies_for_processing(self, plugin_name: str, limit: int = 100) -> List[Any]:
        """Получение вакансий, которые нужно обработать плагином"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT v.* FROM vacancies v
                LEFT JOIN plugin_results pr ON v.id = pr.vacancy_id AND pr.plugin_name = ?
                WHERE pr.id IS NULL OR pr.status != 'completed'
                ORDER BY v.created_at DESC
                LIMIT ?
            """, (plugin_name, limit))
            
            vacancies = []
            for row in cursor.fetchall():
                vacancy = Vacancy(
                    id=row['id'],
                    hh_id=row['hh_id'],
                    title=row['title'],
                    employer_name=row['employer_name'],
                    employer_id=row['employer_id'],
                    # ... остальные поля аналогично get_vacancy
                )
                vacancies.append(vacancy)
                
            return vacancies
    
    def save_process_status(self, process_status) -> int:
        """Сохранение статуса процесса, возвращает ID"""
        # Chg_004_0809 Добавлен метод для работы с process_status
        # // Chg_010_0909 Исправлена вставка с корректными именами столбцов
        # // Chg_FIX_1209: по умолчанию используем колонку 'name' (v3), с устойчивым фолбэком на 'process_name'
        # // Chg_FIX_NAMECOLS_1209: если в таблице есть и 'name', и legacy 'process_name' (NOT NULL), вставляем в обе
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # // Chg_FIX_NAMECOLS_1209: безопасная вставка с учётом наличия обоих name-столбцов
            try:
                info = cursor.execute("PRAGMA table_info(process_status)").fetchall()
                columns = {row[1] for row in info}

                insert_cols = ['process_id']
                name_value = getattr(process_status, 'name', 'HH Fetch Process')
                # Если есть оба столбца, указываем оба
                if 'name' in columns:
                    insert_cols.append('name')
                if 'process_name' in columns:
                    insert_cols.append('process_name')

                # Остальные поля
                insert_cols.extend([
                    'status', 'started_at', 'progress', 'total_items', 'processed_items',
                    'current_item', 'eta_minutes', 'speed_per_minute', 'errors_count', 'config'
                ])

                placeholders = ', '.join(['?'] * len(insert_cols))
                sql = f"INSERT INTO process_status ({', '.join(insert_cols)}) VALUES ({placeholders})"

                values = [
                    getattr(process_status, 'process_id', None)
                ]
                if 'name' in columns:
                    values.append(name_value)
                if 'process_name' in columns:
                    values.append(name_value)
                values.extend([
                    getattr(process_status, 'status', 'running'),
                    getattr(process_status, 'started_at', 'CURRENT_TIMESTAMP'),
                    getattr(process_status, 'progress', 0.0),
                    getattr(process_status, 'total_items', 0),
                    getattr(process_status, 'processed_items', 0),
                    getattr(process_status, 'current_item', None),
                    getattr(process_status, 'eta_minutes', None),
                    getattr(process_status, 'speed_per_minute', None),
                    getattr(process_status, 'errors_count', 0),
                    getattr(process_status, 'config', None)
                ])
                cursor.execute(sql, tuple(values))
            except (sqlite3.IntegrityError, sqlite3.OperationalError):
                # Fallback: минимальная совместимая вставка — выбираем доступное имя-Поле
                info = cursor.execute("PRAGMA table_info(process_status)").fetchall()
                columns = {row[1] for row in info}
                if 'name' in columns:
                    cursor.execute(
                        "INSERT INTO process_status (process_id, name, status, started_at) VALUES (?, ?, ?, ?)",
                        (
                            getattr(process_status, 'process_id', f"proc_{hash(str(process_status)) % 10000}"),
                            name_value,
                            getattr(process_status, 'status', 'running'),
                            getattr(process_status, 'started_at', 'CURRENT_TIMESTAMP')
                        )
                    )
                elif 'process_name' in columns:
                    cursor.execute(
                        "INSERT INTO process_status (process_id, process_name, status, started_at) VALUES (?, ?, ?, ?)",
                        (
                            getattr(process_status, 'process_id', f"proc_{hash(str(process_status)) % 10000}"),
                            name_value,
                            getattr(process_status, 'status', 'running'),
                            getattr(process_status, 'started_at', 'CURRENT_TIMESTAMP')
                        )
                    )
                else:
                    # Последний фолбэк: пробуем с name
                    cursor.execute(
                        "INSERT INTO process_status (process_id, name, status, started_at) VALUES (?, ?, ?, ?)",
                        (
                            getattr(process_status, 'process_id', f"proc_{hash(str(process_status)) % 10000}"),
                            name_value,
                            getattr(process_status, 'status', 'running'),
                            getattr(process_status, 'started_at', 'CURRENT_TIMESTAMP')
                        )
                    )
            return cursor.lastrowid
        # // Chg_010_0909 end
        # Chg_004_0809
        
    # // Chg_EMP_2009: Методы для работы с работодателями
    def save_employer(self, employer) -> int:
        """Сохранение работодателя с версионированием"""
        conn = self._connect()
        try:
            cursor = conn.cursor()
            
            # Проверяем по content_hash (основная дедупликация)
            if employer.content_hash:
                cursor.execute("SELECT id, hh_id FROM employers WHERE content_hash = ?", (employer.content_hash,))
                existing_by_hash = cursor.fetchone()
                
                if existing_by_hash:
                    cursor.execute(
                        "UPDATE employers SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                        (existing_by_hash[0],)
                    )
                    conn.commit()
                    logger.info(f"save_employer: duplicate by hash -> id={existing_by_hash[0]}")
                    return existing_by_hash[0]
                    
            # Проверяем по hh_id
            cursor.execute("SELECT id, content_hash FROM employers WHERE hh_id = ?", (employer.hh_id,))
            existing_by_hh_id = cursor.fetchone()
            
            if existing_by_hh_id:
                # Создаём новую версию при изменении
                cursor.execute(
                    "SELECT MAX(version) FROM employers WHERE hh_id = ?",
                    (employer.hh_id,)
                )
                max_version = cursor.fetchone()[0] or 0
                new_version = max_version + 1
                
                cursor.execute(
                    """
                    INSERT INTO employers (
                        hh_id, name, description, site_url, logo_url, area_name, 
                        vacancies_url, content_hash, version, prev_version_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        employer.hh_id, employer.name, employer.description,
                        employer.site_url, employer.logo_url, employer.area_name,
                        employer.vacancies_url, employer.content_hash,
                        new_version, existing_by_hh_id[0]
                    )
                )
                new_id = cursor.lastrowid
                conn.commit()
                logger.info(f"save_employer: new version id={new_id} v{new_version}")
                return new_id
            else:
                # Новый работодатель
                cursor.execute(
                    """
                    INSERT INTO employers (
                        hh_id, name, description, site_url, logo_url, area_name,
                        vacancies_url, content_hash
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        employer.hh_id, employer.name, employer.description,
                        employer.site_url, employer.logo_url, employer.area_name,
                        employer.vacancies_url, employer.content_hash
                    )
                )
                new_id = cursor.lastrowid
                conn.commit()
                logger.info(f"save_employer: new employer id={new_id}")
                return new_id
                
        finally:
            try:
                conn.close()
            except Exception:
                pass
                
    def calculate_employer_hash(self, employer_data: dict) -> str:
        """Вычисляет hash контента работодателя"""
        fields = ['name', 'description', 'site_url', 'logo_url', 'area_name']
        
        values = []
        for field in fields:
            value = employer_data.get(field)
            if value is None:
                values.append('')
            else:
                values.append(str(value))
                
        content = '|'.join(values)
        return hashlib.md5(content.encode('utf-8')).hexdigest()
        
    def get_latest_employer_by_hh_id(self, hh_id: str):
        """Получение последней версии работодателя"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM employers WHERE hh_id = ? ORDER BY version DESC LIMIT 1", 
                (hh_id,)
            )
            return cursor.fetchone()
    # // Chg_EMP_2009 end
    
    def get_vacancy_by_hh_id(self, hh_id: str) -> Optional[Vacancy]:
        """Получение последней версии вакансии по hh_id"""
        # // Chg_011_0909 Добавлен недостающий метод для fetcher.py
        # // Chg_VER_VAC_2009: Обновлен для получения последней версии
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM vacancies WHERE hh_id = ? ORDER BY version DESC LIMIT 1", (hh_id,))
            row = cursor.fetchone()
            if row:
                # // Chg_VER_VAC_2009: Обновлена сборка Vacancy с полями версионирования (get_vacancy_by_hh_id)
                return Vacancy(
                    id=row['id'],
                    hh_id=row['hh_id'],
                    title=row['title'],
                    employer_name=row.get('employer_name', ''),
                    employer_id=row.get('employer_id', ''),
                    salary_from=row.get('salary_from'),
                    salary_to=row.get('salary_to'),
                    currency=row.get('currency'),
                    experience=row.get('experience'),
                    schedule=row.get('schedule'),
                    schedule_id=row.get('schedule_id'),
                    employment=row.get('employment'),
                    description=row.get('description'),
                    key_skills=json.loads(row['key_skills']) if row.get('key_skills') else None,
                    area_name=row.get('area_name'),
                    published_at=row.get('published_at'),
                    url=row.get('url'),
                    work_format_classified=row.get('work_format_classified'),
                    relevance_score=row.get('relevance_score'),
                    analysis_summary=row.get('analysis_summary'),
                    match_status=row.get('match_status'),
                    content_hash=row.get('content_hash'),
                    created_at=row.get('created_at'),
                    updated_at=row.get('updated_at'),
                    version=row['version'] if 'version' in row.keys() else 1,
                    prev_version_id=row['prev_version_id'] if 'prev_version_id' in row.keys() else None
                )
            return None
        # // Chg_011_0909 end
    
    def update_process_status(self, process_db_id: int, process_status):
        """Обновление статуса процесса по ID"""
        # Chg_004_0809 Добавлен метод для обновления process_status
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE process_status SET
                    status = ?, progress = ?, processed_items = ?,
                    current_item = ?, eta_minutes = ?, speed_per_minute = ?,
                    errors_count = ?, last_error = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (
                process_status.status,
                process_status.progress,
                process_status.processed_items,
                process_status.current_item,
                process_status.eta_minutes,
                process_status.speed_per_minute,
                process_status.errors_count,
                getattr(process_status, 'last_error', None),
                process_db_id
            ))
        # Chg_004_0809

    def get_recent_vacancies(self, limit: int = 10) -> List[Dict]:
        """Получение последних вакансий"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM vacancies 
                ORDER BY published_at DESC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_stats(self) -> Dict[str, Any]:
        """Статистика БД для веб-интерфейса"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Общие статистики
            cursor.execute("SELECT COUNT(*) FROM vacancies")
            total_vacancies = cursor.fetchone()[0]
            
            # // Chg_006_0909 Метрика today по localtime
            # Используем локальное время для метрики "сегодня"
            cursor.execute("SELECT COUNT(*) FROM vacancies WHERE DATE(created_at, 'localtime') = DATE('now', 'localtime')")
            today_vacancies = cursor.fetchone()[0]
            # // Chg_006_0909 end
            
            cursor.execute("SELECT COUNT(*) FROM vacancies WHERE relevance_score >= 7")
            relevant_vacancies = cursor.fetchone()[0]
            
            cursor.execute("SELECT AVG(relevance_score) FROM vacancies WHERE relevance_score IS NOT NULL")
            avg_score = cursor.fetchone()[0] or 0
            
            # Размер БД
            cursor.execute("SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()")
            db_size_bytes = cursor.fetchone()[0]
            
            return {
                'total_vacancies': total_vacancies,
                'today_vacancies': today_vacancies,
                'relevant_vacancies': relevant_vacancies,
                'avg_relevance_score': round(avg_score, 2),
                'db_size_mb': round(db_size_bytes / 1024 / 1024, 2)
            }

    def get_duplicate_stats(self) -> Dict[str, Any]:
        """Получить статистику дубликатов"""
        return self.stats.get_summary()

    def reset_duplicate_stats(self):
        """Сбросить статистику дубликатов"""
        self.stats.reset()

    def get_table_names(self) -> List[str]:
        """Получить список всех таблиц в БД"""
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            return [row[0] for row in cursor.fetchall()]
    
    def get_table_schema(self, table_name: str) -> List[str]:
        """Получить список полей таблицы"""
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            return [row[1] for row in cursor.fetchall()]  # row[1] = column name
    
    def get_vacancy_by_id(self, vacancy_id: int) -> Optional[Vacancy]:
        """Получение вакансии по ID (алиас для get_vacancy)"""
        return self.get_vacancy(vacancy_id)
    
    def calculate_content_hash(self, vacancy: Vacancy) -> str:
        """Вычислить хеш контента вакансии для версионирования"""
        # Используем ключевые поля для расчета хеша
        content_parts = [
            vacancy.title or "",
            vacancy.description or "",
            str(vacancy.salary_from or 0),
            str(vacancy.salary_to or 0),
            vacancy.currency or "",
            vacancy.employer_name or "",
            json.dumps(sorted(vacancy.key_skills or []))
        ]
        content = "|".join(content_parts)
        return hashlib.sha256(content.encode('utf-8')).hexdigest()
    
    def save_employer(self, employer) -> int:
        """Сохранение работодателя с версионированием"""
        with self._connect() as conn:
            cursor = conn.cursor()

            # Проверяем существование по content_hash
            if employer.content_hash:
                cursor.execute("SELECT id FROM employers WHERE content_hash = ?", (employer.content_hash,))
                existing = cursor.fetchone()
                if existing:
                    # Обновляем timestamp существующей записи
                    cursor.execute(
                        "UPDATE employers SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                        (existing[0],)
                    )
                    
                    # // Chg_CHANGES_TRACK_2009: Записываем дубликат работодателя в историю изменений
                    cursor.execute(
                        """
                        INSERT INTO employer_changes (
                            hh_id, change_type, content_hash, employer_id
                        ) VALUES (?, ?, ?, ?)
                        """,
                        (employer.hh_id, 'duplicate', employer.content_hash, existing[0])
                    )
                    
                    # // Chg_DUP_2009: Подсчет дубликата работодателя
                    self.stats.employer_duplicates += 1
                    return existing[0]

            # Проверяем по hh_id для создания новой версии
            cursor.execute("SELECT id, content_hash FROM employers WHERE hh_id = ? ORDER BY version DESC LIMIT 1", (employer.hh_id,))
            existing_employer = cursor.fetchone()

            if existing_employer and existing_employer[1] != employer.content_hash:
                # Создаем новую версию
                cursor.execute("SELECT MAX(version) FROM employers WHERE hh_id = ?", (employer.hh_id,))
                max_version = cursor.fetchone()[0] or 0
                employer.version = max_version + 1
                employer.prev_version_id = existing_employer[0]

            # Вставляем новую запись
            cursor.execute(
                """
                INSERT INTO employers (
                    hh_id, name, description, site_url, logo_url,
                    area_name, vacancies_url, version, content_hash, prev_version_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    employer.hh_id, employer.name, employer.description,
                    employer.site_url, employer.logo_url, employer.area_name,
                    employer.vacancies_url, employer.version, employer.content_hash,
                    employer.prev_version_id
                )
            )

            new_id = cursor.lastrowid
            
            # // Chg_CHANGES_TRACK_2009: Записываем в историю изменений
            change_type = 'version' if existing_employer else 'new'
            prev_employer_id = existing_employer[0] if existing_employer else None
            
            cursor.execute(
                """
                INSERT INTO employer_changes (
                    hh_id, change_type, content_hash, employer_id, prev_employer_id
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (employer.hh_id, change_type, employer.content_hash, new_id, prev_employer_id)
            )
            
            # // Chg_DUP_2009: Подсчет нового работодателя или версии
            if existing_employer:
                self.stats.employer_versions += 1
            else:
                self.stats.new_employers += 1

            return new_id

    # // Chg_STATS_METHODS_2009: Методы для получения статистики изменений
    def get_vacancy_changes_stats(self, days: int = 7) -> Dict[str, Any]:
        """Получить статистику изменений вакансий за последние N дней"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Статистика по типам изменений
            cursor.execute("""
                SELECT change_type, COUNT(*) as count
                FROM vacancy_changes 
                WHERE recorded_at >= datetime('now', '-{} days')
                GROUP BY change_type
            """.format(days))
            
            stats_by_type = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Общая статистика
            cursor.execute("""
                SELECT COUNT(*) as total_changes
                FROM vacancy_changes 
                WHERE recorded_at >= datetime('now', '-{} days')
            """.format(days))
            
            total_changes = cursor.fetchone()[0]
            
            # Эффективность (доля новых и версий от всего)
            new_count = stats_by_type.get('new', 0)
            version_count = stats_by_type.get('version', 0) 
            duplicate_count = stats_by_type.get('duplicate', 0)
            
            efficiency = ((new_count + version_count) / total_changes * 100) if total_changes > 0 else 0
            
            return {
                'days': days,
                'total_changes': total_changes,
                'new_vacancies': new_count,
                'new_versions': version_count,
                'duplicates_skipped': duplicate_count,
                'efficiency_percentage': round(efficiency, 1),
                'by_type': stats_by_type
            }
    
    def get_employer_changes_stats(self, days: int = 7) -> Dict[str, Any]:
        """Получить статистику изменений работодателей за последние N дней"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT change_type, COUNT(*) as count
                FROM employer_changes 
                WHERE recorded_at >= datetime('now', '-{} days')
                GROUP BY change_type
            """.format(days))
            
            stats_by_type = {row[0]: row[1] for row in cursor.fetchall()}
            
            cursor.execute("""
                SELECT COUNT(*) as total_changes
                FROM employer_changes 
                WHERE recorded_at >= datetime('now', '-{} days')
            """.format(days))
            
            total_changes = cursor.fetchone()[0]
            
            return {
                'days': days,
                'total_changes': total_changes,
                'new_employers': stats_by_type.get('new', 0),
                'new_versions': stats_by_type.get('version', 0),
                'duplicates_skipped': stats_by_type.get('duplicate', 0),
                'by_type': stats_by_type
            }
    
    def get_combined_changes_stats(self, days: int = 7) -> Dict[str, Any]:
        """Получить объединенную статистику изменений"""
        vacancy_stats = self.get_vacancy_changes_stats(days)
        employer_stats = self.get_employer_changes_stats(days)
        
        return {
            'period_days': days,
            'vacancies': vacancy_stats,
            'employers': employer_stats,
            'summary': {
                'total_operations': vacancy_stats['total_changes'] + employer_stats['total_changes'],
                'overall_efficiency': vacancy_stats['efficiency_percentage']
            }
        }

    def get_connection(self):
        """Алиас для _connect() для совместимости"""
        return self._connect()
    
    def save_system_health(self, health_data: Dict[str, Any]) -> None:
        """Сохранение метрик системного здоровья"""
        # Добавляем отсутствующий метод для демона
        logger.info(f"System health check: {health_data}")
        # В будущем можно сохранять в БД в таблицу system_health

    def execute_sql(self, query: str, params: tuple = ()) -> List[Dict]:
        """Выполнить произвольный SQL запрос"""
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_system_info(self) -> Dict:
        """Получить системную информацию БД"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Размер БД
            cursor.execute("SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()")
            db_size = cursor.fetchone()[0]
            
            # Количество таблиц
            tables = self.get_table_names()
            
            return {
                'db_size_bytes': db_size,
                'db_size_mb': round(db_size / 1024 / 1024, 2),
                'tables_count': len(tables),
                'table_names': tables
            }

    # // Chg_SCHEDULER_METHODS_2009: Методы для демона планировщика
    
    def get_missing_employer_ids(self, limit: int = 100) -> List[str]:
        """Получить список ID работодателей, которых нет в БД"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Получаем уникальные employer_id из вакансий, которых нет в таблице employers
            cursor.execute("""
                SELECT DISTINCT v.employer_id 
                FROM vacancies v 
                LEFT JOIN employers e ON v.employer_id = e.hh_id 
                WHERE v.employer_id IS NOT NULL 
                  AND v.employer_id != '' 
                  AND e.id IS NULL 
                ORDER BY v.created_at DESC 
                LIMIT ?
            """, (limit,))
            
            return [row[0] for row in cursor.fetchall()]
    
    def get_unsync_vacancy_ids(self, limit: int = 1000) -> List[int]:
        """Получить ID вакансий для синхронизации с Host2"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Получаем вакансии, которые не синхронизированы (упрощенная логика)
            # В реальности можно добавить флаг synced в таблицу или отдельную таблицу sync_status
            cursor.execute("""
                SELECT id FROM vacancies 
                WHERE created_at >= datetime('now', '-7 days')
                ORDER BY created_at DESC 
                LIMIT ?
            """, (limit,))
            
            return [row[0] for row in cursor.fetchall()]
    
    def get_unanalyzed_vacancies(self, limit: int = 50, new_only: bool = True) -> List[Dict[str, Any]]:
        """Получить вакансии для анализа через Host3"""
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Базовый запрос
            base_query = """
                SELECT v.id, v.hh_id, v.title, v.description, v.employer_name, v.salary_from, v.salary_to
                FROM vacancies v
                LEFT JOIN plugin_results pr ON v.id = pr.vacancy_id AND pr.plugin_name = 'host3_analysis'
                WHERE (pr.id IS NULL OR pr.status != 'completed')
            """
            
            # Добавляем фильтр для новых вакансий
            if new_only:
                base_query += " AND v.created_at >= datetime('now', '-3 days')"
            
            base_query += " ORDER BY v.created_at DESC LIMIT ?"
            
            cursor.execute(base_query, (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    def save_analysis_result(self, vacancy_id: int, analysis: Dict[str, Any]) -> None:
        """Сохранить результат анализа от Host3"""
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Сохраняем как результат плагина
            cursor.execute("""
                INSERT OR REPLACE INTO plugin_results 
                (vacancy_id, plugin_name, status, result_data, execution_time, created_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (
                vacancy_id, 
                'host3_analysis',
                'completed',
                json.dumps(analysis, ensure_ascii=False),
                analysis.get('execution_time_seconds', 0)
            ))
            
            # Обновляем поля анализа в вакансии
            if 'relevance_score' in analysis:
                cursor.execute(
                    "UPDATE vacancies SET relevance_score = ?, analysis_summary = ? WHERE id = ?",
                    (
                        analysis['relevance_score'], 
                        analysis.get('summary', ''),
                        vacancy_id
                    )
                )
    
    def cleanup_old_records(self, cutoff_date) -> int:
        """Очистка старых записей"""
        deleted_count = 0
        
        with self._connect() as conn:
            cursor = conn.cursor()
            
            # Удаляем старые записи системных метрик
            cursor.execute("""
                DELETE FROM system_stats 
                WHERE timestamp < ?
            """, (cutoff_date.isoformat(),))
            deleted_count += cursor.rowcount
            
            # Удаляем старые статусы процессов
            cursor.execute("""
                DELETE FROM process_status 
                WHERE created_at < ? AND status IN ('completed', 'failed')
            """, (cutoff_date.isoformat(),))
            deleted_count += cursor.rowcount
            
            # Удаляем старые записи изменений (оставляем последние 30 дней)
            cursor.execute("""
                DELETE FROM vacancy_changes 
                WHERE recorded_at < datetime('now', '-30 days')
            """)
            deleted_count += cursor.rowcount
            
            cursor.execute("""
                DELETE FROM employer_changes 
                WHERE recorded_at < datetime('now', '-30 days')
            """)
            deleted_count += cursor.rowcount
            
        logger.info(f"Очищено {deleted_count} старых записей")
        return deleted_count
    
    def vacuum(self) -> bool:
        """Выполнить VACUUM для оптимизации БД"""
        try:
            with self._connect() as conn:
                logger.info("Выполняется VACUUM БД...")
                conn.execute("VACUUM")
                logger.info("VACUUM завершен успешно")
                return True
        except Exception as e:
            logger.error(f"Ошибка VACUUM: {e}")
            return False
    # // Chg_SCHEDULER_METHODS_2009 end
