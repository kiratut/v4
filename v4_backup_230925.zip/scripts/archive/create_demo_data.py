#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Создание демо-данных для веб-панели мониторинга

// Chg_DEMO_DATA_2009: Генерация тестовых данных для демонстрации панели
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
import random

# Добавляем путь к проекту
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core.database_v3 import VacancyDatabase


class DemoDataGenerator:
    """Генератор демо-данных для тестирования панели"""
    
    def __init__(self, db_path='data/hh_v4_demo.sqlite3'):
        self.db = VacancyDatabase(db_path)
        print(f"🗄️  Создана демо БД: {db_path}")
        
    def create_demo_vacancies(self, count=50):
        """Создание демо-вакансий"""
        print(f"📝 Создание {count} демо-вакансий...")
        
        # Шаблоны данных
        titles = [
            "Python Developer", "Java Developer", "Frontend Developer", 
            "Backend Developer", "DevOps Engineer", "Data Scientist",
            "QA Engineer", "Product Manager", "UI/UX Designer",
            "System Administrator", "Business Analyst", "Mobile Developer"
        ]
        
        companies = [
            "Яндекс", "Сбер", "Тинькофф", "ВТБ", "OZON", "Wildberries",
            "Mail.ru Group", "Kaspersky", "JetBrains", "Avito", "2GIS",
            "Positive Technologies", "DataArt", "EPAM", "Luxoft"
        ]
        
        experiences = ["noExperience", "between1And3", "between3And6", "moreThan6"]
        currencies = ["RUR", "USD", "EUR"]
        areas = ["Москва", "Санкт-Петербург", "Новосибирск", "Екатеринбург", "Казань"]
        
        created_count = 0
        duplicate_count = 0
        version_count = 0
        
        for i in range(count):
            # Базовые данные вакансии
            title = random.choice(titles)
            company = random.choice(companies)
            experience = random.choice(experiences)
            area = random.choice(areas)
            
            # Зарплатная вилка
            salary_from = random.choice([None, 50000, 70000, 100000, 120000, 150000, 200000])
            salary_to = salary_from + 50000 if salary_from else None
            currency = random.choice(currencies)
            
            # Создаем мок-объект вакансии
            class MockVacancy:
                def __init__(self):
                    self.hh_id = f"demo_{i+1:03d}"
                    self.title = title
                    self.company = company  # В БД используется поле 'company'
                    self.employer_id = f"emp_{hash(company) % 1000:03d}"
                    self.salary_from = salary_from
                    self.salary_to = salary_to
                    self.currency = currency
                    self.experience = experience
                    self.schedule = "fullDay"
                    self.schedule_id = "fullDay"
                    self.employment = "full"
                    self.description = f"Требуется {title} в компанию {company}. Опыт работы: {experience}."
                    self.key_skills = random.sample([
                        "Python", "Java", "JavaScript", "React", "Django", "Flask",
                        "PostgreSQL", "Redis", "Docker", "Kubernetes", "Git", "Linux"
                    ], k=random.randint(2, 5))
                    self.area_name = area
                    self.published_at = (datetime.now() - timedelta(days=random.randint(0, 30))).isoformat()
                    self.url = f"https://hh.ru/vacancy/{self.hh_id}"
                    # Убираем поля которых нет в текущей схеме БД
                    self.content_hash = f"hash_{self.hh_id}_{hash(title + company) % 10000:04d}"
                    self.id = None
                    self.version = 1
                    self.prev_version_id = None
                    self.created_at = None
                    self.updated_at = None
            
            vacancy = MockVacancy()
            
            # 10% шанс создать дубликат
            if i > 5 and random.random() < 0.1:
                # Берем хэш от предыдущей вакансии
                prev_vacancy_idx = random.randint(0, i-1)
                vacancy.content_hash = f"hash_demo_{prev_vacancy_idx+1:03d}_{hash(titles[0] + companies[0]) % 10000:04d}"
                duplicate_count += 1
            
            # 15% шанс создать новую версию существующей вакансии
            elif i > 10 and random.random() < 0.15:
                # Берем hh_id от предыдущей вакансии, но меняем контент
                prev_vacancy_idx = random.randint(0, i-1)
                vacancy.hh_id = f"demo_{prev_vacancy_idx+1:03d}"
                vacancy.title = f"Senior {title}"  # Изменяем title
                vacancy.salary_from = (vacancy.salary_from or 100000) + 30000  # Повышаем зарплату
                vacancy.content_hash = f"hash_v2_{vacancy.hh_id}_{hash(vacancy.title) % 10000:04d}"
                version_count += 1
            else:
                created_count += 1
            
            # Сохраняем в БД
            try:
                result_id = self.db.save_vacancy(vacancy)
                if i % 10 == 0:
                    print(f"  💾 Сохранено {i+1}/{count} вакансий...")
            except Exception as e:
                print(f"  ❌ Ошибка сохранения вакансии {i+1}: {e}")
        
        print(f"✅ Создано демо-вакансий:")
        print(f"  📝 Новых: {created_count}")
        print(f"  🔄 Версий: {version_count}")
        print(f"  ⏭️  Дубликатов: {duplicate_count}")
        
    def create_demo_employers(self, count=15):
        """Создание демо-работодателей"""
        print(f"🏢 Создание {count} демо-работодателей...")
        
        companies = [
            ("Яндекс", "Российская интернет-компания"), 
            ("Сбер", "Крупнейший банк России"),
            ("Тинькофф", "Частный банк и экосистема"),
            ("ВТБ", "Государственный банк"),
            ("OZON", "Интернет-ритейлер"),
            ("Wildberries", "Онлайн-платформа"),
            ("Mail.ru Group", "Интернет-холдинг"),
            ("Kaspersky", "Компания информационной безопасности"),
            ("JetBrains", "Разработка инструментов для программистов"),
            ("Avito", "Доска объявлений"),
            ("2GIS", "Геоинформационная система"),
            ("Positive Technologies", "Кибербезопасность"),
            ("DataArt", "ИТ-консалтинг"),
            ("EPAM", "Разработка ПО"),
            ("Luxoft", "ИТ-консалтинг")
        ]
        
        class MockEmployer:
            def __init__(self, name, description, hh_id):
                self.hh_id = hh_id
                self.name = name
                self.description = description
                self.site_url = f"https://{name.lower().replace(' ', '')}.ru"
                self.logo_url = None
                self.area_name = "Москва"
                self.vacancies_url = f"https://hh.ru/employer/{hh_id}"
                self.id = None
                self.version = 1
                self.content_hash = f"emp_hash_{hh_id}_{hash(name + description) % 10000:04d}"
                self.prev_version_id = None
                self.created_at = None
                self.updated_at = None
        
        for i, (name, description) in enumerate(companies[:count]):
            employer = MockEmployer(name, description, f"emp_{i+1:03d}")
            
            try:
                result_id = self.db.save_employer(employer)
                print(f"  🏢 Сохранен работодатель: {name}")
            except Exception as e:
                print(f"  ❌ Ошибка сохранения работодателя {name}: {e}")
        
        print(f"✅ Создано {count} демо-работодателей")
        
    def show_demo_stats(self):
        """Показать статистику демо-данных"""
        print("\n📊 === СТАТИСТИКА ДЕМО-ДАННЫХ ===")
        
        try:
            # Базовая статистика
            stats = self.db.get_stats()
            print(f"📦 Всего вакансий: {stats.get('total_vacancies', 0)}")
            print(f"🗄️  Размер БД: {stats.get('db_size_mb', 0)} МБ")
            
            # Статистика изменений
            changes_stats = self.db.get_vacancy_changes_stats(days=30)
            print(f"✅ Новых вакансий: {changes_stats['new_vacancies']}")
            print(f"🔄 Новых версий: {changes_stats['new_versions']}")
            print(f"⏭️  Дубликатов пропущено: {changes_stats['duplicates_skipped']}")
            print(f"📈 Эффективность: {changes_stats['efficiency_percentage']}%")
            
        except Exception as e:
            print(f"❌ Ошибка получения статистики: {e}")


def main():
    """Основная функция создания демо-данных"""
    print("🎭 === СОЗДАНИЕ ДЕМО-ДАННЫХ ДЛЯ ВЕБ-ПАНЕЛИ ===")
    
    # Создаем генератор
    generator = DemoDataGenerator('data/hh_v4.sqlite3')  # Используем основную БД
    
    # Генерируем данные
    generator.create_demo_vacancies(50)
    generator.create_demo_employers(15)
    
    # Показываем статистику
    generator.show_demo_stats()
    
    print("\n🎉 Демо-данные созданы!")
    print("🌐 Теперь откройте веб-панель: http://localhost:5000")
    print("📊 Статистика должна отображаться корректно")


if __name__ == "__main__":
    main()
