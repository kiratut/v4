param(
    [switch]$dry_run,
    [switch]$force
)

$ErrorActionPreference = "Stop"
# // Chg_PS5_1909: Remove PS7-only $PSStyle to support PowerShell 5
# (Plain ASCII output is ensured by avoiding non-ASCII characters.)

# // Chg_ROOT_1909: Robust project root detection (from scripts/ -> v4/)
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Write-Header($title) {
    Write-Host "==============================================="
    Write-Host "   HH-Bot v4 Project Cleanup Utility"
    Write-Host "==============================================="
    Write-Host "$title"
    Write-Host "Start time: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')"
    Write-Host "Dry-run mode: $($dry_run.IsPresent)"
    Write-Host "Force mode: $($force.IsPresent)"
    Write-Host "Project root: $ProjectRoot"
    Write-Host ""
}

function Ensure-Dir($path) {
    if (-not (Test-Path -LiteralPath $path)) {
        if ($dry_run) { Write-Host "[DRY-RUN] Would create: $path" }
        else { New-Item -ItemType Directory -Force -Path $path | Out-Null }
    }
}

Write-Header "Project cleanup"

# 1/6 Integrity check
Write-Host "[1/6] Project integrity check..."
if (-not (Test-Path (Join-Path $ProjectRoot "cli_v4.py"))) { throw "ERROR: Missing main file cli_v4.py" }
if (-not (Test-Path (Join-Path $ProjectRoot "config\config_v4.json"))) { throw "ERROR: Missing main config config_v4.json" }
if (-not (Test-Path (Join-Path $ProjectRoot "data"))) { throw "ERROR: Missing data folder" }
Write-Host "OK: Required files are present"

# 2/6 Create archive folders
Write-Host ""
Write-Host "[2/6] Creating archive folders..."
Ensure-Dir (Join-Path $ProjectRoot "docs\archive")
Ensure-Dir (Join-Path $ProjectRoot "scripts\archive")
Ensure-Dir (Join-Path $ProjectRoot "data\.trash")
if (-not $dry_run) { Write-Host "OK: Archive folders ready" }

# 3/6 Clean Python cache
Write-Host ""
Write-Host "[3/6] Cleaning Python cache..."
$cacheDirs = Get-ChildItem -Path $ProjectRoot -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue
$cacheCount = 0
foreach ($d in $cacheDirs) {
    $cacheCount++
    if ($dry_run) { Write-Host "[DRY-RUN] Would delete: $($d.FullName)" }
    else { Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction SilentlyContinue }
}
Write-Host "Processed cache dirs: $cacheCount"
if ($cacheCount -gt 0) {
    Write-Host "  Cache locations processed:"
    foreach ($d in $cacheDirs) {
        $rel = $d.FullName.Replace($ProjectRoot, ".")
        Write-Host "    $rel"
    }
}

# 4/6 Clean old DB backups
Write-Host ""
Write-Host "[4/6] Cleaning old DB backups..."
$dataDir = Join-Path $ProjectRoot "data"
$backups = Get-ChildItem -Path $dataDir -Filter "hh_v4_backup_*.sqlite3" -File -ErrorAction SilentlyContinue
$backupCount = 0
foreach ($b in $backups) {
    $backupCount++
    if ($dry_run) { Write-Host "[DRY-RUN] Would delete: $($b.FullName)" }
    else { Remove-Item -LiteralPath $b.FullName -Force -ErrorAction SilentlyContinue }
}
Write-Host "Processed old backups: $backupCount"
if ($backupCount -gt 0) {
    Write-Host "  Backup files processed:"
    foreach ($b in $backups) {
        $rel = $b.FullName.Replace($ProjectRoot, ".")
        Write-Host "    $rel ($([int]($b.Length/1MB)) MB)"
    }
}

# 5/6 Archive old docs
Write-Host ""
Write-Host "[5/6] Archiving outdated docs..."
$docs = @(
  "Architecture_v4_Checklist.md",
  "Architecture_v4_Part1_TaskQueue.md",
  "Architecture_v4_Part2_Structure.md",
  "Architecture_v4_Part3_Documentation.md",
  "Architecture_v4_Summary.md"
)
$archiveCount = 0
$archiveDir = Join-Path $ProjectRoot "docs\archive"
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
foreach ($doc in $docs) {
    $src = Join-Path $ProjectRoot (Join-Path "docs" $doc)
    if (Test-Path -LiteralPath $src) {
        $archiveCount++
        $dst = Join-Path $archiveDir ("{0}_old_{1}" -f $doc, $ts)
        if ($dry_run) { Write-Host "[DRY-RUN] Would archive: $src -> $dst" }
        else { Move-Item -LiteralPath $src -Destination $dst -Force }
    }
}
Write-Host "Archived docs: $archiveCount"
if ($archiveCount -gt 0) {
    Write-Host "  Archive location: .\docs\archive\"
    $archiveDir = Join-Path $ProjectRoot "docs\archive"
    if (Test-Path -LiteralPath $archiveDir) {
        $archivedFiles = Get-ChildItem -Path $archiveDir -File -ErrorAction SilentlyContinue
        Write-Host "  Total files in archive: $($archivedFiles.Count)"
        Write-Host "  Latest archived files:"
        foreach ($af in ($archivedFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 5)) {
            Write-Host "    $($af.Name) ($([int]($af.Length/1KB)) KB)"
        }
    }
}

# 6/6 Logs
Write-Host ""
Write-Host "[6/6] Cleaning old logs..."
$logsDir = Join-Path $ProjectRoot "logs"
$logCount = 0
if (Test-Path -LiteralPath $logsDir) {
    $logs = Get-ChildItem -Path $logsDir -Filter "*.log" -File -ErrorAction SilentlyContinue
    foreach ($lf in $logs) {
        # Rotate if > 100MB
        if ($lf.Length -gt 100MB) {
            if ($dry_run) { Write-Host "[DRY-RUN] Would rotate: $($lf.FullName) size=$([int]($lf.Length/1MB))MB" }
            else {
                $rot = "$($lf.FullName).1"
                Move-Item -LiteralPath $lf.FullName -Destination $rot -Force -ErrorAction SilentlyContinue
                New-Item -ItemType File -Path $lf.FullName -Force | Out-Null
            }
            $logCount++
        }
        # Delete if older than 14 days
        if ($lf.LastWriteTime -lt (Get-Date).AddDays(-14)) {
            if ($dry_run) { Write-Host "[DRY-RUN] Would delete: $($lf.FullName)" }
            else { Remove-Item -LiteralPath $lf.FullName -Force -ErrorAction SilentlyContinue }
            $logCount++
        }
    }
} else {
    Write-Host "logs folder not found"
    Write-Host "  Expected location: .\logs\"
    Write-Host "  No logs to process"
}
Write-Host "Processed logs: $logCount"
if ($logCount -gt 0) {
    Write-Host "  Log operations performed (rotation/deletion)"
} else {
    $logsDir = Join-Path $ProjectRoot "logs"
    if (Test-Path -LiteralPath $logsDir) {
        $allLogs = Get-ChildItem -Path $logsDir -Filter "*.log" -File -ErrorAction SilentlyContinue
        if ($allLogs.Count -gt 0) {
            Write-Host "  Current logs (kept, within retention policy):"
            foreach ($lg in $allLogs) {
                $age = [int]((Get-Date) - $lg.LastWriteTime).TotalDays
                $size = [int]($lg.Length/1KB)
                Write-Host "    $($lg.Name) (${age}d old, ${size} KB)"
            }
        }
    }
}

Write-Host ""
Write-Host "==============================================="
Write-Host "             CLEANUP SUMMARY"
Write-Host "==============================================="
Write-Host ("Python cache dirs: {0}" -f $cacheCount)
Write-Host ("Old DB backups: {0}" -f $backupCount)
Write-Host ("Archived docs: {0}" -f $archiveCount)
Write-Host ("Logs processed: {0}" -f $logCount)
Write-Host ""
if ($dry_run) {
    Write-Host "DRY-RUN MODE - no files changed"
    Write-Host "To apply changes, run without --dry-run"
} else {
    Write-Host "Cleanup finished successfully"
    Write-Host "Verify: python cli_v4.py status"
}
