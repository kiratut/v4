# Архивация устаревших документов HH-бота v4
# // Chg_ARCHIVE_DOCS_2009: Автоматизация архивации документации

param(
    [switch]$DryRun,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

Write-Host "📚 === АРХИВАЦИЯ ДОКУМЕНТОВ ===" -ForegroundColor Cyan
Write-Host "🗓️  Дата: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')" 
Write-Host "⚡ Режим: $(if($DryRun){'DRY-RUN'}else{'EXECUTE'})"
Write-Host ""

# Определяем корень проекта
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$DocsPath = Join-Path $ProjectRoot "docs"
$ArchivePath = Join-Path $DocsPath "archive"
$DateFolder = "2025-09-19"
$ArchiveDatePath = Join-Path $ArchivePath $DateFolder

# Создаем структуру архива
if (-not $DryRun) {
    if (-not (Test-Path $ArchiveDatePath)) {
        New-Item -ItemType Directory -Path $ArchiveDatePath -Force | Out-Null
        Write-Host "✅ Создана папка архива: archive\$DateFolder" -ForegroundColor Green
    }
}

# Документы для архивации (устаревшие анализы)
$ArchiveFiles = @(
    @{
        Source = "Analytics_Gaps_Analysis.md"
        Target = "analytics_gaps_analysis_$DateFolder.md" 
        Reason = "Завершенный анализ разрывов в аналитике"
    },
    @{
        Source = "Current_vs_Requirements_Gap.md"
        Target = "requirements_gap_analysis_$DateFolder.md"
        Reason = "Устаревший анализ соответствия требованиям"
    },
    @{
        Source = "Database_Schema_Gaps.md" 
        Target = "database_schema_gaps_$DateFolder.md"
        Reason = "Устаревший анализ разрывов в схеме БД"
    },
    @{
        Source = "Completion_Report_v4.md"
        Target = "completion_report_v4_$DateFolder.md"
        Reason = "Промежуточный отчет о завершении"
    },
    @{
        Source = "Development_Roadmap_MVP_P1.md"
        Target = "development_roadmap_mvp_p1_$DateFolder.md"
        Reason = "Выполненный план разработки MVP P1"
    }
)

# Документы для удаления (временные)
$DeleteFiles = @(
    @{
        File = "File_Classification_Analysis.md"
        Reason = "Разовый анализ классификации файлов - больше не нужен"
    },
    @{
        File = "Files_To_Delete_List.md" 
        Reason = "Разовый список файлов для удаления - больше не актуален"
    }
)

# Документы для проверки (сомнительные)
$ReviewFiles = @(
    @{
        File = "Cleanup_Plan_v4.md"
        Reason = "План очистки выполнен, но может содержать полезную информацию"
    },
    @{
        File = "Test_Fixes_Plan.md"
        Reason = "План исправления тестов выполнен"
    },
    @{
        File = "Test_Fixes_Report.md"
        Reason = "Отчет об исправлении тестов"
    }
)

Write-Host "[1/3] Архивация устаревших документов..." -ForegroundColor Yellow

$archivedCount = 0
foreach ($item in $ArchiveFiles) {
    $sourcePath = Join-Path $DocsPath $item.Source
    $targetPath = Join-Path $ArchiveDatePath $item.Target
    
    if (Test-Path $sourcePath) {
        if ($DryRun) {
            Write-Host "  📦 [DRY-RUN] Would archive: $($item.Source) -> archive\$DateFolder\$($item.Target)" -ForegroundColor Cyan
            Write-Host "     Причина: $($item.Reason)" -ForegroundColor Gray
        } else {
            try {
                Move-Item -Path $sourcePath -Destination $targetPath -Force
                Write-Host "  ✅ Заархивирован: $($item.Source)" -ForegroundColor Green
                Write-Host "     -> archive\$DateFolder\$($item.Target)" -ForegroundColor Gray
                $archivedCount++
            } catch {
                Write-Host "  ❌ Ошибка архивации $($item.Source): $_" -ForegroundColor Red
            }
        }
    } else {
        Write-Host "  ⚠️  Файл не найден: $($item.Source)" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "[2/3] Удаление временных документов..." -ForegroundColor Yellow

$deletedCount = 0
foreach ($item in $DeleteFiles) {
    $filePath = Join-Path $DocsPath $item.File
    
    if (Test-Path $filePath) {
        if ($DryRun) {
            Write-Host "  🗑️  [DRY-RUN] Would delete: $($item.File)" -ForegroundColor Cyan
            Write-Host "     Причина: $($item.Reason)" -ForegroundColor Gray
        } else {
            if ($Force -or (Read-Host "Удалить $($item.File)? (y/N)") -eq 'y') {
                try {
                    Remove-Item -Path $filePath -Force
                    Write-Host "  ✅ Удален: $($item.File)" -ForegroundColor Green
                    $deletedCount++
                } catch {
                    Write-Host "  ❌ Ошибка удаления $($item.File): $_" -ForegroundColor Red
                }
            } else {
                Write-Host "  ⏭️  Пропущен: $($item.File)" -ForegroundColor Gray
            }
        }
    } else {
        Write-Host "  ⚠️  Файл не найден: $($item.File)" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "[3/3] Файлы для ручной проверки..." -ForegroundColor Yellow

foreach ($item in $ReviewFiles) {
    $filePath = Join-Path $DocsPath $item.File
    
    if (Test-Path $filePath) {
        $fileSize = [math]::Round((Get-Item $filePath).Length / 1KB, 1)
        Write-Host "  🔍 Требует проверки: $($item.File) (${fileSize} КБ)" -ForegroundColor Cyan
        Write-Host "     Причина: $($item.Reason)" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "📊 === ИТОГИ АРХИВАЦИИ ===" -ForegroundColor Cyan

if ($DryRun) {
    Write-Host "🎭 РЕЖИМ СИМУЛЯЦИИ - файлы не изменены" -ForegroundColor Yellow
    Write-Host "📦 Файлов для архивации: $($ArchiveFiles.Count)"
    Write-Host "🗑️  Файлов для удаления: $($DeleteFiles.Count)" 
    Write-Host "🔍 Файлов для проверки: $($ReviewFiles.Count)"
    Write-Host ""
    Write-Host "💡 Для выполнения запустите без -DryRun"
} else {
    Write-Host "✅ Заархивировано файлов: $archivedCount" -ForegroundColor Green
    Write-Host "🗑️  Удалено файлов: $deletedCount" -ForegroundColor Green
    Write-Host "📁 Папка архива: docs\archive\$DateFolder" -ForegroundColor Cyan
    
    if ($archivedCount -gt 0 -or $deletedCount -gt 0) {
        Write-Host ""
        Write-Host "🎯 Следующие шаги:" -ForegroundColor White
        Write-Host "  1. Проверить файлы в разделе 'для проверки'" -ForegroundColor Gray
        Write-Host "  2. Объединить дублирующие документы" -ForegroundColor Gray
        Write-Host "  3. Обновить существующие документы" -ForegroundColor Gray
        Write-Host "  4. Создать новые документы процедур" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "📚 Архивация документов завершена!" -ForegroundColor Cyan
