# Демонстрация исправлений HH-бота v4
# // Chg_DEMO_SHOWCASE_2009: Показ результатов исправлений

$ErrorActionPreference = "Stop"

Write-Host "🎯 === ДЕМОНСТРАЦИЯ ИСПРАВЛЕНИЙ HH-БОТА v4 ===" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/5] Checking test improvements..." -ForegroundColor Yellow

# Запуск исправленных тестов
Write-Host "  🧪 Running functional tests..."
$TestResult = python tests/functional_test_runner.py 2>&1
$TestOutput = $TestResult -join "`n"

# Извлекаем успешность
if ($TestOutput -match "Успешность: ([0-9.]+)%") {
    $SuccessRate = $Matches[1]
    Write-Host "  ✅ Test success rate: $SuccessRate%" -ForegroundColor Green
    
    if ([float]$SuccessRate -gt 60) {
        Write-Host "  🎉 Improvement confirmed!" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️  Needs more work" -ForegroundColor Yellow
    }
} else {
    Write-Host "  ❌ Could not determine success rate" -ForegroundColor Red
}

Write-Host ""
Write-Host "[2/5] Checking database status..." -ForegroundColor Yellow

# Проверка БД
try {
    $DbCheck = python -c "from core.database_v3 import VacancyDatabase; db = VacancyDatabase(); tables = db.get_table_names(); print(f'Tables: {len(tables)}'); stats = db.get_stats(); print(f'Vacancies: {stats.get(\"total_vacancies\", 0)}')" 2>&1
    
    Write-Host "  ✅ Database accessible" -ForegroundColor Green
    $DbCheck | ForEach-Object { Write-Host "    $_" -ForegroundColor White }
} catch {
    Write-Host "  ❌ Database issues: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "[3/5] Checking web dashboard..." -ForegroundColor Yellow

# Проверка веб-панели
$WebProcess = Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*monitoring_dashboard*" }

if ($WebProcess) {
    Write-Host "  ✅ Web dashboard running (PID: $($WebProcess.Id))" -ForegroundColor Green
    Write-Host "  🌐 URL: http://localhost:5000" -ForegroundColor Cyan
} else {
    Write-Host "  ⚠️  Web dashboard not running" -ForegroundColor Yellow
    Write-Host "  💡 Start with: python web/monitoring_dashboard.py" -ForegroundColor Gray
}

Write-Host ""
Write-Host "[4/5] File cleanup status..." -ForegroundColor Yellow

# Поиск временных файлов
$TempFiles = @()
$TempFiles += Get-ChildItem "data\test_*.sqlite3" -ErrorAction SilentlyContinue
$TempFiles += Get-ChildItem "$env:TEMP\test_*.sqlite3" -ErrorAction SilentlyContinue

if ($TempFiles.Count -eq 0) {
    Write-Host "  ✅ No temporary test files found" -ForegroundColor Green
} else {
    Write-Host "  ⚠️  Found $($TempFiles.Count) temporary files" -ForegroundColor Yellow
    $TempFiles | ForEach-Object {
        Write-Host "    $($_.Name)" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "[5/5] System readiness check..." -ForegroundColor Yellow

# Финальная проверка готовности
$ReadinessScore = 0
$TotalChecks = 4

# Проверка 1: Импорты работают
try {
    python -c "from core.database_v3 import VacancyDatabase; from web.monitoring_dashboard import MonitoringService; print('OK')" | Out-Null
    $ReadinessScore++
    Write-Host "  ✅ Core imports working" -ForegroundColor Green
} catch {
    Write-Host "  ❌ Import issues" -ForegroundColor Red
}

# Проверка 2: CLI команды работают
try {
    $CliResult = python cli_v4.py stats --help 2>&1
    if ($CliResult -like "*статистика*") {
        $ReadinessScore++
        Write-Host "  ✅ CLI commands working" -ForegroundColor Green
    }
} catch {
    Write-Host "  ❌ CLI issues" -ForegroundColor Red
}

# Проверка 3: Конфигурация найдена
if (Test-Path "config\config_v4.json") {
    $ReadinessScore++
    Write-Host "  ✅ Configuration found" -ForegroundColor Green
} else {
    Write-Host "  ⚠️  Configuration missing" -ForegroundColor Yellow
}

# Проверка 4: БД создается
try {
    python -c "from core.database_v3 import VacancyDatabase; import tempfile; import os; import uuid; uid=uuid.uuid4().hex[:8]; path=os.path.join(tempfile.gettempdir(), f'readiness_{uid}.sqlite3'); db=VacancyDatabase(path); print('OK'); os.remove(path)" | Out-Null
    $ReadinessScore++
    Write-Host "  ✅ Database creation working" -ForegroundColor Green
} catch {
    Write-Host "  ❌ Database creation issues" -ForegroundColor Red
}

$ReadinessPercentage = [math]::Round(($ReadinessScore / $TotalChecks) * 100)

Write-Host ""
Write-Host "🏁 === ИТОГИ ДЕМОНСТРАЦИИ ===" -ForegroundColor Cyan
Write-Host "📈 System Readiness: $ReadinessPercentage% ($ReadinessScore/$TotalChecks checks passed)" -ForegroundColor White

if ($ReadinessPercentage -ge 75) {
    $Status = "ГОТОВ К ИСПОЛЬЗОВАНИЮ"
    $Color = "Green"
} elseif ($ReadinessPercentage -ge 50) {
    $Status = "ТРЕБУЕТ ДОРАБОТКИ"
    $Color = "Yellow"
} else {
    $Status = "НЕ ГОТОВ"
    $Color = "Red"
}

Write-Host "🎯 Status: $Status" -ForegroundColor $Color
Write-Host ""

Write-Host "📋 Next Steps:" -ForegroundColor White
Write-Host "  1. Open web dashboard: http://localhost:5000" -ForegroundColor Gray
Write-Host "  2. Run full tests: python tests/functional_test_runner.py" -ForegroundColor Gray
Write-Host "  3. Check stats: python cli_v4.py stats --days 7" -ForegroundColor Gray
Write-Host "  4. Continue with MVP development" -ForegroundColor Gray
