#!/usr/bin/env python3
"""
Скрипт мониторинга задач HH Tool v4
Показывает подробную информацию о выполнении задач
"""

import sys
import sqlite3
import json
import time
from datetime import datetime, timedelta
from pathlib import Path

def format_duration(seconds):
    """Форматировать длительность в читаемый вид"""
    if seconds is None:
        return "N/A"
    
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"

def format_timestamp(ts):
    """Форматировать timestamp в читаемый вид"""
    if ts is None:
        return "N/A"
    
    dt = datetime.fromtimestamp(ts)
    return dt.strftime('%H:%M:%S')

def get_db_connection():
    """Получить соединение с БД"""
    db_path = Path('data/hh_v4.sqlite3')
    
    if not db_path.exists():
        print(f"База данных не найдена: {db_path}")
        sys.exit(1)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def monitor_realtime():
    """Мониторинг задач в реальном времени"""
    print("=== HH Tool v4 - Real-time Task Monitor ===")
    print("Нажмите Ctrl+C для выхода\n")
    
    try:
        while True:
            conn = get_db_connection()
            
            # Текущие активные задачи
            running_tasks = conn.execute("""
                SELECT id, type, worker_id, started_at, timeout_sec, progress_json
                FROM tasks 
                WHERE status = 'running'
                ORDER BY started_at
            """).fetchall()
            
            # Очистить экран
            print("\033[2J\033[H")  # ANSI escape codes
            
            print(f"=== Task Monitor - {datetime.now().strftime('%H:%M:%S')} ===\n")
            
            if not running_tasks:
                print("Нет активных задач")
            else:
                print(f"{'Task ID':<12} {'Type':<15} {'Worker':<10} {'Runtime':<10} {'Progress'}")
                print("-" * 70)
                
                current_time = time.time()
                
                for task in running_tasks:
                    task_id = task['id'][:8] + "..."
                    task_type = task['type']
                    worker_id = task['worker_id'] or "N/A"
                    
                    # Время выполнения
                    if task['started_at']:
                        runtime = current_time - task['started_at']
                        runtime_str = format_duration(runtime)
                        
                        # Проверка таймаута
                        if task['timeout_sec'] and runtime > task['timeout_sec']:
                            runtime_str += " [TIMEOUT!]"
                    else:
                        runtime_str = "N/A"
                    
                    # Прогресс
                    progress = "N/A"
                    if task['progress_json']:
                        try:
                            prog_data = json.loads(task['progress_json'])
                            if 'chunk_progress' in prog_data:
                                progress = prog_data['chunk_progress']
                            elif 'current_page' in prog_data:
                                progress = f"page {prog_data['current_page']}"
                        except:
                            pass
                    
                    print(f"{task_id:<12} {task_type:<15} {worker_id:<10} {runtime_str:<10} {progress}")
            
            # Статистика за последний час
            conn.execute("""
                SELECT 
                    status,
                    COUNT(*) as count
                FROM tasks 
                WHERE created_at > ?
                GROUP BY status
            """, (time.time() - 3600,))
            
            stats = {}
            for row in conn.execute("""
                SELECT status, COUNT(*) as count
                FROM tasks 
                WHERE created_at > ?
                GROUP BY status
            """, (time.time() - 3600,)):
                stats[row['status']] = row['count']
            
            if stats:
                print(f"\nСтатистика за последний час:")
                for status, count in stats.items():
                    print(f"  {status}: {count}")
            
            conn.close()
            
            # Обновление каждые 5 секунд
            time.sleep(5)
            
    except KeyboardInterrupt:
        print("\nМониторинг остановлен")

def show_task_details(task_id):
    """Показать детальную информацию о задаче"""
    conn = get_db_connection()
    
    # Поиск задачи (поддержка частичного ID)
    task = conn.execute("""
        SELECT * FROM tasks 
        WHERE id LIKE ? OR id = ?
        ORDER BY created_at DESC
        LIMIT 1
    """, (f'{task_id}%', task_id)).fetchone()
    
    if not task:
        print(f"Задача не найдена: {task_id}")
        return
    
    print(f"=== Задача {task['id']} ===")
    print(f"Тип: {task['type']}")
    print(f"Статус: {task['status']}")
    print(f"Worker: {task['worker_id'] or 'N/A'}")
    
    # Временные метки
    print(f"\nВремя:")
    print(f"  Создана: {format_timestamp(task['created_at'])}")
    print(f"  Запущена: {format_timestamp(task['started_at'])}")
    print(f"  Завершена: {format_timestamp(task['finished_at'])}")
    
    if task['schedule_at']:
        print(f"  Запланирована: {format_timestamp(task['schedule_at'])}")
    
    # Длительность
    if task['started_at'] and task['finished_at']:
        duration = task['finished_at'] - task['started_at']
        print(f"  Длительность: {format_duration(duration)}")
    elif task['started_at']:
        duration = time.time() - task['started_at']
        print(f"  Длительность: {format_duration(duration)} (выполняется)")
    
    print(f"  Таймаут: {format_duration(task['timeout_sec'])}")
    
    # Параметры
    if task['params_json']:
        try:
            params = json.loads(task['params_json'])
            print(f"\nПараметры:")
            for key, value in params.items():
                if isinstance(value, dict) and 'name' in value:
                    print(f"  {key}: {value['name']}")
                elif isinstance(value, (str, int, bool)):
                    print(f"  {key}: {value}")
                else:
                    print(f"  {key}: {type(value).__name__}")
        except:
            print(f"\nПараметры (raw): {task['params_json'][:100]}...")
    
    # Прогресс
    if task['progress_json']:
        try:
            progress = json.loads(task['progress_json'])
            print(f"\nПрогресс:")
            for key, value in progress.items():
                print(f"  {key}: {value}")
        except:
            print(f"\nПрогресс (raw): {task['progress_json'][:100]}...")
    
    # Результат
    if task['result_json']:
        try:
            result = json.loads(task['result_json'])
            print(f"\nРезультат:")
            for key, value in result.items():
                print(f"  {key}: {value}")
        except:
            print(f"\nРезультат (raw): {task['result_json'][:100]}...")
    
    # Ошибка
    if task['error']:
        print(f"\nОшибка: {task['error']}")
    
    conn.close()

def show_statistics():
    """Показать статистику выполнения задач"""
    conn = get_db_connection()
    
    print("=== Статистика HH Tool v4 ===\n")
    
    # Общая статистика
    total_tasks = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
    print(f"Всего задач: {total_tasks}")
    
    if total_tasks == 0:
        print("Нет данных для статистики")
        return
    
    # По статусам
    print("\nПо статусам:")
    for row in conn.execute("""
        SELECT status, COUNT(*) as count,
               ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM tasks), 1) as percentage
        FROM tasks 
        GROUP BY status 
        ORDER BY count DESC
    """):
        print(f"  {row['status']}: {row['count']} ({row['percentage']}%)")
    
    # По типам
    print("\nПо типам:")
    for row in conn.execute("""
        SELECT type, COUNT(*) as count
        FROM tasks 
        GROUP BY type 
        ORDER BY count DESC
    """):
        print(f"  {row['type']}: {row['count']}")
    
    # Средняя длительность выполнения
    print("\nСредняя длительность выполнения:")
    for row in conn.execute("""
        SELECT 
            type,
            COUNT(*) as completed_count,
            AVG(finished_at - started_at) as avg_duration,
            MIN(finished_at - started_at) as min_duration,
            MAX(finished_at - started_at) as max_duration
        FROM tasks 
        WHERE status = 'completed' AND started_at IS NOT NULL AND finished_at IS NOT NULL
        GROUP BY type
    """):
        print(f"  {row['type']}:")
        print(f"    Завершено: {row['completed_count']}")
        print(f"    Среднее: {format_duration(row['avg_duration'])}")
        print(f"    Мин: {format_duration(row['min_duration'])}")
        print(f"    Макс: {format_duration(row['max_duration'])}")
    
    # Активность по времени (последние 24 часа)
    print(f"\nАктивность за последние 24 часа:")
    
    current_time = time.time()
    for hours_ago in [1, 6, 12, 24]:
        start_time = current_time - (hours_ago * 3600)
        count = conn.execute("""
            SELECT COUNT(*) FROM tasks 
            WHERE created_at > ?
        """, (start_time,)).fetchone()[0]
        
        print(f"  За {hours_ago}ч: {count} задач")
    
    # Топ ошибок
    print(f"\nТоп ошибок:")
    for row in conn.execute("""
        SELECT error, COUNT(*) as count
        FROM tasks 
        WHERE status = 'failed' AND error IS NOT NULL
        GROUP BY error 
        ORDER BY count DESC
        LIMIT 5
    """):
        error_short = row['error'][:50] + "..." if len(row['error']) > 50 else row['error']
        print(f"  {row['count']}x: {error_short}")
    
    conn.close()

def cleanup_old_tasks(days_to_keep=7):
    """Очистить старые задачи"""
    conn = get_db_connection()
    
    cutoff_time = time.time() - (days_to_keep * 86400)
    
    # Подсчитать сколько будет удалено
    to_delete = conn.execute("""
        SELECT COUNT(*) FROM tasks 
        WHERE created_at < ? AND status IN ('completed', 'failed')
    """, (cutoff_time,)).fetchone()[0]
    
    if to_delete == 0:
        print(f"Нет задач старше {days_to_keep} дней для удаления")
        return
    
    print(f"Будет удалено {to_delete} задач старше {days_to_keep} дней")
    
    # Подтверждение
    response = input("Продолжить? (y/N): ").strip().lower()
    if response != 'y':
        print("Отменено")
        return
    
    # Удалить старые задачи
    result = conn.execute("""
        DELETE FROM tasks 
        WHERE created_at < ? AND status IN ('completed', 'failed')
    """, (cutoff_time,))
    
    deleted_count = result.rowcount
    conn.commit()
    
    print(f"✓ Удалено {deleted_count} старых задач")
    
    # VACUUM для освобождения места
    print("Дефрагментация базы данных...")
    conn.execute("VACUUM")
    
    print("✓ Очистка завершена")
    conn.close()

def main():
    """Основная функция"""
    
    if len(sys.argv) < 2:
        print("Использование:")
        print("  python monitor_tasks.py monitor           # Real-time мониторинг")
        print("  python monitor_tasks.py info <task_id>    # Детали задачи")
        print("  python monitor_tasks.py stats             # Статистика")
        print("  python monitor_tasks.py cleanup [days]    # Очистка старых задач")
        return
    
    command = sys.argv[1]
    
    if command == 'monitor':
        monitor_realtime()
        
    elif command == 'info' and len(sys.argv) >= 3:
        task_id = sys.argv[2]
        show_task_details(task_id)
        
    elif command == 'stats':
        show_statistics()
        
    elif command == 'cleanup':
        days = int(sys.argv[2]) if len(sys.argv) >= 3 else 7
        cleanup_old_tasks(days)
        
    else:
        print(f"Неизвестная команда: {command}")

if __name__ == '__main__':
    main()
