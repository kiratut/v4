#!/usr/bin/env python3
"""
Database migration script: upgrade to v4 schema
Removes unnecessary fields, adds comments, creates proper indexes

// TEMP: Migration script, delete after successful migration
"""

import sqlite3
import time
import json
from pathlib import Path


def backup_database(db_path: str) -> str:
    """Create backup before migration"""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}_backup_{timestamp}"
    
    source = sqlite3.connect(db_path)
    backup = sqlite3.connect(backup_path)
    
    source.backup(backup)
    
    source.close()
    backup.close()
    
    print(f"✓ Database backup created: {backup_path}")
    return backup_path


def check_current_schema(cursor):
    """Analyze current database schema"""
    print("\n=== Current Schema Analysis ===")
    
    # Check tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    print(f"Tables: {tables}")
    
    # Check vacancies structure
    if 'vacancies' in tables:
        cursor.execute("PRAGMA table_info(vacancies)")
        columns = {row[1]: row[2] for row in cursor.fetchall()}
        print(f"Vacancies columns: {list(columns.keys())}")
        
        cursor.execute("SELECT COUNT(*) FROM vacancies")
        count = cursor.fetchone()[0]
        print(f"Vacancies count: {count}")
    
    # Check indexes
    cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='vacancies'")
    indexes = [row[0] for row in cursor.fetchall()]
    print(f"Vacancies indexes: {indexes}")
    
    return tables, columns if 'vacancies' in tables else {}


def migrate_vacancies_table(cursor):
    """Update vacancies table to v4 schema"""
    print("\n=== Migrating vacancies table ===")
    
    # Check existing columns
    cursor.execute("PRAGMA table_info(vacancies)")
    existing_cols = {row[1]: row[2] for row in cursor.fetchall()}
    
    # Add missing columns
    required_cols = {
        'created_at': 'REAL',
        'updated_at': 'REAL', 
        'is_processed': 'INTEGER DEFAULT 0'
    }
    
    for col_name, col_type in required_cols.items():
        if col_name not in existing_cols:
            print(f"  Adding column: {col_name} {col_type}")
            cursor.execute(f"ALTER TABLE vacancies ADD COLUMN {col_name} {col_type}")
        else:
            print(f"  Column {col_name} already exists")
    
    # Update missing timestamps for existing records
    cursor.execute("""
        UPDATE vacancies 
        SET created_at = processed_at,
            updated_at = processed_at
        WHERE created_at IS NULL OR updated_at IS NULL
    """)
    
    rows_updated = cursor.rowcount
    print(f"  Updated timestamps for {rows_updated} existing records")


def create_missing_indexes(cursor):
    """Create missing indexes for performance"""
    print("\n=== Creating missing indexes ===")
    
    indexes_to_create = [
        "CREATE INDEX IF NOT EXISTS idx_vacancies_hh_id ON vacancies(hh_id)",
        "CREATE INDEX IF NOT EXISTS idx_vacancies_filter_id ON vacancies(filter_id)",
        "CREATE INDEX IF NOT EXISTS idx_vacancies_published_at ON vacancies(published_at)",
        "CREATE INDEX IF NOT EXISTS idx_vacancies_processed_at ON vacancies(processed_at)",
        "CREATE INDEX IF NOT EXISTS idx_vacancies_content_hash ON vacancies(content_hash) WHERE content_hash IS NOT NULL",
        "CREATE INDEX IF NOT EXISTS idx_vacancies_created_at ON vacancies(created_at)",
        "CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)",
        "CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(type)",
        "CREATE INDEX IF NOT EXISTS idx_tasks_created_at ON tasks(created_at)"
    ]
    
    for idx_sql in indexes_to_create:
        try:
            cursor.execute(idx_sql)
            idx_name = idx_sql.split()[5]  # Extract index name
            print(f"  ✓ Created/verified index: {idx_name}")
        except sqlite3.Error as e:
            print(f"  ⚠ Index creation failed: {e}")


def cleanup_obsolete_tables(cursor):
    """Remove obsolete tables from v3"""
    print("\n=== Cleaning obsolete tables ===")
    
    # According to schema v4, plugin_results should be removed
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    obsolete_tables = ['plugin_results']  # Add more if needed
    
    for table in obsolete_tables:
        if table in tables:
            # Check if table has any data
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            
            if count > 0:
                print(f"  Table {table} has {count} records - renaming to {table}_old")
                cursor.execute(f"ALTER TABLE {table} RENAME TO {table}_old")
            else:
                print(f"  Dropping empty table: {table}")
                cursor.execute(f"DROP TABLE {table}")
        else:
            print(f"  Table {table} not found (already clean)")


def optimize_database(cursor):
    """Apply database optimizations"""
    print("\n=== Applying database optimizations ===")
    
    optimizations = [
        ("PRAGMA journal_mode=WAL", "Enable WAL mode for better concurrency"),
        ("PRAGMA synchronous=NORMAL", "Set synchronous mode to NORMAL"),
        ("PRAGMA cache_size=10000", "Increase cache size"),
        ("PRAGMA temp_store=MEMORY", "Store temp tables in memory"),
        ("ANALYZE", "Update table statistics for query optimization")
    ]
    
    for sql, description in optimizations:
        try:
            result = cursor.execute(sql).fetchone()
            if result:
                print(f"  ✓ {description}: {result[0]}")
            else:
                print(f"  ✓ {description}")
        except sqlite3.Error as e:
            print(f"  ⚠ {description} failed: {e}")


def verify_migration(cursor):
    """Verify migration was successful"""
    print("\n=== Migration Verification ===")
    
    # Check vacancies table structure
    cursor.execute("PRAGMA table_info(vacancies)")
    columns = [row[1] for row in cursor.fetchall()]
    
    required_columns = [
        'id', 'hh_id', 'title', 'company', 'filter_id', 
        'content_hash', 'processed_at', 'created_at', 'updated_at'
    ]
    
    missing = [col for col in required_columns if col not in columns]
    if missing:
        print(f"  ⚠ Missing required columns: {missing}")
        return False
    
    print(f"  ✓ All required columns present: {len(columns)} total")
    
    # Check indexes
    cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='vacancies'")
    indexes = [row[0] for row in cursor.fetchall()]
    
    required_indexes = ['idx_vacancies_hh_id', 'idx_vacancies_filter_id', 'idx_vacancies_content_hash']
    missing_idx = [idx for idx in required_indexes if idx not in indexes]
    if missing_idx:
        print(f"  ⚠ Missing indexes: {missing_idx}")
    else:
        print(f"  ✓ All required indexes present: {len(indexes)} total")
    
    # Check record count
    cursor.execute("SELECT COUNT(*) FROM vacancies")
    count = cursor.fetchone()[0]
    print(f"  ✓ Vacancies preserved: {count} records")
    
    return len(missing) == 0


def main():
    """Main migration function"""
    db_path = "data/hh_v4.sqlite3"
    
    if not Path(db_path).exists():
        print(f"❌ Database not found: {db_path}")
        return False
    
    print("🔧 Starting database migration to v4 schema...")
    
    # Create backup
    backup_path = backup_database(db_path)
    
    try:
        # Connect to database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Enable foreign keys
        cursor.execute("PRAGMA foreign_keys=ON")
        
        # Analyze current state
        tables, columns = check_current_schema(cursor)
        
        # Perform migration steps
        migrate_vacancies_table(cursor)
        create_missing_indexes(cursor)
        cleanup_obsolete_tables(cursor)
        optimize_database(cursor)
        
        # Verify migration
        success = verify_migration(cursor)
        
        if success:
            print("\n✅ Migration completed successfully!")
            conn.commit()
            
            # Clean up backup if migration successful
            cleanup_old_backups()
            
        else:
            print("\n❌ Migration verification failed!")
            conn.rollback()
            return False
            
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        conn.rollback()
        
        # Restore from backup
        print(f"Restoring from backup: {backup_path}")
        Path(db_path).unlink()
        Path(backup_path).rename(db_path)
        return False
        
    finally:
        conn.close()
    
    return True


def cleanup_old_backups():
    """Remove old backup files, keep last 3"""
    backup_pattern = "data/hh_v4.sqlite3_backup_*"
    backups = list(Path(".").glob(backup_pattern))
    
    if len(backups) > 3:
        # Sort by modification time, keep newest 3
        backups.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for old_backup in backups[3:]:
            old_backup.unlink()
            print(f"  Cleaned old backup: {old_backup}")


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
