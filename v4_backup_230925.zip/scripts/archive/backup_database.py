#!/usr/bin/env python3
"""
Скрипт для создания backup базы данных HH Tool v4
"""

import os
import shutil
import sqlite3
import gzip
import json
from datetime import datetime
from pathlib import Path

def create_backup():
    """Создание полного backup базы данных"""
    
    # Пути
    db_path = Path('data/hh_v4.sqlite3')
    backup_dir = Path('backups')
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Создать папку backup если нет
    backup_dir.mkdir(exist_ok=True)
    
    if not db_path.exists():
        print(f"База данных не найдена: {db_path}")
        return False
    
    print(f"Создание backup базы данных HH Tool v4...")
    print(f"Источник: {db_path}")
    
    # 1. Простая копия файла БД
    file_backup = backup_dir / f'hh_v4_file_backup_{timestamp}.sqlite3'
    shutil.copy2(db_path, file_backup)
    file_size = file_backup.stat().st_size
    print(f"✓ Файловый backup: {file_backup} ({file_size:,} bytes)")
    
    # 2. SQL dump (сжатый)
    sql_backup = backup_dir / f'hh_v4_sql_dump_{timestamp}.sql.gz'
    with sqlite3.connect(db_path) as conn:
        with gzip.open(sql_backup, 'wt', encoding='utf-8') as f:
            for line in conn.iterdump():
                f.write(f'{line}\n')
    
    sql_size = sql_backup.stat().st_size
    print(f"✓ SQL dump: {sql_backup} ({sql_size:,} bytes)")
    
    # 3. Статистика и метаданные
    stats = get_database_stats(db_path)
    metadata = {
        'timestamp': timestamp,
        'database_path': str(db_path),
        'file_backup': str(file_backup),
        'sql_backup': str(sql_backup),
        'file_size_bytes': file_size,
        'sql_size_bytes': sql_size,
        'compression_ratio': round(sql_size / file_size, 3),
        'stats': stats
    }
    
    metadata_file = backup_dir / f'hh_v4_backup_metadata_{timestamp}.json'
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    print(f"✓ Метаданные: {metadata_file}")
    print(f"✓ Коэффициент сжатия: {metadata['compression_ratio']:.3f}")
    
    # 4. Очистка старых backup (оставляем 10 последних)
    cleanup_old_backups(backup_dir)
    
    return True

def get_database_stats(db_path):
    """Получить статистику базы данных"""
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        
        stats = {}
        
        # Количество записей в таблицах
        tables = ['tasks', 'vacancies']
        for table in tables:
            try:
                cursor = conn.execute(f"SELECT COUNT(*) as count FROM {table}")
                stats[f'{table}_count'] = cursor.fetchone()['count']
            except sqlite3.OperationalError:
                stats[f'{table}_count'] = 0
        
        # Статистика задач по статусам
        try:
            cursor = conn.execute("""
                SELECT status, COUNT(*) as count 
                FROM tasks 
                GROUP BY status
            """)
            task_stats = {row['status']: row['count'] for row in cursor.fetchall()}
            stats['task_status_breakdown'] = task_stats
        except sqlite3.OperationalError:
            stats['task_status_breakdown'] = {}
        
        # Статистика вакансий по фильтрам
        try:
            cursor = conn.execute("""
                SELECT filter_id, COUNT(*) as count 
                FROM vacancies 
                WHERE filter_id IS NOT NULL
                GROUP BY filter_id 
                ORDER BY count DESC
                LIMIT 10
            """)
            filter_stats = {row['filter_id']: row['count'] for row in cursor.fetchall()}
            stats['top_filters'] = filter_stats
        except sqlite3.OperationalError:
            stats['top_filters'] = {}
        
        # Размер БД
        cursor = conn.execute("PRAGMA page_count")
        page_count = cursor.fetchone()[0]
        cursor = conn.execute("PRAGMA page_size")
        page_size = cursor.fetchone()[0]
        stats['db_size_bytes'] = page_count * page_size
        
        return stats

def cleanup_old_backups(backup_dir, keep_count=10):
    """Удалить старые backup файлы, оставить только последние"""
    
    # Найти все backup файлы
    file_backups = list(backup_dir.glob('hh_v4_file_backup_*.sqlite3'))
    sql_backups = list(backup_dir.glob('hh_v4_sql_dump_*.sql.gz'))
    metadata_files = list(backup_dir.glob('hh_v4_backup_metadata_*.json'))
    
    # Сортировать по времени создания (от новых к старым)
    for backup_list in [file_backups, sql_backups, metadata_files]:
        backup_list.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    # Удалить старые файлы (оставить только keep_count последних)
    deleted_count = 0
    
    for backup_list in [file_backups, sql_backups, metadata_files]:
        for old_backup in backup_list[keep_count:]:
            old_backup.unlink()
            deleted_count += 1
    
    if deleted_count > 0:
        print(f"✓ Удалено {deleted_count} старых backup файлов")

def restore_from_file(backup_file, target_db='data/hh_v4_restored.sqlite3'):
    """Восстановление из файлового backup"""
    backup_path = Path(backup_file)
    
    if not backup_path.exists():
        print(f"Backup файл не найден: {backup_path}")
        return False
    
    target_path = Path(target_db)
    shutil.copy2(backup_path, target_path)
    
    print(f"✓ База данных восстановлена: {backup_path} -> {target_path}")
    return True

def restore_from_sql(backup_file, target_db='data/hh_v4_restored.sqlite3'):
    """Восстановление из SQL dump"""
    backup_path = Path(backup_file)
    
    if not backup_path.exists():
        print(f"SQL dump не найден: {backup_path}")
        return False
    
    target_path = Path(target_db)
    
    # Удалить старую БД если есть
    if target_path.exists():
        target_path.unlink()
    
    # Восстановить из SQL dump
    with sqlite3.connect(target_path) as conn:
        if backup_path.suffix == '.gz':
            with gzip.open(backup_path, 'rt', encoding='utf-8') as f:
                conn.executescript(f.read())
        else:
            with open(backup_path, 'r', encoding='utf-8') as f:
                conn.executescript(f.read())
    
    print(f"✓ База данных восстановлена из SQL: {backup_path} -> {target_path}")
    return True

def list_backups():
    """Показать список всех backup'ов"""
    backup_dir = Path('backups')
    
    if not backup_dir.exists():
        print("Папка backups не найдена")
        return
    
    # Найти metadata файлы
    metadata_files = list(backup_dir.glob('hh_v4_backup_metadata_*.json'))
    metadata_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    if not metadata_files:
        print("Backup'ы не найдены")
        return
    
    print(f"\n{'Timestamp':<17} {'Size (MB)':<10} {'Tasks':<8} {'Vacancies':<12} {'Compression'}")
    print("-" * 70)
    
    for metadata_file in metadata_files:
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            timestamp = data['timestamp']
            size_mb = round(data['file_size_bytes'] / (1024*1024), 1)
            tasks = data['stats'].get('tasks_count', 0)
            vacancies = data['stats'].get('vacancies_count', 0)
            compression = data['compression_ratio']
            
            print(f"{timestamp:<17} {size_mb:<10} {tasks:<8} {vacancies:<12} {compression:.3f}")
            
        except Exception as e:
            print(f"Ошибка чтения {metadata_file}: {e}")

def main():
    """Основная функция"""
    import sys
    
    if len(sys.argv) < 2:
        print("Использование:")
        print("  python backup_database.py create          # Создать backup")
        print("  python backup_database.py list            # Показать список backup'ов")
        print("  python backup_database.py restore-file <backup.sqlite3>   # Восстановить из файла")
        print("  python backup_database.py restore-sql <backup.sql.gz>     # Восстановить из SQL")
        return
    
    command = sys.argv[1]
    
    if command == 'create':
        create_backup()
        
    elif command == 'list':
        list_backups()
        
    elif command == 'restore-file' and len(sys.argv) >= 3:
        backup_file = sys.argv[2]
        restore_from_file(backup_file)
        
    elif command == 'restore-sql' and len(sys.argv) >= 3:
        backup_file = sys.argv[2]
        restore_from_sql(backup_file)
        
    else:
        print(f"Неизвестная команда: {command}")

if __name__ == '__main__':
    main()
