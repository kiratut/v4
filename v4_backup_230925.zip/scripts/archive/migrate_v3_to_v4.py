#!/usr/bin/env python3
"""
Скрипт миграции данных из HH Tool v3 в v4
"""

import sys
import sqlite3
import json
import hashlib
from pathlib import Path
from datetime import datetime

def get_content_hash(title, company, description):
    """Создать хеш содержимого для дедупликации"""
    content = f"{title}|{company}|{description or ''}"
    return hashlib.sha256(content.encode('utf-8')).hexdigest()

def migrate_vacancies(v3_db_path, v4_db_path):
    """Миграция вакансий из v3 в v4"""
    
    v3_path = Path(v3_db_path)
    v4_path = Path(v4_db_path)
    
    if not v3_path.exists():
        print(f"v3 база данных не найдена: {v3_path}")
        return False
    
    print(f"Миграция вакансий: {v3_path} -> {v4_path}")
    
    # Подключения к базам
    v3_conn = sqlite3.connect(v3_path)
    v3_conn.row_factory = sqlite3.Row
    
    v4_conn = sqlite3.connect(v4_path)
    
    try:
        # Получить все вакансии из v3
        cursor = v3_conn.execute("""
            SELECT * FROM vacancies 
            ORDER BY id
        """)
        
        v3_vacancies = cursor.fetchall()
        print(f"Найдено {len(v3_vacancies)} вакансий в v3")
        
        migrated_count = 0
        skipped_count = 0
        
        for v3_vacancy in v3_vacancies:
            # Проверить есть ли уже такая вакансия в v4
            existing = v4_conn.execute(
                "SELECT id FROM vacancies WHERE hh_id = ?", 
                (v3_vacancy['hh_id'],)
            ).fetchone()
            
            if existing:
                skipped_count += 1
                continue
            
            # Подготовить данные для v4
            content_hash = get_content_hash(
                v3_vacancy['title'],
                v3_vacancy.get('employer_name', ''),
                v3_vacancy.get('description', '')
            )
            
            # Маппинг полей v3 -> v4
            v4_data = {
                'hh_id': v3_vacancy['hh_id'],
                'title': v3_vacancy['title'],
                'company': v3_vacancy.get('employer_name'),
                'employer_id': v3_vacancy.get('employer_id'),
                'salary_from': v3_vacancy.get('salary_from'),
                'salary_to': v3_vacancy.get('salary_to'),
                'currency': v3_vacancy.get('currency'),
                'experience': v3_vacancy.get('experience'),
                'schedule': v3_vacancy.get('schedule'),
                'employment': v3_vacancy.get('employment'),
                'description': v3_vacancy.get('description'),
                'key_skills': v3_vacancy.get('key_skills'),
                'area': v3_vacancy.get('area_name'),
                'published_at': v3_vacancy.get('published_at'),
                'url': v3_vacancy.get('url'),
                'processed_at': datetime.now().timestamp(),
                'filter_id': 'migrated_from_v3',
                'content_hash': content_hash,
                'raw_json': None  # v3 может не иметь raw_json
            }
            
            # Вставить в v4
            v4_conn.execute("""
                INSERT INTO vacancies (
                    hh_id, title, company, employer_id, 
                    salary_from, salary_to, currency,
                    experience, schedule, employment,
                    description, key_skills, area,
                    published_at, url, processed_at,
                    filter_id, content_hash, raw_json
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                    ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            """, (
                v4_data['hh_id'], v4_data['title'], v4_data['company'], v4_data['employer_id'],
                v4_data['salary_from'], v4_data['salary_to'], v4_data['currency'],
                v4_data['experience'], v4_data['schedule'], v4_data['employment'],
                v4_data['description'], v4_data['key_skills'], v4_data['area'],
                v4_data['published_at'], v4_data['url'], v4_data['processed_at'],
                v4_data['filter_id'], v4_data['content_hash'], v4_data['raw_json']
            ))
            
            migrated_count += 1
            
            if migrated_count % 100 == 0:
                print(f"Мигрировано {migrated_count} вакансий...")
        
        v4_conn.commit()
        
        print(f"✓ Миграция завершена:")
        print(f"  Мигрировано: {migrated_count}")
        print(f"  Пропущено (дубли): {skipped_count}")
        
        return True
        
    except Exception as e:
        print(f"Ошибка миграции: {e}")
        v4_conn.rollback()
        return False
        
    finally:
        v3_conn.close()
        v4_conn.close()

def migrate_filters(v3_config_path, v4_config_path):
    """Миграция фильтров из v3 в v4"""
    
    v3_path = Path(v3_config_path)
    v4_path = Path(v4_config_path)
    
    if not v3_path.exists():
        print(f"v3 конфиг фильтров не найден: {v3_path}")
        return False
    
    print(f"Миграция фильтров: {v3_path} -> {v4_path}")
    
    try:
        # Загрузить v3 фильтры
        with open(v3_path, 'r', encoding='utf-8') as f:
            v3_filters = json.load(f)
        
        # Проверить структуру
        if 'filters' not in v3_filters:
            print("Неверная структура v3 фильтров")
            return False
        
        # Загрузить существующие v4 фильтры если есть
        v4_filters = {'filters': []}
        if v4_path.exists():
            with open(v4_path, 'r', encoding='utf-8') as f:
                v4_filters = json.load(f)
        
        # Получить ID существующих фильтров v4
        existing_ids = {f['id'] for f in v4_filters['filters']}
        
        # Мигрировать фильтры
        migrated_count = 0
        for v3_filter in v3_filters['filters']:
            filter_id = v3_filter.get('id')
            
            if not filter_id:
                print(f"Фильтр без ID пропущен: {v3_filter}")
                continue
            
            if filter_id in existing_ids:
                print(f"Фильтр {filter_id} уже существует в v4, пропущен")
                continue
            
            # Адаптировать фильтр для v4
            v4_filter = {
                'id': filter_id,
                'name': v3_filter.get('name', filter_id),
                'params': v3_filter.get('params', {}),
                'active': v3_filter.get('active', True),
                'migrated_from_v3': True
            }
            
            v4_filters['filters'].append(v4_filter)
            migrated_count += 1
            print(f"✓ Мигрирован фильтр: {filter_id}")
        
        # Сохранить v4 фильтры
        v4_path.parent.mkdir(parents=True, exist_ok=True)
        with open(v4_path, 'w', encoding='utf-8') as f:
            json.dump(v4_filters, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Миграция фильтров завершена: {migrated_count} фильтров")
        return True
        
    except Exception as e:
        print(f"Ошибка миграции фильтров: {e}")
        return False

def validate_v4_database(v4_db_path):
    """Проверить целостность v4 базы данных после миграции"""
    
    v4_path = Path(v4_db_path)
    
    if not v4_path.exists():
        print(f"v4 база данных не найдена: {v4_path}")
        return False
    
    try:
        conn = sqlite3.connect(v4_path)
        conn.row_factory = sqlite3.Row
        
        # Проверить таблицы
        tables_check = conn.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name IN ('tasks', 'vacancies')
        """).fetchall()
        
        table_names = {row['name'] for row in tables_check}
        
        if 'tasks' not in table_names:
            print("❌ Таблица tasks не найдена")
            return False
        
        if 'vacancies' not in table_names:
            print("❌ Таблица vacancies не найдена")
            return False
        
        # Статистика вакансий
        vacancy_stats = conn.execute("""
            SELECT 
                COUNT(*) as total,
                COUNT(DISTINCT hh_id) as unique_hh_ids,
                COUNT(DISTINCT content_hash) as unique_content,
                COUNT(*) - COUNT(DISTINCT content_hash) as potential_duplicates
            FROM vacancies
        """).fetchone()
        
        print("✓ Проверка v4 базы данных:")
        print(f"  Всего вакансий: {vacancy_stats['total']}")
        print(f"  Уникальных hh_id: {vacancy_stats['unique_hh_ids']}")
        print(f"  Уникального контента: {vacancy_stats['unique_content']}")
        print(f"  Потенциальных дублей: {vacancy_stats['potential_duplicates']}")
        
        # Проверить индексы
        indexes = conn.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND name LIKE 'idx_%'
        """).fetchall()
        
        print(f"  Индексов: {len(indexes)}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"Ошибка проверки v4 БД: {e}")
        return False

def main():
    """Основная функция миграции"""
    
    if len(sys.argv) < 2:
        print("Использование:")
        print("  python migrate_v3_to_v4.py all                    # Полная миграция")
        print("  python migrate_v3_to_v4.py vacancies              # Только вакансии")
        print("  python migrate_v3_to_v4.py filters                # Только фильтры")
        print("  python migrate_v3_to_v4.py validate               # Проверить v4 БД")
        print()
        print("Пути по умолчанию:")
        print("  v3 БД: ../data/hh_v3.sqlite3")
        print("  v4 БД: data/hh_v4.sqlite3")
        print("  v3 фильтры: ../config/filters.json")
        print("  v4 фильтры: config/filters.json")
        return
    
    command = sys.argv[1]
    
    # Пути по умолчанию
    v3_db = '../data/hh_v3.sqlite3'
    v4_db = 'data/hh_v4.sqlite3'
    v3_filters = '../config/filters.json'
    v4_filters = 'config/filters.json'
    
    success = True
    
    if command == 'all':
        print("=== Полная миграция v3 -> v4 ===\n")
        
        # Миграция фильтров
        success &= migrate_filters(v3_filters, v4_filters)
        print()
        
        # Миграция вакансий
        success &= migrate_vacancies(v3_db, v4_db)
        print()
        
        # Проверка результата
        success &= validate_v4_database(v4_db)
        
    elif command == 'vacancies':
        success = migrate_vacancies(v3_db, v4_db)
        
    elif command == 'filters':
        success = migrate_filters(v3_filters, v4_filters)
        
    elif command == 'validate':
        success = validate_v4_database(v4_db)
        
    else:
        print(f"Неизвестная команда: {command}")
        success = False
    
    if success:
        print("\n🎉 Миграция завершена успешно!")
    else:
        print("\n❌ Миграция завершена с ошибками")
        sys.exit(1)

if __name__ == '__main__':
    main()
