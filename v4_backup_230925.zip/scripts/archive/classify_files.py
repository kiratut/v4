#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Классификация файлов проекта HH-бота v4 для очистки

// Chg_CLASSIFY_2009: Анализ файлов перед очисткой
"""

import os
import re
from pathlib import Path
from datetime import datetime, timedelta

# Правила классификации из памяти
CLASSIFICATIONS = {
    'CORE': {
        'emoji': '🔴',
        'description': 'Критически важные - НЕ ТРОГАТЬ',
        'patterns': [
            r'cli_v4\.py$',
            r'core/.*\.py$',
            r'config/.*\.json$',
            r'data/hh_v4\.sqlite3$',
            r'requirements\.txt$'
        ]
    },
    'STABLE': {
        'emoji': '🟢', 
        'description': 'Стабильные - удалять осторожно',
        'patterns': [
            r'docs/(?!.*_draft|.*_tmp|.*analysis|.*plan).*\.md$',
            r'tests/(?!.*debug|.*temp).*\.py$',
            r'web/.*\.(py|html|css|js)$'
        ]
    },
    'ARCHIVE': {
        'emoji': '🟡',
        'description': 'Архивные - можно архивировать', 
        'patterns': [
            r'.*analysis.*\.md$',
            r'.*_old_.*',
            r'Architecture_v4_Part.*\.md$',
            r'.*plan.*\.md$',
            r'.*checklist.*\.md$',
            r'.*summary.*\.md$',
            r'.*_v[0-9]+\.md$'
        ]
    },
    'TEMP': {
        'emoji': '🔵',
        'description': 'Временные - удалять по возрасту',
        'patterns': [
            r'debug_.*',
            r'.*_temp\.',
            r'test_.*\.sqlite3$',
            r'.*\.tmp$',
            r'.*\.bak$',
            r'.*\.old$'
        ]
    },
    'CACHE': {
        'emoji': '⚫',
        'description': 'Кэш - удалять всегда',
        'patterns': [
            r'__pycache__',
            r'.*\.pyc$',
            r'\.pytest_cache',
            r'.*\.sqlite3-shm$',
            r'.*\.sqlite3-wal$'
        ]
    }
}

def classify_file(file_path: str, project_root: str) -> str:
    """Классифицирует файл по правилам"""
    relative_path = os.path.relpath(file_path, project_root).replace('\\', '/')
    
    for category, rules in CLASSIFICATIONS.items():
        for pattern in rules['patterns']:
            if re.search(pattern, relative_path):
                return category
    
    return 'STABLE'  # По умолчанию

def get_file_size_str(size_bytes: int) -> str:
    """Человекочитаемый размер файла"""
    if size_bytes > 1024*1024:
        return f"{size_bytes/(1024*1024):.1f} МБ"
    elif size_bytes > 1024:
        return f"{size_bytes/1024:.1f} КБ"
    else:
        return f"{size_bytes} б"

def main():
    """Основная функция классификации"""
    project_root = Path(__file__).parent.parent
    
    print("📋 === КЛАССИФИКАЦИЯ ФАЙЛОВ HH-БОТА v4 ===")
    print(f"📂 Проект: {project_root}")
    print(f"⏰ Время: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}")
    print()
    
    # Собираем все файлы
    all_files = {}
    for category in CLASSIFICATIONS:
        all_files[category] = []
    
    total_files = 0
    total_size = 0
    
    # Сканируем проект
    for file_path in project_root.rglob('*'):
        if file_path.is_file():
            category = classify_file(str(file_path), str(project_root))
            file_size = file_path.stat().st_size
            
            all_files[category].append({
                'path': str(file_path.relative_to(project_root)),
                'size': file_size,
                'age_days': (datetime.now() - datetime.fromtimestamp(file_path.stat().st_mtime)).days
            })
            
            total_files += 1
            total_size += file_size
    
    # Показываем статистику по категориям
    print("📊 СТАТИСТИКА ПО КАТЕГОРИЯМ:")
    print()
    
    for category, rules in CLASSIFICATIONS.items():
        files = all_files[category]
        count = len(files)
        category_size = sum(f['size'] for f in files)
        
        print(f"{rules['emoji']} {category}: {count} файлов, {get_file_size_str(category_size)}")
        print(f"   {rules['description']}")
        
        if category in ['TEMP', 'CACHE', 'ARCHIVE'] and count > 0:
            print("   Файлы для обработки:")
            for file in sorted(files, key=lambda x: x['size'], reverse=True)[:10]:  # Топ 10 по размеру
                age_str = f"{file['age_days']}д" if file['age_days'] > 0 else "сегодня"
                print(f"     • {file['path']} ({get_file_size_str(file['size'])}, {age_str})")
            
            if count > 10:
                print(f"     ... и еще {count - 10} файлов")
        print()
    
    # Рекомендации по очистке
    temp_files = all_files['TEMP']
    cache_files = all_files['CACHE'] 
    archive_files = all_files['ARCHIVE']
    
    cleanup_size = sum(f['size'] for f in temp_files + cache_files)
    archive_size = sum(f['size'] for f in archive_files)
    
    print("🎯 РЕКОМЕНДАЦИИ ПО ОЧИСТКЕ:")
    print()
    
    if cache_files:
        print(f"⚫ КЭШИ ({len(cache_files)} файлов, {get_file_size_str(sum(f['size'] for f in cache_files))}):")
        print("   ✅ УДАЛИТЬ СРАЗУ - пересоздаются автоматически")
    
    if temp_files:
        temp_old = [f for f in temp_files if f['age_days'] > 14]
        temp_recent = [f for f in temp_files if f['age_days'] <= 14]
        
        if temp_old:
            print(f"🔵 ВРЕМЕННЫЕ СТАРЫЕ ({len(temp_old)} файлов, {get_file_size_str(sum(f['size'] for f in temp_old))}):")
            print("   ✅ УДАЛИТЬ - старше 14 дней")
        
        if temp_recent:
            print(f"🔵 ВРЕМЕННЫЕ НОВЫЕ ({len(temp_recent)} файлов, {get_file_size_str(sum(f['size'] for f in temp_recent))}):")
            print("   ⚠️  ПРОВЕРИТЬ - могут использоваться")
    
    if archive_files:
        print(f"🟡 АРХИВНЫЕ ({len(archive_files)} файлов, {get_file_size_str(archive_size)}):")
        print("   📦 ПЕРЕМЕСТИТЬ в docs/archive/ с суффиксом даты")
    
    print()
    print("💾 ПОТЕНЦИАЛЬНОЕ ОСВОБОЖДЕНИЕ МЕСТА:")
    print(f"   🗑️  Удаление: {get_file_size_str(cleanup_size)}")
    print(f"   📦 Архивация: {get_file_size_str(archive_size)}")
    print(f"   📊 Всего: {get_file_size_str(cleanup_size + archive_size)}")
    
    print()
    print("🔧 КОМАНДЫ ДЛЯ ВЫПОЛНЕНИЯ:")
    print("   powershell -ExecutionPolicy Bypass -File scripts/cleanup_v4_enhanced.ps1 -DryRun")
    print("   powershell -ExecutionPolicy Bypass -File scripts/cleanup_v4_enhanced.ps1")

if __name__ == "__main__":
    main()
