#!/usr/bin/env python3
"""
Пересоздание БД v4 в точном соответствии со схемой Database_Schema_v4.md
"""

import sqlite3
import os
import shutil
from datetime import datetime

def recreate_database():
    db_path = "data/hh_v4.sqlite3"
    
    print("🗃️ Пересоздание БД HH Tool v4...")
    
    # Бэкап старой БД
    if os.path.exists(db_path):
        backup_path = f"data/hh_v4_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
        shutil.copy2(db_path, backup_path)
        print(f"📦 Создан бэкап: {backup_path}")
        os.remove(db_path)
    
    # Создаем новую БД
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("📋 Создание таблиц по схеме Database_Schema_v4.md...")
    
    # Таблица задач диспетчера (точно по схеме)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            params_json TEXT,
            progress_json TEXT,
            result_json TEXT,
            error TEXT,
            created_at REAL NOT NULL,
            started_at REAL,
            finished_at REAL,
            schedule_at REAL,
            timeout_sec INTEGER DEFAULT 3600,
            worker_id TEXT,
            
            CHECK (status IN ('pending', 'running', 'completed', 'failed')),
            CHECK (type IN ('load_vacancies', 'process_pipeline', 'cleanup', 'test'))
        );
    """)
    
    # Таблица вакансий (точно по схеме - исправлены поля!)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vacancies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hh_id TEXT,
            title TEXT,
            company TEXT,
            employer_id TEXT,
            salary_from INTEGER,
            salary_to INTEGER,
            currency TEXT,
            experience TEXT,
            schedule TEXT,
            employment TEXT,
            description TEXT,
            key_skills TEXT,
            area TEXT,
            published_at TEXT,
            url TEXT,
            processed_at REAL,
            filter_id TEXT,
            content_hash TEXT,
            raw_json TEXT
        );
    """)
    
    print("📇 Создание индексов...")
    
    # Индексы для tasks
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(type);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_created_at ON tasks(created_at);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_schedule_at ON tasks(schedule_at) WHERE schedule_at IS NOT NULL;")
    
    # Индексы для vacancies (правильные имена полей!)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vacancies_hh_id ON vacancies(hh_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vacancies_filter_id ON vacancies(filter_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vacancies_published_at ON vacancies(published_at);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vacancies_processed_at ON vacancies(processed_at);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vacancies_content_hash ON vacancies(content_hash) WHERE content_hash IS NOT NULL;")
    
    print("⚙️ Настройка БД...")
    
    # WAL режим для concurrent access
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA cache_size=10000;")
    cursor.execute("PRAGMA temp_store=MEMORY;")
    
    conn.commit()
    
    print("✅ Проверка созданной структуры...")
    
    # Проверяем таблицы
    tables = [row[0] for row in cursor.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    print(f"📋 Созданные таблицы: {tables}")
    
    # Проверяем индексы
    indexes = [row[0] for row in cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%'").fetchall()]
    print(f"📇 Созданные индексы: {indexes}")
    
    # Проверяем настройки
    journal_mode = cursor.execute("PRAGMA journal_mode").fetchone()[0]
    synchronous = cursor.execute("PRAGMA synchronous").fetchone()[0]
    print(f"⚙️ Journal mode: {journal_mode}, Synchronous: {synchronous}")
    
    conn.close()
    
    print("🎉 БД пересоздана успешно!")
    print(f"📊 Размер новой БД: {os.path.getsize(db_path)} байт")
    
    return True

if __name__ == "__main__":
    recreate_database()
