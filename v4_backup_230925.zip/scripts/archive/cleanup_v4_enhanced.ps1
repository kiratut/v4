# Улучшенная очистка проекта HH-бота v4
# // Chg_CLEANUP_V4_2009: Дополнен для новых файлов и исправлений

param(
    [switch]$DryRun,
    [switch]$Force,
    [switch]$ClassifyOnly
)

$ErrorActionPreference = "Stop"

# Определяем корень проекта
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Write-Progress($step, $max, $description) {
    Write-Host "[$step/$max] $description..." -ForegroundColor Yellow
}

function Write-Success($message) {
    Write-Host "  ✅ $message" -ForegroundColor Green
}

function Write-Warning($message) {
    Write-Host "  ⚠️  $message" -ForegroundColor Yellow
}

function Write-Info($message) {
    Write-Host "  ℹ️  $message" -ForegroundColor Cyan
}

function Remove-ItemSafely($path, $description) {
    if (Test-Path $path) {
        if ($DryRun) {
            Write-Info "[DRY-RUN] Would delete: $description"
            return $false
        } else {
            try {
                Remove-Item $path -Recurse -Force -ErrorAction Stop
                Write-Success "Deleted: $description" 
                return $true
            } catch {
                Write-Warning "Could not delete $description`: $_"
                return $false
            }
        }
    }
    return $false
}

function Move-ItemSafely($source, $destination, $description) {
    if (Test-Path $source) {
        if ($DryRun) {
            Write-Info "[DRY-RUN] Would move: $description"
            return $false
        } else {
            try {
                $destDir = Split-Path $destination -Parent
                if (-not (Test-Path $destDir)) {
                    New-Item -ItemType Directory -Path $destDir -Force | Out-Null
                }
                Move-Item $source $destination -Force -ErrorAction Stop
                Write-Success "Moved: $description"
                return $true
            } catch {
                Write-Warning "Could not move $description`: $_"
                return $false
            }
        }
    }
    return $false
}

Write-Host "🧹 === HH-БОТ v4 ОЧИСТКА ПРОЕКТА ===" -ForegroundColor Cyan
Write-Host "📂 Проект: $ProjectRoot"
Write-Host "⚡ Режим: $(if($DryRun){'DRY-RUN'}else{'EXECUTE'})"
Write-Host "⏰ Время: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')"
Write-Host ""

$totalFiles = 0
$totalSize = 0

# 1. Классификация файлов
Write-Progress 1 7 "Классификация файлов проекта"

$classifications = @{
    'CORE' = @()      # 🔴 Критически важные - НЕ ТРОГАТЬ
    'STABLE' = @()    # 🟢 Стабильные - удалять осторожно  
    'ARCHIVE' = @()   # 🟡 Архивные - можно архивировать
    'TEMP' = @()      # 🔵 Временные - удалять
    'CACHE' = @()     # ⚫ Кэш - удалять всегда
}

# Сканируем файлы
Get-ChildItem $ProjectRoot -Recurse -File | ForEach-Object {
    $relativePath = $_.FullName.Replace("$ProjectRoot\", "")
    $fileName = $_.Name
    $extension = $_.Extension
    
    # Классификация по правилам
    if ($fileName -match "(cli_v4\.py|database_v3\.py|config_v4\.json|hh_v4\.sqlite3$)") {
        $classifications['CORE'] += @{Path=$relativePath; Size=$_.Length; File=$_}
    }
    elseif ($fileName -match "(__pycache__|\.pyc$|\.pytest_cache)") {
        $classifications['CACHE'] += @{Path=$relativePath; Size=$_.Length; File=$_}
    }
    elseif ($fileName -match "(test_.*\.sqlite3$|.*debug.*|.*_temp\.|.*\.tmp$|.*\.bak$)") {
        $classifications['TEMP'] += @{Path=$relativePath; Size=$_.Length; File=$_}
    }
    elseif ($fileName -match "(.*analysis.*\.md$|.*_old_.*|Architecture_v4_Part.*|.*plan.*\.md$)") {
        $classifications['ARCHIVE'] += @{Path=$relativePath; Size=$_.Length; File=$_}
    }
    else {
        $classifications['STABLE'] += @{Path=$relativePath; Size=$_.Length; File=$_}
    }
}

# Показываем классификацию
foreach ($category in $classifications.Keys) {
    $count = $classifications[$category].Count
    $sizeTotal = ($classifications[$category] | Measure-Object -Property Size -Sum).Sum
    $sizeMsg = if ($sizeTotal -gt 1MB) { "$([math]::Round($sizeTotal/1MB, 1)) МБ" } else { "$([math]::Round($sizeTotal/1KB, 1)) КБ" }
    
    $emoji = switch ($category) {
        'CORE' { '🔴' }
        'STABLE' { '🟢' }
        'ARCHIVE' { '🟡' }
        'TEMP' { '🔵' }
        'CACHE' { '⚫' }
    }
    
    Write-Host "  $emoji $category`: $count файлов, $sizeMsg"
}

if ($ClassifyOnly) {
    Write-Host ""
    Write-Host "📋 ПОДРОБНАЯ КЛАССИФИКАЦИЯ:" -ForegroundColor White
    
    foreach ($category in @('TEMP', 'CACHE', 'ARCHIVE')) {
        if ($classifications[$category].Count -gt 0) {
            Write-Host ""
            Write-Host "  $category файлы:" -ForegroundColor Yellow
            $classifications[$category] | ForEach-Object {
                $sizeStr = if ($_.Size -gt 1KB) { "$([math]::Round($_.Size/1KB, 1))КБ" } else { "$($_.Size)б" }
                Write-Host "    $($_.Path) ($sizeStr)"
            }
        }
    }
    
    Write-Host ""
    Write-Host "💡 Для выполнения очистки запустите без -ClassifyOnly"
    return
}

# 2. Очистка кэша Python
Write-Progress 2 7 "Очистка кэша Python"

$cacheDeleted = 0
$classifications['CACHE'] | ForEach-Object {
    if (Remove-ItemSafely $_.File.FullName $_.Path) {
        $cacheDeleted++
        $totalFiles++
        $totalSize += $_.Size
    }
}

Write-Info "Обработано кэш-файлов: $cacheDeleted"

# 3. Очистка временных файлов
Write-Progress 3 7 "Очистка временных файлов"

$tempDeleted = 0
$classifications['TEMP'] | ForEach-Object {
    # Особая обработка для SQLite файлов - проверяем что они не используются
    if ($_.Path -match "\.sqlite3$") {
        try {
            # Попробуем открыть файл для записи, чтобы проверить блокировку
            $fileStream = [System.IO.File]::OpenWrite($_.File.FullName)
            $fileStream.Close()
            
            if (Remove-ItemSafely $_.File.FullName $_.Path) {
                $tempDeleted++
                $totalFiles++
                $totalSize += $_.Size
            }
        } catch {
            Write-Warning "Файл $($_.Path) используется другим процессом, пропускаем"
        }
    } else {
        if (Remove-ItemSafely $_.File.FullName $_.Path) {
            $tempDeleted++
            $totalFiles++
            $totalSize += $_.Size
        }
    }
}

Write-Info "Обработано временных файлов: $tempDeleted"

# 4. Архивация старых документов
Write-Progress 4 7 "Архивация устаревших документов"

$archiveDir = Join-Path $ProjectRoot "docs\archive"
if (-not (Test-Path $archiveDir)) {
    if (-not $DryRun) {
        New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null
    }
}

$archivedCount = 0
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

$classifications['ARCHIVE'] | ForEach-Object {
    $newName = "$([System.IO.Path]::GetFileNameWithoutExtension($_.File.Name))_archived_$timestamp$($_.File.Extension)"
    $destPath = Join-Path $archiveDir $newName
    
    if (Move-ItemSafely $_.File.FullName $destPath $_.Path) {
        $archivedCount++
    }
}

Write-Info "Заархивировано документов: $archivedCount"

# 5. Очистка data/.trash
Write-Progress 5 7 "Очистка корзины данных"

$trashDir = Join-Path $ProjectRoot "data\.trash"
$trashDeleted = 0

if (Test-Path $trashDir) {
    Get-ChildItem $trashDir -File | ForEach-Object {
        if (Remove-ItemSafely $_.FullName "trash/$($_.Name)") {
            $trashDeleted++
            $totalFiles++
            $totalSize += $_.Length
        }
    }
}

Write-Info "Очищено из корзины файлов: $trashDeleted"

# 6. Очистка старых backup'ов
Write-Progress 6 7 "Очистка старых backup файлов"

$dataDir = Join-Path $ProjectRoot "data"
$backupDeleted = 0
$cutoffDate = (Get-Date).AddDays(-30) # Удаляем backup'ы старше 30 дней

Get-ChildItem $dataDir -Filter "*backup*" -File | Where-Object {
    $_.LastWriteTime -lt $cutoffDate -and $_.Name -match "(backup|\.bak$)"
} | ForEach-Object {
    if (Remove-ItemSafely $_.FullName "backup/$($_.Name)") {
        $backupDeleted++
        $totalFiles++
        $totalSize += $_.Length
    }
}

Write-Info "Удалено старых backup'ов: $backupDeleted"

# 7. Финальная проверка и статистика
Write-Progress 7 7 "Финальная проверка проекта"

# Проверяем целостность основных файлов
$coreFiles = @("cli_v4.py", "core\database_v3.py", "config\config_v4.json")
$missingCore = @()

foreach ($file in $coreFiles) {
    if (-not (Test-Path (Join-Path $ProjectRoot $file))) {
        $missingCore += $file
    }
}

if ($missingCore.Count -gt 0) {
    Write-Warning "ВНИМАНИЕ: Отсутствуют критически важные файлы:"
    $missingCore | ForEach-Object { Write-Host "    ❌ $_" -ForegroundColor Red }
} else {
    Write-Success "Все критически важные файлы на месте"
}

# Итоговая статистика
Write-Host ""
Write-Host "📊 === ИТОГИ ОЧИСТКИ ===" -ForegroundColor Cyan

$sizeMB = [math]::Round($totalSize / 1MB, 2)
Write-Host "🗑️  Удалено файлов: $totalFiles"
Write-Host "💾 Освобождено места: $sizeMB МБ"
Write-Host "📂 Заархивировано: $archivedCount документов"

Write-Host ""
Write-Host "📋 Детализация:" -ForegroundColor White
Write-Host "  ⚫ Кэш Python: $cacheDeleted файлов"
Write-Host "  🔵 Временные: $tempDeleted файлов"
Write-Host "  🗑️  Корзина: $trashDeleted файлов"
Write-Host "  💾 Backup'ы: $backupDeleted файлов"

Write-Host ""
if ($DryRun) {
    Write-Host "⚠️  РЕЖИМ СИМУЛЯЦИИ - файлы не изменены" -ForegroundColor Yellow
    Write-Host "💡 Для выполнения запустите без -DryRun"
} else {
    Write-Host "✅ ОЧИСТКА ЗАВЕРШЕНА УСПЕШНО" -ForegroundColor Green
    Write-Host "🔍 Проверьте: python cli_v4.py stats"
}

Write-Host ""
Write-Host "🎯 Следующий этап: 1.2.1 Заглушки хостов (Дни 5-7)" -ForegroundColor Cyan
