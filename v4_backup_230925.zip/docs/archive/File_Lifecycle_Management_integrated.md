# Система управления жизненным циклом файлов - HH-бот v4

*Создано: 19.09.2025 21:35:00*

## 🏷️ Система маркировки файлов

### Принципы классификации

#### 🔴 CORE - Основные файлы системы
**Маркировка**: `# CORE:` в комментарии или `.core` в имени
**Правило**: НИКОГДА НЕ УДАЛЯТЬ автоматически
```
# CORE: Main application entry point
cli_v4.py

# CORE: Database schema and operations  
core/database_v3.py

# CORE: User configuration
config/config_v4.json
```

#### 🟢 STABLE - Стабильные файлы
**Маркировка**: `# STABLE:` в комментарии или отсутствие временных маркеров
**Правило**: Удалять только при явном указании пользователя
```
# STABLE: Project documentation
docs/Project_v4.md

# STABLE: Functional tests
tests/test_functional_business.py
```

#### 🟡 ARCHIVE - Архивные файлы  
**Маркировка**: `# ARCHIVE:` в комментарии или `_archive`, `_old` в имени
**Правило**: Можно архивировать в папку archive/
```
# ARCHIVE: Outdated architecture documentation
docs/Architecture_v4_Part1_TaskQueue.md

# Автоматически по имени
docs/architecture_old_20250919.md
```

#### 🔵 TEMP - Временные файлы
**Маркировка**: `# TEMP:` в комментарии или временные паттерны в имени
**Правило**: Удалять автоматически по возрасту
```
# TEMP: Debug output file
debug_output_20250919.log

# Автоматически по паттернам
*.tmp, *_temp.*, test_*.sqlite3, debug_*.py
```

#### ⚫ CACHE - Кэш и автогенерируемые
**Маркировка**: Стандартные папки и расширения
**Правило**: Можно удалять в любое время - пересоздается автоматически
```
__pycache__/
*.pyc
*.pyo
.pytest_cache/
node_modules/
```

## 📁 Структура файловой системы с маркировкой

### Предлагаемая организация
```
/hh_v3/v4/
├── 🔴 CORE FILES
│   ├── cli_v4.py                    # CORE: Main application
│   ├── README.md                    # CORE: User documentation
│   ├── core/                        # CORE: System modules
│   ├── config/                      # CORE: User configurations
│   └── data/hh_v4.sqlite3          # CORE: Production database
│
├── 🟢 STABLE FILES  
│   ├── docs/Project_v4.md          # STABLE: Main documentation
│   ├── docs/Req.md                 # STABLE: Requirements
│   ├── tests/test_*.py             # STABLE: Functional tests
│   └── web/                        # STABLE: Web interface
│
├── 🟡 ARCHIVE CANDIDATES
│   ├── docs/archive/               # Target for old docs
│   ├── docs/Analytics_*.md         # ARCHIVE: Analysis docs  
│   ├── docs/Architecture_v4_*.md   # ARCHIVE: Old architecture
│   └── scripts/archive/            # Target for old scripts
│
├── 🔵 TEMPORARY FILES
│   ├── logs/                       # TEMP: Log files (rotation)
│   ├── data/hh_v4_backup_*.sqlite3 # TEMP: Old backups
│   ├── data/.trash/                # TEMP: Quarantine folder
│   └── utils/debug_*.py            # TEMP: Debug scripts
│
└── ⚫ CACHE FILES
    ├── **/__pycache__/             # CACHE: Python bytecode
    ├── .pytest_cache/              # CACHE: Test cache
    └── node_modules/               # CACHE: NPM packages (if any)
```

## 🤖 Автоматизированные правила очистки

### Правила по возрасту файлов
```yaml
# cleanup_rules.yaml (концептуально)
rules:
  cache_files:
    patterns: ["**/__pycache__", "*.pyc", "*.pyo"]
    action: delete
    max_age: 0  # Удалять всегда
    
  temp_logs:
    patterns: ["logs/*.log", "logs/*.log.*"]  
    action: delete
    max_age: 14  # дней
    exceptions: ["logs/app.log"]  # Текущий лог
    
  old_backups:
    patterns: ["data/*_backup_*.sqlite3"]
    action: delete  
    max_age: 30  # дней
    keep_latest: 3  # Всегда оставлять последние 3
    
  debug_files:
    patterns: ["*debug*", "*_temp*", "test_*.sqlite3"]
    action: quarantine  # Сначала в карантин
    max_age: 7  # дней
    quarantine_days: 7  # Потом удалить из карантина
```

### Автоматические паттерны распознавания

#### Временные файлы (удалять)
```regex
# По расширению
\.(tmp|temp|bak|old)$

# По содержимому имени
.*(debug|test|temp|draft|tmp).*

# По дате в имени (старше 30 дней)
.*_20[0-9]{6}.*

# Резервные копии с временными метками
.*_backup_20[0-9]{6}_[0-9]{6}.*
```

#### Архивные файлы (в архив)
```regex
# Явная маркировка
.*(archive|old|deprecated).*

# Документы анализа и планирования
.*_(analysis|plan|checklist|summary)\.md$

# Версионные документы с суффиксами
.*_v[0-9]+\.md$
.*_Part[0-9]+.*\.md$
```

## 🛠️ Реализация в коде

### Автоматический классификатор файлов
```python
# file_classifier.py
class FileClassifier:
    """Классификатор файлов по жизненному циклу"""
    
    CORE_PATTERNS = [
        r'cli_v4\.py$', r'config/.*\.json$', r'core/.*\.py$',
        r'data/hh_v4\.sqlite3$', r'README\.md$'
    ]
    
    TEMP_PATTERNS = [
        r'.*\.(tmp|temp|bak)$', r'.*debug.*', r'.*_temp.*',
        r'test_.*\.sqlite3$', r'.*_backup_20\d{6}_.*'
    ]
    
    CACHE_PATTERNS = [
        r'__pycache__', r'\.pytest_cache', r'.*\.pyc$'
    ]
    
    ARCHIVE_PATTERNS = [
        r'.*_(analysis|plan|checklist|summary)\.md$',
        r'Architecture_v4_Part\d+.*\.md$'
    ]
    
    def classify_file(self, file_path: str) -> str:
        """Определить категорию файла"""
        if self._matches_patterns(file_path, self.CORE_PATTERNS):
            return 'CORE'
        elif self._matches_patterns(file_path, self.TEMP_PATTERNS):
            return 'TEMP'
        elif self._matches_patterns(file_path, self.CACHE_PATTERNS):
            return 'CACHE'
        elif self._matches_patterns(file_path, self.ARCHIVE_PATTERNS):
            return 'ARCHIVE'
        else:
            return 'STABLE'
```

### Интеграция с CLI
```python
# В cli_v4.py
@cli.command()
@click.option('--classify-only', is_flag=True, help='Только классифицировать файлы')
@click.option('--age-days', default=14, help='Возраст файлов для удаления')
def cleanup(classify_only: bool, age_days: int):
    """Автоматическая очистка проекта с классификацией файлов"""
    
    classifier = FileClassifier()
    
    for file_path in find_project_files():
        category = classifier.classify_file(file_path)
        age_days_actual = get_file_age_days(file_path)
        
        if classify_only:
            print(f"{category:8} {age_days_actual:3}d {file_path}")
            continue
            
        # Действия по категориям
        if category == 'CORE':
            continue  # Никогда не трогаем
        elif category == 'CACHE':
            remove_file(file_path)  # Удаляем без вопросов
        elif category == 'TEMP' and age_days_actual > age_days:
            quarantine_file(file_path)  # В карантин
        elif category == 'ARCHIVE':
            archive_file(file_path)  # В архив
```

## 📋 Правила для команды разработки

### При создании новых файлов

#### Обязательные комментарии в начале файла
```python
#!/usr/bin/env python3
# CORE: Main application entry point for HH-bot v4
# LIFECYCLE: permanent
# AUTHOR: AI Assistant
# CREATED: 2025-09-19
# DESCRIPTION: CLI interface for job vacancy collection system

# или

# TEMP: Debug script for API testing
# LIFECYCLE: delete_after=2025-10-01
# RELATED_TASK: Fix API authentication issues
```

#### Именование файлов
```bash
# Временные файлы - обязательно с датой/префиксом
debug_api_20250919.py
test_data_temp.json
backup_20250919_142301.sqlite3

# Архивные файлы - с суффиксом версии/даты
Architecture_v1_deprecated.md
analysis_old_20250919.md
plan_archive_v1.md

# Стабильные файлы - без временных маркеров
vacancy_processor.py
main_config.json
user_manual.md
```

### Автоматические проверки
```bash
# Pre-commit hook (концептуально)
./scripts/check_file_lifecycle.py --strict

# Еженедельная автоматическая очистка
crontab: 0 3 * * 0 /path/to/cleanup_project.bat --force
```

## 🎯 Внедрение системы

### Этап 1: Разметка существующих файлов (1 день)
- Добавить комментарии LIFECYCLE во все существующие файлы
- Переименовать временные файлы по новым правилам
- Создать первую версию cleanup_rules.yaml

### Этап 2: Автоматизация (2 дня)  
- Реализовать FileClassifier класс
- Интегрировать в cli_v4.py команду cleanup
- Создать и протестировать cleanup_project.bat

### Этап 3: Процедуры команды (1 день)
- Документировать правила для разработчиков
- Настроить автоматические проверки
- Обучить команду новым принципам именования

### Этап 4: Мониторинг (ongoing)
- Еженедельные отчеты о состоянии файловой системы
- Метрики использования диска и эффективности очистки
- Корректировка правил на основе опыта

## 📊 KPI системы управления файлами

### Метрики эффективности
- **Размер проекта**: не более 500МБ основных файлов
- **Временные файлы**: не старше 14 дней (кроме специальных случаев)
- **Архивы**: организованно структурированы по датам/версиям
- **Кэш**: очищается автоматически при каждом деплое

### Автоматические отчеты
```bash
# Еженедельный отчет
python cli_v4.py cleanup --report-only
# Покажет:
# - Общий размер проекта
# - Количество файлов по категориям  
# - Кандидаты на удаление/архивацию
# - Рекомендации по очистке
```

*Обновлено: 19.09.2025 21:35:00*
