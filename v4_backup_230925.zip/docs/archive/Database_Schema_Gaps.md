# Анализ пробелов схемы базы данных v4

*Создано: 19.09.2025 20:39:00*

## 🗄️ Текущее состояние схемы БД

### Существующие таблицы
- ✅ `vacancies` - основные поля вакансий
- ✅ `employers` - базовые поля работодателей  
- ✅ `tasks` - система задач
- ✅ `system_stats` - системные метрики
- ✅ `plugin_results` - результаты плагинов
- ✅ `process_status` - статусы процессов

## 🚨 Критические пробелы в схеме БД

### 1. Отсутствующие поля в таблице `vacancies`

#### Поля для требований 2.11-2.12 (Поиск и загрузка)
```sql
ALTER TABLE vacancies ADD COLUMN search_query_id TEXT;     -- Связь с поисковым запросом
ALTER TABLE vacancies ADD COLUMN found_page INTEGER;       -- На какой странице найдена
ALTER TABLE vacancies ADD COLUMN found_position INTEGER;   -- Позиция на странице
ALTER TABLE vacancies ADD COLUMN search_date DATE;         -- Дата поиска
ALTER TABLE vacancies ADD COLUMN load_attempts INTEGER DEFAULT 0; -- Попытки загрузки
ALTER TABLE vacancies ADD COLUMN last_load_error TEXT;     -- Последняя ошибка загрузки
```

#### Поля версионирования (требование 2.12.4)
```sql
ALTER TABLE vacancies ADD COLUMN is_unique_host1 BOOLEAN DEFAULT FALSE;  -- Уникальность на Хост 1
ALTER TABLE vacancies ADD COLUMN synced_to_host2 BOOLEAN DEFAULT FALSE;  -- Синхронизировано с БД2
ALTER TABLE vacancies ADD COLUMN sync_date TIMESTAMP;                     -- Дата синхронизации
ALTER TABLE vacancies ADD COLUMN duplicate_of INTEGER;                    -- ID дубликата
ALTER TABLE vacancies ADD COLUMN content_changes TEXT;                    -- JSON изменений контента
```

#### Поля аналитики (требования 2.13-2.16)
```sql
ALTER TABLE vacancies ADD COLUMN llm_processed BOOLEAN DEFAULT FALSE;     -- Обработано LLM
ALTER TABLE vacancies ADD COLUMN llm_processing_date TIMESTAMP;           -- Дата LLM обработки
ALTER TABLE vacancies ADD COLUMN relevance_score REAL;                    -- Оценка релевантности (0-10)
ALTER TABLE vacancies ADD COLUMN pros TEXT;                               -- Плюсы (LLM)
ALTER TABLE vacancies ADD COLUMN cons TEXT;                               -- Минусы (LLM)
ALTER TABLE vacancies ADD COLUMN limitations TEXT;                        -- Ограничения (LLM)
ALTER TABLE vacancies ADD COLUMN user_match_percent REAL;                 -- % соответствия профилю
ALTER TABLE vacancies ADD COLUMN generated_letter TEXT;                   -- Сгенерированное письмо
ALTER TABLE vacancies ADD COLUMN response_status TEXT;                    -- Статус отклика
ALTER TABLE vacancies ADD COLUMN response_date TIMESTAMP;                 -- Дата отклика
ALTER TABLE vacancies ADD COLUMN employer_response TEXT;                  -- Ответ работодателя
ALTER TABLE vacancies ADD COLUMN interview_scheduled BOOLEAN DEFAULT FALSE; -- Назначено собеседование
```

#### Технические поля HH API
```sql
ALTER TABLE vacancies ADD COLUMN hh_api_response TEXT;                     -- Полный ответ API (JSON)
ALTER TABLE vacancies ADD COLUMN view_count INTEGER;                      -- Просмотры на HH
ALTER TABLE vacancies ADD COLUMN response_count INTEGER;                  -- Отклики на HH
ALTER TABLE vacancies ADD COLUMN is_featured BOOLEAN DEFAULT FALSE;      -- Премиум размещение
ALTER TABLE vacancies ADD COLUMN publication_end_date DATE;              -- Дата окончания публикации
```

### 2. Отсутствующие поля в таблице `employers`

#### Поля для LLM обработки (требования 2.14, 3.5)
```sql
ALTER TABLE employers ADD COLUMN llm_processed BOOLEAN DEFAULT FALSE;     -- Обработано LLM
ALTER TABLE employers ADD COLUMN llm_processing_date TIMESTAMP;           -- Дата LLM обработки
ALTER TABLE employers ADD COLUMN company_size_category TEXT;              -- junior/middle/senior
ALTER TABLE employers ADD COLUMN industry_category TEXT;                  -- Отрасль
ALTER TABLE employers ADD COLUMN revenue_estimate TEXT;                   -- Оценка оборота
ALTER TABLE employers ADD COLUMN employee_count_estimate INTEGER;         -- Оценка численности
ALTER TABLE employers ADD COLUMN tech_stack TEXT;                         -- Технологии (JSON)
ALTER TABLE employers ADD COLUMN social_links TEXT;                       -- Соцсети (JSON)
ALTER TABLE employers ADD COLUMN news_mentions TEXT;                      -- Упоминания в новостях (JSON)
ALTER TABLE employers ADD COLUMN changes_summary TEXT;                    -- Краткое описание изменений
ALTER TABLE employers ADD COLUMN reputation_score REAL;                  -- Оценка репутации
```

#### Поля справочной информации
```sql
ALTER TABLE employers ADD COLUMN hh_employer_data TEXT;                   -- Полные данные с HH API (JSON)
ALTER TABLE employers ADD COLUMN office_locations TEXT;                  -- Расположения офисов (JSON)
ALTER TABLE employers ADD COLUMN benefits_offered TEXT;                  -- Льготы (JSON)
ALTER TABLE employers ADD COLUMN company_age_years INTEGER;              -- Возраст компании
```

### 3. Отсутствующие таблицы

#### 3.1. Таблица поисковых запросов
```sql
CREATE TABLE search_queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filter_name TEXT NOT NULL,                    -- Название из filters.json
    search_text TEXT,                            -- Поисковый запрос
    search_params TEXT,                          -- JSON параметров поиска
    execution_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_found INTEGER,                         -- Общее количество найденных
    pages_processed INTEGER,                     -- Обработано страниц
    vacancies_collected INTEGER,                 -- Собрано ID вакансий
    execution_time_sec REAL,                    -- Время выполнения
    status TEXT DEFAULT 'pending',              -- pending/running/completed/failed
    error_message TEXT,                         -- Сообщение об ошибке
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2. Таблица очереди загрузки
```sql
CREATE TABLE download_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vacancy_hh_id TEXT NOT NULL,               -- ID вакансии в HH
    search_query_id INTEGER,                   -- Связь с поисковым запросом
    priority INTEGER DEFAULT 0,                -- Приоритет загрузки
    attempts INTEGER DEFAULT 0,                -- Количество попыток
    last_attempt TIMESTAMP,                    -- Последняя попытка
    status TEXT DEFAULT 'pending',            -- pending/processing/completed/failed
    error_message TEXT,                        -- Ошибка загрузки
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (search_query_id) REFERENCES search_queries (id),
    UNIQUE (vacancy_hh_id)
);
```

#### 3.3. Таблица мониторинга системы (требование 2.1)
```sql
CREATE TABLE system_monitoring (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    check_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    component TEXT NOT NULL,                   -- database/api_hh/api_llm/filesystem
    status TEXT NOT NULL,                     -- ok/warning/critical
    response_time_ms INTEGER,                 -- Время отклика
    cpu_percent REAL,                         -- Использование CPU
    memory_percent REAL,                      -- Использование памяти
    disk_percent REAL,                        -- Использование диска
    error_message TEXT,                       -- Сообщение об ошибке
    details TEXT                              -- JSON с деталями проверки
);
```

#### 3.4. Таблица авторизации HH (требование 2.8)
```sql
CREATE TABLE hh_auth_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_name TEXT NOT NULL UNIQUE,        -- Название профиля
    auth_type TEXT NOT NULL,                  -- token/cookie/oauth
    credentials TEXT NOT NULL,                -- JSON с данными авторизации
    is_active BOOLEAN DEFAULT TRUE,           -- Активен ли профиль
    last_used TIMESTAMP,                      -- Последнее использование
    success_count INTEGER DEFAULT 0,          -- Успешных запросов
    error_count INTEGER DEFAULT 0,            -- Ошибок
    ban_until TIMESTAMP,                      -- Заблокирован до
    rate_limit_reset TIMESTAMP,              -- Сброс лимита запросов
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.5. Таблица Telegram уведомлений (требование 2.1.7, 2.6.2)
```sql
CREATE TABLE telegram_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_type TEXT NOT NULL,               -- system/alert/report/summary
    priority INTEGER DEFAULT 0,               -- Приоритет отправки
    title TEXT,                              -- Заголовок сообщения
    message TEXT NOT NULL,                    -- Текст сообщения  
    attachment_path TEXT,                     -- Путь к вложению
    sent_status TEXT DEFAULT 'pending',      -- pending/sent/failed
    sent_at TIMESTAMP,                        -- Время отправки
    telegram_message_id TEXT,                 -- ID сообщения в Telegram
    error_message TEXT,                       -- Ошибка отправки
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.6. Таблица экспорта данных (требование 2.10.5)
```sql
CREATE TABLE data_exports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    export_type TEXT NOT NULL,                -- excel/csv/json
    filter_criteria TEXT,                     -- JSON критериев отбора
    file_path TEXT,                          -- Путь к созданному файлу
    record_count INTEGER,                     -- Количество записей
    file_size_bytes INTEGER,                  -- Размер файла
    status TEXT DEFAULT 'pending',           -- pending/processing/completed/failed
    created_by TEXT,                         -- Инициатор экспорта
    error_message TEXT,                       -- Ошибка экспорта
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP                    -- Время завершения
);
```

### 4. Индексы для производительности

```sql
-- Индексы для поиска и версионирования
CREATE INDEX idx_vacancies_search_date ON vacancies (search_date);
CREATE INDEX idx_vacancies_sync_status ON vacancies (synced_to_host2, is_unique_host1);
CREATE INDEX idx_vacancies_response_status ON vacancies (response_status);
CREATE INDEX idx_vacancies_relevance ON vacancies (relevance_score) WHERE relevance_score IS NOT NULL;

-- Индексы для мониторинга
CREATE INDEX idx_monitoring_component_time ON system_monitoring (component, check_time);
CREATE INDEX idx_monitoring_status ON system_monitoring (status, check_time);

-- Индексы для очереди загрузки
CREATE INDEX idx_download_queue_status ON download_queue (status, priority);
CREATE INDEX idx_download_queue_attempts ON download_queue (attempts, last_attempt);
```

### 5. Триггеры для автоматизации

```sql
-- Автоматическое обновление updated_at
CREATE TRIGGER update_vacancy_timestamp 
    AFTER UPDATE ON vacancies
    FOR EACH ROW 
BEGIN
    UPDATE vacancies SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Автоматический расчет версий при вставке
CREATE TRIGGER calculate_vacancy_version
    BEFORE INSERT ON vacancies
    FOR EACH ROW
BEGIN
    UPDATE vacancies SET version = (
        SELECT COALESCE(MAX(version), 0) + 1 
        FROM vacancies 
        WHERE hh_id = NEW.hh_id
    ) WHERE id = NEW.id;
END;
```

## 📊 Приоритизация доработок схемы

### Приоритет 1 (MVP - неделя 1-2)
1. ✅ Поля версионирования в `vacancies` и `employers`
2. ✅ Таблица `search_queries` и `download_queue`  
3. ✅ Базовые индексы производительности
4. ✅ Таблица `system_monitoring`

### Приоритет 2 (после MVP - неделя 3-4)
1. Таблица `hh_auth_profiles` для управления авторизацией
2. Таблица `telegram_notifications` для уведомлений
3. Поля аналитики в `vacancies` (relevance_score, pros, cons)
4. Триггеры для автоматизации

### Приоритет 3 (расширенная функциональность)
1. LLM поля в `employers` и `vacancies`
2. Таблица `data_exports` для отчетности
3. Полные JSON поля с API данными
4. Расширенные индексы и оптимизация

## 🔧 Скрипт миграции

```sql
-- Основной скрипт миграции для Приоритета 1
-- Выполнить в core/database_v3.py в методе _init_schema()

-- 1. Добавляем критические поля версионирования
ALTER TABLE vacancies ADD COLUMN is_unique_host1 BOOLEAN DEFAULT FALSE;
ALTER TABLE vacancies ADD COLUMN synced_to_host2 BOOLEAN DEFAULT FALSE;  
ALTER TABLE vacancies ADD COLUMN search_query_id TEXT;
ALTER TABLE vacancies ADD COLUMN response_status TEXT;

-- 2. Создаем таблицы поиска
-- (код создания таблиц из раздела 3.1-3.3)

-- 3. Создаем индексы
-- (код индексов из раздела 4)
```

*Обновлено: 19.09.2025 20:39:00*
