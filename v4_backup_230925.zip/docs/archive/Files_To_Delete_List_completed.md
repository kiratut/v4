# Список файлов для удаления - HH-бот v4

*Создано: 19.09.2025 21:05:00*

## 🗑️ Файлы для немедленного удаления

### Категория: Устаревшие исполняемые файлы

```
c:\DEV\hh-applicant-tool\hh_v3\v4\check_db.py
c:\DEV\hh-applicant-tool\hh_v3\v4\detailed_db_analysis.py  
c:\DEV\hh-applicant-tool\hh_v3\v4\run_v4.py
```

**Обоснование**: Заменены на cli_v4.py, больше не используются

### Категория: Временные и тестовые данные

```
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_083305.sqlite3
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_090332.sqlite3
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_090515.sqlite3
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_091743.sqlite3
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_092033.sqlite3
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_20250915_092113.sqlite3
```

**Обоснование**: Старые бэкапы БД (>30 дней), занимают место

### Категория: Python кэш файлы

```
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\__init__.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\auth.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\database_v3.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\models.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\task_database.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__\task_dispatcher.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\plugins\__pycache__\fetcher_v4.cpython-311.pyc
c:\DEV\hh-applicant-tool\hh_v3\v4\web\__pycache__\server.cpython-311.pyc
```

**Обоснование**: Автоматически пересоздаются, можно удалить

### Категория: Устаревшие тестовые файлы

```
c:\DEV\hh-applicant-tool\hh_v3\v4\tests\test_run_v4.py
c:\DEV\hh-applicant-tool\hh_v3\v4\tests\debug.py
```

**Обоснование**: Тестируют удаленный run_v4.py, не актуальны

### Категория: Старые логи (если существуют)

```
c:\DEV\hh-applicant-tool\hh_v3\v4\logs\*.log.*
c:\DEV\hh-applicant-tool\hh_v3\v4\logs\*_2025091[0-8]*
```

**Обоснование**: Логи старше 7 дней

## 📦 Файлы для архивации

### Категория: Устаревшая документация

**Создать папку**: `c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\`

**Переместить в архив**:
```
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Architecture_v4_Checklist.md
  → c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\Architecture_v4_Checklist_old.md

c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Architecture_v4_Part1_TaskQueue.md
  → c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\Architecture_v4_Part1_TaskQueue_old.md

c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Architecture_v4_Part2_Structure.md
  → c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\Architecture_v4_Part2_Structure_old.md

c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Architecture_v4_Part3_Documentation.md
  → c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\Architecture_v4_Part3_Documentation_old.md

c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Architecture_v4_Summary.md
  → c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\Architecture_v4_Summary_old.md
```

**Обоснование**: Заменены новыми версиями документации, но могут понадобиться для справки

### Категория: Экспериментальные скрипты

**Создать папку**: `c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\archive\`

**Переместить в архив**:
```
c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\migrate_v3_to_v4.py
  → c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\archive\migrate_v3_to_v4.py

c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\recreate_database_v4.py
  → c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\archive\recreate_database_v4.py

c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\backup_database.py
  → c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\archive\backup_database.py
```

**Обоснование**: Одноразовые скрипты, уже выполнившие свою функцию

## ⚠️ Файлы НЕ УДАЛЯТЬ (критичные)

### Основные компоненты
```
c:\DEV\hh-applicant-tool\hh_v3\v4\cli_v4.py                 # Основной CLI
c:\DEV\hh-applicant-tool\hh_v3\v4\core\*                   # Ядро системы
c:\DEV\hh-applicant-tool\hh_v3\v4\plugins\*                # Плагины
c:\DEV\hh-applicant-tool\hh_v3\v4\web\*                    # Веб-интерфейс
c:\DEV\hh-applicant-tool\hh_v3\v4\config\*                 # Конфигурации
```

### Актуальные данные
```
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4.sqlite3       # Основная БД
c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v3.sqlite3       # Мигрированная БД v3
```

### Актуальная документация
```
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Project_Plan_v4.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Project_v4.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Req.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Database_Schema_v4.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\V4_RUNBOOK.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Detailed_Development_Plan_v4.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Requirements_Test_Catalog.md
c:\DEV\hh-applicant-tool\hh_v3\v4\docs\Functional_Tests_Specification.md
```

### Тесты
```
c:\DEV\hh-applicant-tool\hh_v3\v4\tests\test_functional_business.py
c:\DEV\hh-applicant-tool\hh_v3\v4\tests\test_functional_system.py
c:\DEV\hh-applicant-tool\hh_v3\v4\tests\test_system_readiness.py
```

## 🔄 Команды для безопасного выполнения

### PowerShell команды для удаления:

```powershell
# 1. Создание архивных папок
New-Item -ItemType Directory -Force -Path "c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive"
New-Item -ItemType Directory -Force -Path "c:\DEV\hh-applicant-tool\hh_v3\v4\scripts\archive"

# 2. Удаление устаревших исполняемых файлов
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\check_db.py" -ErrorAction SilentlyContinue
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\detailed_db_analysis.py" -ErrorAction SilentlyContinue
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\run_v4.py" -ErrorAction SilentlyContinue

# 3. Удаление старых бэкапов БД
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4_backup_202509*.sqlite3" -ErrorAction SilentlyContinue

# 4. Очистка Python кэша
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\core\__pycache__" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\plugins\__pycache__" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\web\__pycache__" -Recurse -Force -ErrorAction SilentlyContinue

# 5. Удаление устаревших тестов
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\tests\test_run_v4.py" -ErrorAction SilentlyContinue
Remove-Item "c:\DEV\hh-applicant-tool\hh_v3\v4\tests\debug.py" -ErrorAction SilentlyContinue

# 6. Архивация документации
$archiveDocs = @(
    "Architecture_v4_Checklist.md",
    "Architecture_v4_Part1_TaskQueue.md", 
    "Architecture_v4_Part2_Structure.md",
    "Architecture_v4_Part3_Documentation.md",
    "Architecture_v4_Summary.md"
)

foreach ($doc in $archiveDocs) {
    $source = "c:\DEV\hh-applicant-tool\hh_v3\v4\docs\$doc"
    $dest = "c:\DEV\hh-applicant-tool\hh_v3\v4\docs\archive\${doc}_old"
    if (Test-Path $source) {
        Move-Item $source $dest
    }
}

# 7. Очистка старых логов (опционально)
Get-ChildItem "c:\DEV\hh-applicant-tool\hh_v3\v4\logs\" -Filter "*.log" | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7)} | Remove-Item -Force
```

### Проверочная команда:
```powershell
# Проверить, что основные компоненты на месте
Test-Path "c:\DEV\hh-applicant-tool\hh_v3\v4\cli_v4.py"
Test-Path "c:\DEV\hh-applicant-tool\hh_v3\v4\data\hh_v4.sqlite3"
Test-Path "c:\DEV\hh-applicant-tool\hh_v3\v4\config\config_v4.json"
```

## 📊 Ожидаемый результат очистки

### Освобождено места:
- **Старые бэкапы**: ~50-100 МБ
- **Python кэш**: ~5-10 МБ  
- **Устаревшие скрипты**: ~1-2 МБ
- **Общий результат**: ~60-115 МБ

### Архивировано:
- **Документация**: 5 файлов → архив
- **Скрипты**: 3 файла → архив
- **Сохранено для справки**, доступно при необходимости

### Удалено:
- **Исполняемые файлы**: 3 файла
- **Тестовые файлы**: 2 файла  
- **Кэш и временные**: 20+ файлов
- **Безвозвратно удалено**, но не критично для работы

*Обновлено: 19.09.2025 21:05:00*
