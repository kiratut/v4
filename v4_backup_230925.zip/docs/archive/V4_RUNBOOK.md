# HH Tool v4 - Полное руководство пользователя

## 🎯 РАБОТА С V4 - ВСЕ ИЗ ПАПКИ v4/

**ВАЖНО:** Все команды v4 запускаются из папки `v4/`, НЕ из корня проекта!

```bash
cd c:\DEV\hh-applicant-tool\hh_v3\v4
# Все последующие команды - отсюда
```

---

## 🚀 БЫСТРЫЙ СТАРТ V4

### Шаг 1: Проверка готовности системы

```bash
# Из папки v4/
cd v4

# Полная проверка готовности  
python cli_v4.py test readiness

# Ожидаемый результат:
# 🎉 Все проверки пройдены! HH Tool v4 готов к работе
```

### Шаг 2: Запуск демона планировщика

```bash
# Запуск демона в фоновом режиме
python cli_v4.py daemon start --background

# Проверка статуса
python cli_v4.py daemon status

# Ожидаемый вывод:
# ✅ Демон запущен
#    PID: XXXX
#    Memory: XX.X MB
```

### Шаг 3: Запуск веб-панели

```bash
# В отдельном терминале - веб-панель (порт 5000)
python -m uvicorn web.server:app --host 0.0.0.0 --port 5000

# Доступ к панели управления:
# http://localhost:5000
```

### Шаг 3: Тестовая загрузка

```bash
# В основном терминале - тестовая загрузка 1 страницы
python cli_v4.py load-vacancies -f "python-remote" -p 1

# Мониторинг выполнения
python cli_v4.py tasks
python cli_v4.py status
```

---

## 📊 ОСНОВНЫЕ КОМАНДЫ V4

### Управление демоном планировщика

```bash
# Запуск демона в фоновом режиме
python cli_v4.py daemon start --background

# Остановка демона
python cli_v4.py daemon stop

# Статус демона
python cli_v4.py daemon status

# Перезапуск демона  
python cli_v4.py daemon restart --background
```

### Управление веб-панелью

```bash
# Запуск веб-панели (порт 5000)
python -m uvicorn web.server:app --host 0.0.0.0 --port 5000 --reload

# Доступ к панели:
# http://localhost:5000
```

### Загрузка вакансий

```bash
# Загрузка всех активных фильтров
python cli_v4.py load-vacancies

# Конкретный фильтр (тест на 5 страницах)
python cli_v4.py load-vacancies -f "python-remote" -p 5

# С chunked processing (1000 вакансий на chunk)
python cli_v4.py load-vacancies -c 1000

# Отложенный запуск (Unix timestamp)
python cli_v4.py load-vacancies --schedule-at 1694712000
```

---

## ⚙️ Статусы задач и диспетчер v4

Chg_DOCS_1509: Добавлено описание статусов и роли диспетчера (15.09.2025 17:34:30)

- pending — задача создана и ожидает подхвата диспетчером.
- running — задача выполняется воркером диспетчера.
- completed — задача завершена успешно.
- failed — задача завершилась ошибкой.

Важно: команда `load-vacancies` добавляет задачу в БД. Для выполнения должен быть запущен диспетчер (`python cli_v4.py start`) или используйте короткую команду `dev-up`, которая поднимет панель и диспетчер и выполнит быстрый прогон.

---

## 🧭 Метрики системы и окно «10 минут до последнего запуска»

Chg_DOCS_1509: Уточнена семантика метрик и поведение автообновления (15.09.2025 17:34:30)

- Дашборд получает обновления через WebSocket каждые ~5 сек и резервно опрашивает `/api/stats` каждые ~30 сек.
- При ошибках сервер возвращает кэш последних валидных метрик, чтобы не было «провалов» CPU/RAM/Disk и размера БД.
- Размер БД вычисляется через PRAGMA; при сбое — через `os.path.getsize` основного файла; далее — суммой `data/*.sqlite*`.
- Метрика «За 10 мин до последнего запуска» считает количество добавленных вакансий строго в окне `[T-10м; T]`, где `T` — момент последнего запуска задачи `load_vacancies`.

---

## 🔄 Кнопка «Обновить» на панели

Chg_DOCS_1509: Пояснение поведения кнопки (15.09.2025 17:34:30)

- При активном WebSocket кнопка дизейблится (обновления приходят автоматически).
- При потере соединения кнопка активна — можно принудительно обновить список задач/метрики.

---

## 🚀 Быстрый перезапуск (dev-up)

Chg_DOCS_1509: Рекомендация по быстрой проверке (15.09.2025 17:34:30)

```powershell
python cli_v4.py dev-up -w 2 -p 1
```

Команда убивает старые процессы панели/диспетчера на 8080, поднимает их заново, выполняет быструю загрузку (1 страница) и печатает ключевые метрики. Удобно после изменения конфигов или токенов.

### Мониторинг задач

```bash
# Список последних задач
python cli_v4.py tasks

# Последние 50 задач
python cli_v4.py tasks --limit 50

# Только failed задачи
python cli_v4.py tasks --status failed

# Детали конкретной задачи
python cli_v4.py task-info abc12345
```

### Веб-интерфейс

```bash
# Запуск веб-интерфейса (http://localhost:8000)
python cli_v4.py web

# Кастомный хост/порт
python cli_v4.py web --host 0.0.0.0 --port 8080
```

### Конфигурация и фильтры

```bash
# Просмотр всех фильтров
python cli_v4.py filters

# Очистка старых данных (7 дней)
python cli_v4.py cleanup

# Очистка старых данных (30 дней)
python cli_v4.py cleanup --days 30
```

---

## 🔧 КОНФИГУРАЦИЯ V4

### config_v4.json - основные настройки

```json
{
  "task_dispatcher": {
    "max_workers": 3,           // количество worker threads
    "chunk_size": 500,          // размер chunk для больших задач
    "monitor_interval_sec": 10, // интервал мониторинга задач
    "default_timeout_sec": 3600 // таймаут задачи по умолчанию (1 час)
  },
  "vacancy_fetcher": {
    "rate_limit_delay": 1.0,    // задержка между запросами к API
    "request_timeout_sec": 30,  // таймаут HTTP запроса
    "retry_attempts": 3,        // количество повторов при ошибке
    "retry_backoff_sec": 2,     // задержка между повторами
    "max_pages_per_filter": 200 // лимит страниц на фильтр
  },
  "database": {
    "path": "data/hh_v4.sqlite3",
    "timeout_sec": 30,          // таймаут подключения к БД
    "wal_mode": true            // включить WAL mode для concurrency
  },
  "logging": {
    "level": "INFO",            // DEBUG, INFO, WARNING, ERROR
    "file": "logs/hh_v4.log",
    "max_size_mb": 100,         // ротация логов
    "backup_count": 5
  }
}
```

### filters.json - настройка фильтров

```json
{
  "filters": [
    {
      "id": "python-remote",
      "name": "Python разработчик (удаленка)",
      "params": {
        "text": "python",
        "area": 1,                // Москва
        "schedule": "remote",
        "experience": "between1And3"
      },
      "active": true
    },
    {
      "id": "python-hybrid",
      "name": "Python разработчик (гибрид)",
      "params": {
        "text": "python OR django OR flask",
        "area": 1,
        "schedule": "flexible"
      },
      "active": true
    }
  ]
}
```

---

## 📈 МОНИТОРИНГ И ДИАГНОСТИКА

### Просмотр статуса системы

```bash
# Общая статистика
python cli_v4.py status

# Пример вывода:
# === Статус HH Tool v4 ===
# 
# Задачи за последний день:
#   completed: 15
#   running: 2
#   failed: 1
# 
# Вакансии:
#   Всего: 45,230
#   Обработано: 44,850
#   Сегодня загружено: 1,847
```

### Детальный мониторинг задач

```bash
# Детали конкретной задачи
python cli_v4.py task-info abc12345

# Пример вывода:
# === Задача abc12345-67890 ===
# Тип: load_vacancies
# Статус: running
# Создана: 2025-09-14 22:30:15
# Запущена: 2025-09-14 22:30:20
# Таймаут: 3600 сек
# 
# Параметры:
#   filter: Python разработчик (удаленка)
#   max_pages: 20
#   chunk_size: 500
# 
# Прогресс:
#   chunk_progress: 3/4 chunks completed
#   current_page: 15
#   loaded_vacancies: 1500
```

### Веб-интерфейс мониторинга

```bash
# Запуск веб-интерфейса
python cli_v4.py web

# Доступные URL:
# http://localhost:8000/          - dashboard с автообновлением
# http://localhost:8000/api/stats - JSON API статистики
```

### Логи и отладка

```bash
# Просмотр логов в реальном времени
tail -f logs/hh_v4.log

# Только ошибки
grep ERROR logs/hh_v4.log

# Логи диспетчера
tail -f logs/dispatcher.log

# Увеличить детальность логов
# В config_v4.json: "logging": {"level": "DEBUG"}
```

---

## 🔄 ТИПИЧНЫЕ СЦЕНАРИИ РАБОТЫ

### Ежедневная загрузка

```bash
# 1. Проверка готовности
python run_v4.py

# 2. Запуск диспетчера (в фоне или отдельном терминале)
python cli_v4.py start &

# 3. Загрузка всех активных фильтров
python cli_v4.py load-vacancies

# 4. Мониторинг прогресса
while true; do
  python cli_v4.py status
  sleep 30
done
```

### Тестирование новых фильтров

```bash
# 1. Редактирование фильтров
notepad config/filters.json

# 2. Проверка фильтров
python cli_v4.py filters

# 3. Тестовая загрузка (1 страница)
python cli_v4.py load-vacancies -f "new-filter-id" -p 1

# 4. Проверка результатов
python cli_v4.py tasks --limit 1
```

### Обслуживание системы

```bash
# Еженедельная очистка (7 дней)
python cli_v4.py cleanup

# Ежемесячная очистка (30 дней)
python cli_v4.py cleanup --days 30

# Backup базы данных
copy data\hh_v4.sqlite3 backups\hh_v4_backup_%date%.sqlite3

# Проверка целостности БД
sqlite3 data/hh_v4.sqlite3 "PRAGMA integrity_check;"
```

---

## 🐛 ДИАГНОСТИКА ПРОБЛЕМ

### Частые проблемы и решения

**1. "ModuleNotFoundError"**
```bash
# Убедитесь что запускаете из папки v4/
cd v4/
python cli_v4.py --help
```

**2. "Database locked"**
```bash
# Остановите все процессы
pkill -f "cli_v4.py"

# Проверьте блокировки
lsof data/hh_v4.sqlite3

# В крайнем случае - удалите lock файлы
rm -f data/hh_v4.sqlite3-wal
rm -f data/hh_v4.sqlite3-shm
```

**3. "Task timeout"**
```bash
# Увеличьте таймаут в config_v4.json
"default_timeout_sec": 7200  // 2 часа

# Или для конкретной задачи
python cli_v4.py load-vacancies -p 1  # меньше страниц
```

**4. "Rate limit exceeded"**
```bash
# Увеличьте задержку в config_v4.json
"rate_limit_delay": 2.0  // 2 секунды между запросами

# Уменьшите параллелизм
"max_workers": 1  // только 1 worker
```

**5. "Worker timeout/hang"**
```bash
# Проверьте зависшие задачи
python cli_v4.py tasks --status running

# Перезапустите диспетчер
Ctrl+C  # в окне диспетчера
python cli_v4.py start
```

### Режим отладки

```bash
# Подробные логи
# В config_v4.json: "logging": {"level": "DEBUG"}

# Тестовый режим (без реальных запросов)
# TODO: python cli_v4.py load-vacancies --dry-run

# Проверка без загрузки
python cli_v4.py filters  # проверить конфигурацию фильтров
python run_v4.py          # проверить компоненты системы
```

---

## 📊 ПРОИЗВОДИТЕЛЬНОСТЬ И МОНИТОРИНГ

### Ожидаемые показатели

**Нагрузка 50k вакансий/день:**
- Chunked processing: 100 chunks по 500 вакансий
- Время выполнения: 2-3 часа с 3 workers
- Rate limit: ~3600 запросов/час = 1 запрос/сек
- SQLite performance: 1000+ INSERT/сек (достаточно для ~0.6/сек)

**Типичное время выполнения:**
- Загрузка 1 страницы (~100 вакансий): 1-2 минуты
- Загрузка 1 chunk (500 вакансий): 5-10 минут
- Полная загрузка фильтра (2000 вакансий): 30-60 минут
- Все активные фильтры: 2-4 часа

### Оптимизация производительности

```json
// Для быстрых тестов
{
  "task_dispatcher": {"max_workers": 1, "chunk_size": 100},
  "vacancy_fetcher": {"rate_limit_delay": 0.5}
}

// Для максимальной скорости (осторожно с rate limits!)
{
  "task_dispatcher": {"max_workers": 5, "chunk_size": 1000},
  "vacancy_fetcher": {"rate_limit_delay": 0.5}
}

// Для надежности (медленно, но безопасно)
{
  "task_dispatcher": {"max_workers": 1, "chunk_size": 500},
  "vacancy_fetcher": {"rate_limit_delay": 2.0, "retry_attempts": 5}
}
```

---

## 🔄 ИНТЕГРАЦИЯ С V3

### Параллельная работа

v4 полностью независима от v3:
- ✅ Отдельная база данных: `v4/data/hh_v4.sqlite3`
- ✅ Отдельные логи: `v4/logs/`
- ✅ Отдельная конфигурация: `v4/config/`
- ✅ Можно запускать одновременно с v3

### Миграция данных

```bash
# TODO: Скрипт миграции (планируется)
# python scripts/migrate_v3_to_v4.py

# Ручной экспорт из v3
cd ../  # в папку hh_v3/
python -m hh.cli export --format json --output v4_migration.json

# Импорт в v4
cd v4/
# TODO: python scripts/import_from_v3.py ../v4_migration.json
```

### Сравнение команд

| Операция | v3 | v4 |
|----------|----|----|
| **Загрузка** | `python -m hh.cli load` | `python cli_v4.py load-vacancies` |
| **Статус** | `python -m hh.cli status` | `python cli_v4.py status` |
| **Веб-интерфейс** | `python -m hh.cli web` | `python cli_v4.py web` |
| **Экспорт** | `python -m hh.cli export` | TODO |
| **Pipeline** | `python -m hh.cli pipeline` | TODO |

---

## 🎯 РАСШИРЕННОЕ ИСПОЛЬЗОВАНИЕ

### Автоматизация

```bash
# Windows Task Scheduler
# Создать задачу на ежедневный запуск:
# cd C:\DEV\hh-applicant-tool\hh_v3\v4
# python cli_v4.py load-vacancies

# Linux Cron
# 0 9 * * * cd /path/to/v4 && python cli_v4.py load-vacancies
```

### REST API (через web interface)

```bash
# Запуск веб-сервера
python cli_v4.py web --host 0.0.0.0 --port 8000

# GET /api/stats - получить статистику
curl http://localhost:8000/api/stats

# GET / - dashboard с автообновлением
# Открыть в браузере: http://localhost:8000
```

### Batch операции

```bash
# Загрузка нескольких фильтров по очереди
for filter in python-remote python-hybrid backend-senior; do
  python cli_v4.py load-vacancies -f "$filter" -p 10
  python cli_v4.py tasks --limit 1  # проверить статус
  sleep 60  # пауза между фильтрами
done

# Массовая очистка
python cli_v4.py cleanup --days 1  # очистить вчерашние задачи
```

---

## 📚 СПРАВОЧНАЯ ИНФОРМАЦИЯ

### Полный список команд CLI

```bash
python cli_v4.py --help

# Доступные команды:
# daemon          - Управление демоном планировщика (start/stop/status/restart)
# load-vacancies  - Добавить задачу загрузки вакансий  
# status          - Показать общий статус системы
# tasks           - Показать список задач
# task-info       - Подробная информация о задаче
# export          - Экспорт вакансий в Excel
# stats           - Статистика версионирования и изменений
# test            - Запуск тестов (readiness/functional/system)
# cleanup         - Очистка временных файлов и данных
# system          - Системный мониторинг и диагностика
```

### Файловая структура (обновлено 20.09.2025)

```
v4/
├── cli_v4.py                      # Основной CLI интерфейс
├── core/
│   ├── scheduler_daemon.py        # ✅ Демон планировщика задач
│   ├── database_v3.py            # ✅ База данных с версионированием  
│   ├── task_dispatcher.py        # ✅ Диспетчер задач с Host2/Host3
│   ├── host2_client.py           # ✅ PostgreSQL клиент (mock)
│   └── host3_client.py           # ✅ LLM клиент (mock)
├── plugins/
│   └── fetcher_v4.py             # ✅ Загрузчик вакансий (исправлен UA)
├── web/
│   ├── server.py                 # ✅ Веб-панель FastAPI (порт 5000)
│   ├── templates/                # HTML шаблоны
│   └── static/                   # CSS/JS ресурсы
├── config/
│   ├── config_v4.json            # Настройки системы
│   └── filters.json              # Фильтры поиска вакансий  
├── data/
│   ├── hh_v4.sqlite3            # Основная БД
│   ├── scheduler_daemon.pid      # PID файл демона
│   └── .trash/                   # Карантин для удаляемых файлов
├── logs/
│   └── app.log                   # Общие логи системы (ротация 100МБ, включая демон)
├── docs/                         # Документация
│   ├── archive/                  # ✅ Архив старой документацию
│   ├── V4_RUNBOOK.md            # Данное руководство
│   ├── File_Management_Guide.md  # ✅ Управление файлами
│   └── Project_v4.md            # Описание проекта
└── tests/                        # Тесты готовности и функциональные
```

### Коды возврата

- **0** - Успешное выполнение
- **1** - Общая ошибка
- **2** - Ошибка конфигурации
- **3** - Ошибка подключения к базе данных
- **4** - Ошибка сети/API
- **5** - Timeout выполнения

---

## 🎉 СТАТУС ПРОЕКТА (20.09.2025 22:30)

**✅ СИСТЕМА ПОЛНОСТЬЮ ФУНКЦИОНАЛЬНА:**

### Запущенные службы:
- **Демон планировщика**: Активен (PID: 17804) - автоматические загрузки каждый час
- **Веб-панель управления**: http://localhost:5000 - мониторинг и управление  
- **База данных**: hh_v4.sqlite3 - версионирование данных работает
- **API тестов**: Функциональные и системные тесты доступны через веб-панель

### Выполненные задачи планировщика:
- System Cleanup - очистка старых записей ✅
- Host2 Sync - синхронизация с PostgreSQL ✅  
- VACUUM БД - оптимизация базы данных ✅
- System Health Check - мониторинг каждые 5 минут ✅

### Очистка проекта:
- Удалены устаревшие файлы (check_db.py, run_v4.py и др.) ✅
- Архивированы аналитические документы ✅
- Очищен Python кэш ✅
- Создан единый File_Management_Guide.md ✅

**Система готова к продакшену и работает в полностью автоматическом режиме!**

---

**HH Tool v4** - Create with ❤️ for reliable and simple vacancy processing
