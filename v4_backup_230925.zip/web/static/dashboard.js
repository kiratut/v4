// HH Tool v4 Dashboard - JavaScript
class Dashboard {
    constructor() {
        this.ws = null;
        this.charts = {};
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        
        this.init();
    }

    init() {
        this.setupWebSocket();
        this.loadInitialData();
        this.setupCharts();
        this.setupEventListeners();
        
        // Автообновление каждые 30 секунд
        setInterval(() => this.loadStats(), 30000);
    }

    setupWebSocket() {
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws`;
            
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('WebSocket connected');
                this.updateConnectionStatus(true);
                this.reconnectAttempts = 0;
            };
            
            this.ws.onmessage = (event) => {
                const message = JSON.parse(event.data);
                this.handleWebSocketMessage(message);
            };
            
            this.ws.onclose = () => {
                console.log('WebSocket disconnected');
                this.updateConnectionStatus(false);
                this.attemptReconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.updateConnectionStatus(false);
            };
            
        } catch (error) {
            console.error('WebSocket setup failed:', error);
            this.updateConnectionStatus(false);
        }
    }

    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Attempting to reconnect... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            setTimeout(() => this.setupWebSocket(), 5000 * this.reconnectAttempts);
        }
    }

    updateConnectionStatus(connected) {
        const statusEl = document.getElementById('connectionStatus');
        const dot = statusEl.querySelector('.dot');
        // // Chg_UI_1509: disable manual refresh when WS is connected
        const refreshBtn = document.querySelector('.refresh-btn');
        
        if (connected) {
            dot.className = 'dot online';
            statusEl.innerHTML = '<span class="dot online"></span> Подключено';
            if (refreshBtn) { refreshBtn.disabled = true; refreshBtn.title = 'WebSocket обновляет автоматически'; }
        } else {
            dot.className = 'dot offline';
            statusEl.innerHTML = '<span class="dot offline"></span> Отключено';
            if (refreshBtn) { refreshBtn.disabled = false; refreshBtn.title = 'Принудительное обновление'; }
        }
    }

    handleWebSocketMessage(message) {
        switch (message.type) {
            case 'stats_update':
            case 'live_update':
                this.updateStats(message.data);
                // // Chg_WS_TASKS_1509: автообновление списка задач при stats_update
                this.loadTasks(true);
                break;
            case 'task_complete':
                this.loadTasks();
                break;
            case 'new_vacancy':
                this.loadVacancies();
                break;
        }
    }

    async loadInitialData() {
        try {
            await Promise.all([
                this.loadStats(),
                this.loadTasks(),
                this.loadVacancies(),
                this.loadFilters(),
                this.loadTestHistory()
            ]);
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }

    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            const data = await response.json();
            this.updateStats(data);
        } catch (error) {
            console.error('Failed to load stats:', error);
        }
    }

    updateStats(stats) {
        // System usage
        const sys = stats.system_info || {};
        let usage = '';
        if ('cpu_percent' in sys) usage += `CPU: ${sys.cpu_percent}% `;
        if ('memory_percent' in sys) usage += `RAM: ${sys.memory_percent}% `;
        if ('disk_percent' in sys) usage += `Disk: ${sys.disk_percent}%`;
        // // Chg_UI_1509: do not wipe values if metrics missing; keep last known
        const usageEl = document.getElementById('systemUsage');
        if (usage.trim()) {
            usageEl.textContent = usage.trim();
        }
        // Задачи
        const taskStats = stats.tasks || {};
        const totalTasks = Object.values(taskStats).reduce((sum, count) => sum + count, 0);
        
        document.getElementById('tasksToday').textContent = totalTasks;
        document.getElementById('taskBreakdown').innerHTML = 
            Object.entries(taskStats)
                .map(([status, count]) => `<span class="status ${status}">${status}: ${count}</span>`)
                .join(' ');

        // Вакансии
        const vacancyStats = stats.vacancies || {};
        document.getElementById('vacanciesTotal').textContent = vacancyStats.total_vacancies || 0;
        // // Chg_VAC_ADDED_UI_1509: выводим метрику добавленных за последний запуск и время последнего запуска
        const addedLast = vacancyStats.added_last_run_10m_window || 0;
        const lastRunIso = vacancyStats.last_run_at;
        const lastRunText = lastRunIso ? new Date(lastRunIso).toLocaleString() : '—';
        // // Chg_UI_1509: clarify 10-min window semantics
        document.getElementById('vacancyDetails').innerHTML = `
            Обработано: ${vacancyStats.processed_vacancies || 0}<br>
            Сегодня: ${vacancyStats.today_vacancies || 0}<br>
            За 10 мин до последнего запуска: ${addedLast}<br>
            Последний запуск: ${lastRunText}
        `;

        // Система
        document.getElementById('systemStatus').textContent = 'Работает';
        const aw = (sys.active_workers != null) ? sys.active_workers : '—';
        const wc = (sys.workers_configured != null) ? sys.workers_configured : '—';
        document.getElementById('systemDetails').innerHTML = `
            Обновлено: ${new Date(stats.timestamp).toLocaleTimeString()}<br>
            Воркеры: ${aw}${wc !== '—' ? '/' + wc : ''}
        `;

        // База данных
        // // Chg_UI_1509: avoid flicker to 0 MB; keep previous if missing/zero while we had non-zero
        const dbSizeRaw = stats.system_info?.db_size;
        const dbSizeEl = document.getElementById('dbSize');
        if (typeof dbSizeRaw === 'number' && dbSizeRaw >= 0) {
            dbSizeEl.textContent = `${(dbSizeRaw / 1024 / 1024).toFixed(1)} MB`;
        }
        // Загрузка (цифрами)
        // // Chg_STATUS_1509: normalize 'queued' -> 'pending' (start)
        const completed = taskStats.completed || 0;
        const pending = taskStats.pending || 0;
        const failed = taskStats.failed || 0;
        document.getElementById('loadStats').innerHTML = `Выполнено: ${completed} <br> В очереди: ${pending} <br> Ошибки: ${failed}`;
        // // Chg_STATUS_1509: normalize 'queued' -> 'pending' (end)
    }

    async loadTasks(auto = false) {
        try {
            // // Chg_WS_TASKS_1509: показываем последние задачи (completed,running,pending), максимум 3
            const response = await fetch('/api/tasks?status=completed,running,pending&limit=3');
            const data = await response.json();
            this.updateTasksTable(data.tasks);
        } catch (error) {
            console.error('Failed to load tasks:', error);
        }
    }

    updateTasksTable(tasks) {
        const tbody = document.querySelector('#tasksTable tbody');
        tbody.innerHTML = '';
        // Показываем только 3 последних задачи
        (tasks.slice(0, 3)).forEach(task => {
            const row = document.createElement('tr');
            // worker_id (если есть)
            let worker = task.worker_id || '-';
            row.innerHTML = `
                <td>${task.id.substring(0, 8)}...</td>
                <td>${task.type}</td>
                <td><span class="status ${task.status}">${task.status}</span></td>
                <td>${task.created_at_formatted ? new Date(task.created_at_formatted).toLocaleString() : 'Unknown'}</td>
                <td>${worker}</td>
            `;
            tbody.appendChild(row);
        });
    }

    async loadVacancies() {
        try {
            const response = await fetch('/api/vacancies/recent?limit=5');
            const data = await response.json();
            this.updateVacanciesList(data.vacancies);
        } catch (error) {
            console.error('Failed to load vacancies:', error);
            document.getElementById('vacanciesList').innerHTML = 
                '<p>Ошибка загрузки вакансий. Проверьте подключение к базе данных.</p>';
        }
    }

    updateVacanciesList(vacancies) {
        const container = document.getElementById('vacanciesList');
        
        if (!vacancies || vacancies.length === 0) {
            container.innerHTML = '<p>Вакансии не найдены</p>';
            return;
        }
        
        container.innerHTML = vacancies.map(vacancy => `
            <div class="vacancy-item">
                <div class="vacancy-title">${vacancy.name || 'Без названия'}</div>
                <div class="vacancy-meta">
                    ${vacancy.employer_name || 'Неизвестен'} • 
                    ${vacancy.salary_text || 'Зарплата не указана'} • 
                    ${vacancy.area_name || 'Неизвестно'}
                </div>
            </div>
        `).join('');
    }

    async loadFilters() {
        try {
            const response = await fetch('/api/filters');
            const data = await response.json();
            this.updateFiltersList(data.filters);
        } catch (error) {
            console.error('Failed to load filters:', error);
        }
    }

    // // Chg_TEST_HISTORY_2109: загрузка истории тестов (только последний)
    async loadTestHistory() {
        try {
            const resp = await fetch('/api/tests/history?limit=1');
            const data = await resp.json();
            const list = document.getElementById('testHistoryList');
            if (!list) return;
            const items = (data.history || []).map(item => {
                const icon = item.type === 'functional' ? 'Функц.' : item.type === 'system' ? 'Систем.' : 'Smoke';
                const sr = typeof item.success_rate === 'number' ? item.success_rate.toFixed(1) : item.success_rate;
                const timestamp = new Date(item.timestamp).toLocaleString('ru-RU');
                return `
                    <div class="history-item">
                        <div class="history-title">${icon} • ${timestamp}</div>
                        <div class="history-meta">Успех: ${sr}% • Пройдено: ${item.passed}/${item.total}</div>
                    </div>
                `;
            });
            list.innerHTML = items.join('') || '<div class="stat-details">Нет результатов</div>';
        } catch (e) {
            console.error('Failed to load test history:', e);
            const list = document.getElementById('testHistoryList');
            if (list) list.innerHTML = '<div class="stat-details">Ошибка загрузки</div>';
        }
    }

    updateFiltersList(filters) {
        const container = document.getElementById('filtersList');
        const activeCount = filters.filter(f => f.active).length;
        
        document.getElementById('filterCount').textContent = activeCount;
        
        container.innerHTML = filters.map(filter => `
            <div class="filter-item">
                <span class="filter-name">${filter.name}</span>
                <span class="filter-status ${filter.active ? 'active' : 'inactive'}">
                    ${filter.active ? 'Активен' : 'Неактивен'}
                </span>
            </div>
        `).join('');
    }

    setupCharts() {
        // Нет графиков/диаграмм — минимальная заглушка
    }

    // updateCharts удалён: нет диаграмм


    setupEventListeners() {
        // Глобальные функции для внешнего использования
        // // Chg_FIX_REFRESH_2109: безопасная привязка обновления задач
        window.loadTasks = () => this.loadTasks();

// Функции запуска тестов
async function runFunctionalTests() {
    const testResults = document.getElementById('testResults');
    const failedTests = document.getElementById('failedTests');
    const failedTestsList = document.getElementById('failedTestsList');
    
    // Отключаем кнопки
    const buttons = document.querySelectorAll('.test-btn');
    buttons.forEach(btn => btn.disabled = true);
    
    testResults.innerHTML = '<div class="stat-details">⏳ Запуск функциональных тестов...</div>';
    
    try {
        const response = await fetch('/api/tests/functional', { method: 'POST' });
        const result = await response.json();
        
        const successRate = result.success_rate || 0;
        const statusClass = successRate >= 90 ? 'test-success' : 'test-failure';
        const statusIcon = successRate >= 90 ? '✅' : '❌';
        
        testResults.innerHTML = `
            <div class="stat-details">Последний запуск: ${new Date().toLocaleString()}</div>
            <div class="${statusClass}">${statusIcon} ${successRate.toFixed(1)}% успешность (${result.statistics.passed}/${result.statistics.total})</div>
        `;
        
        // Показываем проваленные тесты
        if (result.statistics.failed > 0) {
            failedTestsList.innerHTML = '';
            result.results.filter(r => r.status === 'FAIL').forEach(test => {
                const li = document.createElement('li');
                li.textContent = `${test.id}: ${test.name} - ${test.message}`;
                failedTestsList.appendChild(li);
            });
            failedTests.style.display = 'block';
        } else {
            failedTests.style.display = 'none';
        }
        
    } catch (error) {
        console.error('Test execution failed:', error);
        testResults.innerHTML = '<div class="test-failure">❌ Ошибка выполнения тестов</div>';
        failedTests.style.display = 'none';
    } finally {
        // Включаем кнопки обратно
        buttons.forEach(btn => btn.disabled = false);
        // Обновляем историю тестов после выполнения
        setTimeout(() => {
            try { 
                if (window.dashboard && window.dashboard.loadTestHistory) { 
                    window.dashboard.loadTestHistory(); 
                }
            } catch(e) { console.log('History update error:', e); }
        }, 1000);
    }
}

async function runSystemTests() {
    const testResults = document.getElementById('testResults');
    const failedTests = document.getElementById('failedTests');
    const failedTestsList = document.getElementById('failedTestsList');
    
    // Отключаем кнопки
    const buttons = document.querySelectorAll('.test-btn');
    buttons.forEach(btn => btn.disabled = true);
    
    testResults.innerHTML = '<div class="stat-details">⏳ Запуск системных тестов...</div>';
    
    try {
        const response = await fetch('/api/tests/system', { method: 'POST' });
        const result = await response.json();
        
        const successRate = result.summary.success_rate || 0;
        const statusClass = successRate >= 90 ? 'test-success' : 'test-failure';
        const statusIcon = successRate >= 90 ? '✅' : '❌';
        
        testResults.innerHTML = `
            <div class="stat-details">Последний запуск: ${new Date().toLocaleString()}</div>
            <div class="${statusClass}">${statusIcon} ${successRate.toFixed(1)}% успешность (${result.summary.passed}/${result.summary.total})</div>
        `;
        
        // Показываем проваленные тесты
        if (result.summary.failed > 0) {
            failedTestsList.innerHTML = '';
            result.results.filter(r => r.status === 'failed').forEach(test => {
                const li = document.createElement('li');
                li.textContent = `${test.id}: ${test.name} - ${test.error || 'Unknown error'}`;
                failedTestsList.appendChild(li);
            });
            failedTests.style.display = 'block';
        } else {
            failedTests.style.display = 'none';
        }
        
    } catch (error) {
        console.error('Test execution failed:', error);
        testResults.innerHTML = '<div class="test-failure">❌ Ошибка выполнения тестов</div>';
        failedTests.style.display = 'none';
    } finally {
        // Включаем кнопки обратно
        buttons.forEach(btn => btn.disabled = false);
    }
}

        window.loadVacancies = () => this.loadVacancies();
    window.loadTestHistory = () => this.loadTestHistory();
        
        // Обновление при фокусе на окно
        window.addEventListener('focus', () => {
            this.loadStats();
        });
    }
}

// Инициализация дашборда
document.addEventListener('DOMContentLoaded', () => {
    // // Chg_GLOBAL_DASHBOARD_2109: сохраняем инстанс глобально
    window.dashboard = new Dashboard();
});

// // Chg_TEST_BUTTONS_2009: Функции запуска тестов
async function runFunctionalTests() {
    await runTestSuite('functional');
}

async function runSystemTests() {
    await runTestSuite('system');
}

// // Chg_SMOKE_2109: функция быстрого smoke-теста
async function runSmokeTest() {
    const testResults = document.getElementById('testResults');
    const buttons = document.querySelectorAll('.test-btn');
    buttons.forEach(btn => btn.disabled = true);
    testResults.innerHTML = '<div class="test-running">🔄 Smoke: загрузка 1 страницы...</div>';
    try {
        const resp = await fetch('/api/tests/smoke', { method: 'POST' });
        const data = await resp.json();
        if (data.status === 'ok') {
            const icon = data.loaded_count > 0 ? '✅' : '⚠️';
            testResults.innerHTML = `
                <div class="stat-details">Smoke: ${new Date().toLocaleString()}</div>
                <div class="${data.loaded_count > 0 ? 'test-success' : 'test-failure'}">${icon} Загружено: ${data.loaded_count} из ${data.items_count} (фильтр: ${data.filter_name || data.filter_id})</div>
            `;
        } else {
            testResults.innerHTML = '<div class="test-failure">❌ Smoke-тест: ошибка ' + (data.message || '') + '</div>';
        }
    } catch (e) {
        console.error('Smoke failed', e);
        testResults.innerHTML = '<div class="test-failure">❌ Smoke-тест: исключение</div>';
    } finally {
        buttons.forEach(btn => btn.disabled = false);
        // Обновляем историю тестов после выполнения
        setTimeout(() => {
            try { 
                if (window.dashboard && window.dashboard.loadTestHistory) { 
                    window.dashboard.loadTestHistory(); 
                }
            } catch(e) { console.log('History update error:', e); }
        }, 1000);
    }
}

async function runTestSuite(testType) {
    const testResults = document.getElementById('testResults');
    const failedTests = document.getElementById('failedTests');
    const failedTestsList = document.getElementById('failedTestsList');
    
    // Отключаем кнопки на время выполнения
    const buttons = document.querySelectorAll('.test-btn');
    buttons.forEach(btn => btn.disabled = true);
    
    testResults.innerHTML = '<div class="test-running">🔄 Выполняются тесты...</div>';
    failedTests.style.display = 'none';
    
    try {
        const response = await fetch(`/api/tests/${testType}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        // Определяем статус и цвет
        const successRate = (result.summary?.passed || result.statistics?.passed || 0) / 
                          (result.summary?.total || result.statistics?.total || 1) * 100;
        const statusClass = successRate >= 90 ? 'test-success' : 'test-failure';
        const statusIcon = successRate >= 90 ? '✅' : '❌';
        
        testResults.innerHTML = `
            <div class="stat-details">Последний запуск: ${new Date().toLocaleString()}</div>
            <div class="${statusClass}">${statusIcon} ${successRate.toFixed(1)}% успешность 
                (${result.summary?.passed || result.statistics?.passed || 0}/${result.summary?.total || result.statistics?.total || 0})</div>
        `;
        
        // Показываем проваленные тесты
        const failedCount = result.summary?.failed || result.statistics?.failed || 0;
        if (failedCount > 0) {
            failedTestsList.innerHTML = '';
            const failedResults = result.results?.filter(r => r.status === 'failed' || r.status === 'FAIL') || [];
            failedResults.forEach(test => {
                const li = document.createElement('li');
                li.textContent = `${test.id}: ${test.name} - ${test.error || test.message || 'Unknown error'}`;
                failedTestsList.appendChild(li);
            });
            failedTests.style.display = 'block';
        } else {
            failedTests.style.display = 'none';
        }
        
    } catch (error) {
        console.error('Test execution failed:', error);
        testResults.innerHTML = '<div class="test-failure">❌ Ошибка выполнения тестов</div>';
        failedTests.style.display = 'none';
    } finally {
        // Включаем кнопки обратно
        buttons.forEach(btn => btn.disabled = false);
    }
}
