"""
HH Tool v4 - Enhanced Web Interface with FastAPI
Улучшенная веб-панель на основе v3 с WebSocket поддержкой, системными метриками и расширенной функциональностью
"""

import json
import asyncio
import time
import glob
import os
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import psutil
import uvicorn
from logging.handlers import RotatingFileHandler

# Импорты модулей v4
from core.task_database import TaskDatabase

app = FastAPI(title="HH Tool v4 Dashboard", version="4.0.0")

# Настройка статических файлов и шаблонов
templates = Jinja2Templates(directory="web/templates")
app.mount("/static", StaticFiles(directory="web/static"), name="static")

# // Chg_WEB_LOG_INIT_2109: гарантируем запись логов веб-сервера в logs/app.log
try:
    Path('logs').mkdir(exist_ok=True)
    root = logging.getLogger()
    has_app_fh = any(
        isinstance(h, RotatingFileHandler) and getattr(h, 'baseFilename', '').endswith('app.log')
        for h in root.handlers
    )
    if not has_app_fh:
        fh = RotatingFileHandler('logs/app.log', maxBytes=100*1024*1024, backupCount=3, encoding='utf-8')
        sh = logging.StreamHandler()
        fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(fmt)
        sh.setFormatter(fmt)
        root.addHandler(fh)
        root.addHandler(sh)
        root.setLevel(logging.INFO)
except Exception:
    pass

# // Chg_STATS_CACHE_1509: cache last good stats/system info to avoid UI flicker (start)
_LAST_GOOD_SYSTEM_INFO: Dict[str, Any] = {}
_LAST_GOOD_DB_SIZE_BYTES: Optional[int] = None
# // Chg_STATS_CACHE_1509: cache last good stats/system info (end)

# WebSocket connections manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except:
                disconnected.append(connection)
        
        # Удаляем неактивные соединения
        for conn in disconnected:
            self.active_connections.remove(conn)

manager = ConnectionManager()

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Главная страница дашборда"""
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/api/stats")
async def get_stats():
    """API получения статистики БД"""
    try:
        task_db = TaskDatabase()
        # Получаем агрегированную статистику в формате v4 БД
        stats = task_db.get_stats()
        
        # Надёжное вычисление размера БД: PRAGMA -> os.path.getsize -> сумма файлов data/*.sqlite*
        db_size_bytes: int = 0
        try:
            with task_db.get_connection() as conn:
                cursor = conn.execute("PRAGMA page_count")
                page_count = cursor.fetchone()[0]
                cursor = conn.execute("PRAGMA page_size")
                page_size = cursor.fetchone()[0]
                db_size_bytes = int(page_count) * int(page_size)
        except Exception:
            try:
                # Фолбэк: размер основного файла
                main_db = Path(task_db.db_path)
                if main_db.exists():
                    db_size_bytes = os.path.getsize(main_db)
                else:
                    raise FileNotFoundError
            except Exception:
                # Фолбэк: сумма по маске
                try:
                    db_files = glob.glob("data/*.sqlite*")
                    db_size_bytes = sum(os.path.getsize(f) for f in db_files if os.path.exists(f))
                except Exception:
                    db_size_bytes = 0

        sys_info = _get_system_info()
        # // Chg_WORKERS_1509: считаем активных воркеров и читаем конфигурацию
        active_workers = 0
        try:
            with task_db.get_connection() as conn:
                roww = conn.execute(
                    "SELECT COUNT(DISTINCT worker_id) AS cnt FROM tasks WHERE status='running' AND worker_id IS NOT NULL"
                ).fetchone()
                active_workers = roww['cnt'] if roww else 0
        except Exception:
            active_workers = 0
        workers_configured = None
        try:
            cfg_path = Path('config/config_v4.json')
            if cfg_path.exists():
                cfg = json.load(open(cfg_path, 'r', encoding='utf-8'))
                workers_configured = ((cfg.get('task_dispatcher') or {}).get('max_workers'))
        except Exception:
            workers_configured = None
        # Объединяем метрики системы с размером БД и информацией о воркерах
        sys_info_merged = {**sys_info, "db_size": db_size_bytes, "active_workers": active_workers, "workers_configured": workers_configured}

        # Обновляем кэш только если данные валидны
        global _LAST_GOOD_SYSTEM_INFO, _LAST_GOOD_DB_SIZE_BYTES
        if sys_info_merged:
            _LAST_GOOD_SYSTEM_INFO = sys_info_merged
        if isinstance(db_size_bytes, int) and db_size_bytes >= 0:
            _LAST_GOOD_DB_SIZE_BYTES = db_size_bytes

        stats["system_info"] = sys_info_merged
        stats["status"] = "ok"
        return stats
    except Exception as e:
        print(f"Ошибка получения статистики: {e}")
        # Фолбэк: возвращаем последние валидные метрики вместо нулей
        fallback_sys = _LAST_GOOD_SYSTEM_INFO or {"db_size": _LAST_GOOD_DB_SIZE_BYTES or 0}
        return {
            "tasks": {},
            "vacancies": {"total_vacancies": 0, "processed_vacancies": 0, "today_vacancies": 0},
            "timestamp": datetime.now().isoformat(),
            "system_info": fallback_sys,
            "status": "degraded",
            "error": str(e)
        }

@app.get("/api/tasks")
async def get_tasks(
    status: Optional[str] = None, 
    limit: int = 50,
    offset: int = 0
):
    """API получения списка задач"""
    task_db = TaskDatabase()
    # // Chg_TASKS_API_1509: поддержка CSV статусов (напр. running,pending)
    status_param: Optional[object] = None
    if status:
        status_param = [s.strip() for s in status.split(',') if s.strip()]
        if len(status_param) == 1:
            status_param = status_param[0]
    tasks = task_db.get_tasks(status=status_param, limit=limit, offset=offset)
    
    # Форматирование времени
    for task in tasks:
        if task.get('created_at'):
            try:
                if task['created_at'] > 1000000000:
                    task['created_at_formatted'] = datetime.fromtimestamp(task['created_at']).isoformat()
                else:
                    unix_time = (task['created_at'] - 2440587.5) * 86400
                    task['created_at_formatted'] = datetime.fromtimestamp(unix_time).isoformat()
            except:
                task['created_at_formatted'] = 'Invalid'
    
    return {"tasks": tasks, "total": len(tasks)}

@app.get("/api/task/{task_id}")
async def get_task_detail(task_id: str):
    """API получения детальной информации о задаче"""
    task_db = TaskDatabase()
    task = task_db.get_task(task_id)
    
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return task

@app.get("/api/vacancies/recent")
async def get_recent_vacancies(limit: int = 20):
    """API получения последних вакансий"""
    # // Chg_API_1509: используем v4 TaskDatabase и маппим поля под UI
    db = TaskDatabase()
    items = db.get_recent_vacancies(limit=limit)
    # Маппинг к ожидаемым ключам UI (dashboard.js)
    mapped = []
    for v in items:
        mapped.append({
            "id": v.get("id"),
            "hh_id": v.get("hh_id"),
            "name": v.get("title"),
            "employer_name": v.get("company"),
            "area_name": v.get("area"),
            "published_at": v.get("published_at"),
            "url": v.get("url"),
            "salary_text": None
        })
    return {"vacancies": mapped}

@app.get("/api/filters")
async def get_filters():
    """API: Список фильтров из config/filters.json"""
    try:
        filters_path = Path("config/filters.json")
        if filters_path.exists():
            with open(filters_path, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            # // Chg_API_1509: нормализуем структуру и признак активности под UI
            if isinstance(raw, dict) and "filters" in raw:
                items = raw["filters"]
            elif isinstance(raw, dict):
                items = list(raw.values())
            else:
                items = raw
            for item in items:
                if "active" not in item:
                    item["active"] = item.get("enabled", True)
            return {"filters": items}
        return {"filters": []}
    except Exception as e:
        return {"error": str(e), "filters": []}

@app.get("/api/system")
async def get_system():
    """API: Системные метрики (память/CPU/диск) как в v3"""
    return _get_system_info()

@app.get("/api/processes")
async def get_processes():
    """API: Активные процессы (аналог process_status v3)"""
    return {"active_processes": _get_active_processes()}

@app.get("/api/enhanced")
async def get_enhanced_metrics():
    """API: Расширенные метрики из логов (как в v3)"""
    return _load_enhanced_metrics()

@app.post("/api/tests/functional")
async def run_functional_tests():
    """API: Запуск функциональных тестов"""
    import subprocess
    import sys
    from pathlib import Path
    
    try:
        logging.info("web_api_test_start: functional")
        # Запускаем functional_test_runner.py
        result = subprocess.run([
            sys.executable, 'tests/functional_test_runner.py', '--json'
        ], capture_output=True, text=True, timeout=300, cwd=Path.cwd())
        
        if result.returncode == 0:
            # Пытаемся найти JSON отчет
            import glob
            json_files = glob.glob('reports/functional_test_report_*.json')
            if json_files:
                latest_report = max(json_files, key=os.path.getctime)
                with open(latest_report, 'r', encoding='utf-8') as f:
                    report_data = json.load(f)
                try:
                    sr = report_data.get('success_rate', 0)
                    total = (report_data.get('statistics') or {}).get('total', 0)
                    passed = (report_data.get('statistics') or {}).get('passed', 0)
                    logging.info(f"web_api_test_finish: functional success_rate={sr} passed={passed}/{total}")
                except Exception:
                    pass
                return report_data
            else:
                # Если JSON файла нет, возвращаем базовый результат
                res = {
                    "success_rate": 100 if result.returncode == 0 else 0,
                    "statistics": {"total": 1, "passed": 1, "failed": 0},
                    "results": []
                }
                logging.info("web_api_test_finish: functional success_rate=100 passed=1/1 (fallback)")
                return res
        else:
            res = {
                "success_rate": 0,
                "statistics": {"total": 1, "passed": 0, "failed": 1},
                "results": [{"status": "FAIL", "id": "RUN", "name": "Test Execution", "message": result.stderr or "Unknown error"}],
                "error": result.stderr
            }
            logging.info("web_api_test_finish: functional success_rate=0 passed=0/1 (returncode!=0)")
            return res
            
    except subprocess.TimeoutExpired:
        logging.info("web_api_test_finish: functional timeout")
        return {"error": "Test execution timeout", "success_rate": 0, "statistics": {"total": 1, "passed": 0, "failed": 1}}
    except Exception as e:
        logging.info(f"web_api_test_finish: functional error={e}")
        return {"error": str(e), "success_rate": 0, "statistics": {"total": 1, "passed": 0, "failed": 1}}

@app.post("/api/tests/system")
async def run_system_tests():
    """API: Запуск системных тестов"""
    import subprocess
    import sys
    from pathlib import Path
    
    try:
        logging.info("web_api_test_start: system")
        # Запускаем system_test_runner.py
        result = subprocess.run([
            sys.executable, 'tests/system_test_runner.py'
        ], capture_output=True, text=True, timeout=300, cwd=Path.cwd())
        
        # Пытаемся найти JSON отчет системных тестов
        import glob
        json_files = glob.glob('reports/system_test_report_*.json')
        
        if json_files:
            latest_report = max(json_files, key=os.path.getctime)
            with open(latest_report, 'r', encoding='utf-8') as f:
                report_data = json.load(f)
            
            # Преобразуем формат для совместимости с frontend
            res = {
                "summary": {
                    "total": report_data.get("summary", {}).get("total_tests", 0),
                    "passed": report_data.get("summary", {}).get("passed", 0),
                    "failed": report_data.get("summary", {}).get("failed", 0),
                    "success_rate": report_data.get("summary", {}).get("success_rate", 0)
                },
                "results": [
                    {
                        "id": k,
                        "name": v.get("name", "Unknown"),
                        "status": "passed" if v.get("passed", False) else "failed",
                        "error": v.get("error"),
                        "time": v.get("time", 0)
                    }
                    for k, v in report_data.get("details", {}).items()
                ]
            }
            try:
                sr = res["summary"].get("success_rate", 0)
                total = res["summary"].get("total", 0)
                passed = res["summary"].get("passed", 0)
                logging.info(f"web_api_test_finish: system success_rate={sr} passed={passed}/{total}")
            except Exception:
                pass
            return res
        else:
            # Если JSON файла нет, возвращаем результат на основе returncode
            success = result.returncode == 0
            res = {
                "summary": {
                    "total": 1,
                    "passed": 1 if success else 0,
                    "failed": 0 if success else 1,
                    "success_rate": 100 if success else 0
                },
                "results": [] if success else [
                    {"id": "SYS", "name": "System Test", "status": "failed", "error": result.stderr or "Unknown error"}
                ]
            }
            logging.info(f"web_api_test_finish: system success_rate={'100' if success else '0'} passed={'1' if success else '0'}/1 (no report)")
            return res
            
    except subprocess.TimeoutExpired:
        logging.info("web_api_test_finish: system timeout")
        return {
            "summary": {"total": 1, "passed": 0, "failed": 1, "success_rate": 0},
            "results": [{"id": "TIMEOUT", "name": "Test Timeout", "status": "failed", "error": "Test execution timeout"}]
        }
    except Exception as e:
        logging.info(f"web_api_test_finish: system error={e}")
        return {
            "summary": {"total": 1, "passed": 0, "failed": 1, "success_rate": 0},
            "results": [{"id": "ERROR", "name": "Test Error", "status": "failed", "error": str(e)}]
        }

@app.post("/api/tests/smoke")
async def run_smoke_test():
    """API: Быстрый smoke-тест загрузки 1 страницы вакансий по первому активному фильтру"""
    try:
        logging.info("web_api_test_start: smoke")
        # Загружаем первый активный фильтр
        filters_path = Path("config/filters.json")
        if not filters_path.exists():
            return {"status": "error", "message": "filters.json not found"}
        raw = json.load(open(filters_path, 'r', encoding='utf-8'))
        if isinstance(raw, dict) and "filters" in raw:
            items = raw["filters"]
        elif isinstance(raw, dict):
            items = list(raw.values())
        else:
            items = raw
        active = [f for f in items if f.get('active', f.get('enabled', True))]
        if not active:
            return {"status": "error", "message": "no active filters"}
        flt = active[0]
        from plugins.fetcher_v4 import VacancyFetcher
        fetcher = VacancyFetcher(rate_limit_delay=0.2)
        # Загрузка первой страницы
        items = fetcher._fetch_page(flt, page=0)
        # Сохранение в БД v4
        saved = fetcher._save_vacancies(items, flt.get('id'))
        result = {
            "status": "ok",
            "items_count": len(items),
            "loaded_count": saved,
            "filter_id": flt.get('id'),
            "filter_name": flt.get('name'),
            "sample": [
                {"id": it.get('id'), "name": it.get('name')} for it in items[:3]
            ]
        }
        logging.info(f"web_api_test_finish: smoke items={len(items)} saved={saved}")
        return result
    except Exception as e:
        logging.info(f"web_api_test_finish: smoke error={e}")
        return {"status": "error", "message": str(e)}

@app.get("/api/tests/history")
async def get_tests_history(limit: int = 10):
    """API: История последних тестов (functional/system) из папки reports/
    Возвращает список последних отчетов с унифицированными полями
    """
    try:
        Path('reports').mkdir(exist_ok=True)
        files = []
        # Собираем отчеты функциональных и системных тестов
        files.extend(glob.glob('reports/functional_test_report_*.json'))
        files.extend(glob.glob('reports/system_test_report_*.json'))
        files = sorted(files, key=os.path.getmtime, reverse=True)[:max(1, min(limit, 50))]
        history: List[Dict[str, Any]] = []
        for fp in files:
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                mtime = datetime.fromtimestamp(os.path.getmtime(fp)).isoformat()
                if os.path.basename(fp).startswith('functional_test_report_'):
                    stats = data.get('statistics') or {}
                    history.append({
                        'type': 'functional',
                        'file': os.path.basename(fp),
                        'timestamp': data.get('timestamp') or mtime,
                        'success_rate': data.get('success_rate', 0),
                        'total': stats.get('total', 0),
                        'passed': stats.get('passed', 0),
                        'failed': stats.get('failed', 0)
                    })
                elif os.path.basename(fp).startswith('system_test_report_'):
                    summary = data.get('summary') or {}
                    history.append({
                        'type': 'system',
                        'file': os.path.basename(fp),
                        'timestamp': data.get('timestamp') or mtime,
                        'success_rate': summary.get('success_rate', 0),
                        'total': summary.get('total_tests', 0),
                        'passed': summary.get('passed', 0),
                        'failed': summary.get('failed', 0)
                    })
            except Exception:
                continue
        logging.info(f"web_api_test_history: returned={len(history)}")
        return {'history': history}
    except Exception as e:
        logging.info(f"web_api_test_history_error: {e}")
        return {'history': [], 'error': str(e)}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket для real-time обновлений"""
    await manager.connect(websocket)
    try:
        while True:
            # Отправляем обновления каждые 5 секунд
            await asyncio.sleep(5)
            
            task_db = TaskDatabase()
            stats = task_db.get_stats()
            
            await websocket.send_text(json.dumps({
                "type": "stats_update",
                "data": stats,
                "timestamp": datetime.now().isoformat()
            }))
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.get("/api/system/health")
async def health_check():
    """Проверка работоспособности системы"""
    try:
        task_db = TaskDatabase()
        stats = task_db.get_stats()
        
        return {
            "status": "healthy",
            "database": "connected",
            "tasks_processed": stats.get("tasks", {}).get("completed", 0),
            "uptime": "running",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
        )

@app.get("/api/daemon/status")
async def get_daemon_status():
    """API: Статус демона планировщика"""
    import psutil 
    from pathlib import Path
    
    pid_file = Path('data/scheduler_daemon.pid')
    
    if not pid_file.exists():
        return {
            "status": "stopped",
            "running": False,
            "pid": None,
            "message": "PID файл не найден"
        }
    
    try:
        pid = int(pid_file.read_text().strip())
        
        if psutil.pid_exists(pid):
            try:
                process = psutil.Process(pid)
                return {
                    "status": "running", 
                    "running": True,
                    "pid": pid,
                    "cpu_percent": round(process.cpu_percent(), 1),
                    "memory_mb": round(process.memory_info().rss / 1024 / 1024, 1),
                    "started": datetime.fromtimestamp(process.create_time()).isoformat(),
                    "message": "Демон активен"
                }
            except psutil.NoSuchProcess:
                pid_file.unlink()  # Удаляем устаревший PID
                return {
                    "status": "stopped",
                    "running": False, 
                    "pid": None,
                    "message": "Процесс не найден"
                }
        else:
            pid_file.unlink()  # Удаляем устаревший PID
            return {
                "status": "stopped",
                "running": False,
                "pid": None, 
                "message": "Процесс не существует"
            }
            
    except Exception as e:
        return {
            "status": "error",
            "running": False,
            "pid": None,
            "message": f"Ошибка проверки: {str(e)}"
        }

@app.get("/api/daemon/tasks")
async def get_daemon_tasks():
    """API: Последние задачи демона планировщика"""
    # Попытка получить статус демона через его API (если доступен)
    # Поскольку демон работает независимо, читаем логи
    from pathlib import Path
    import re
    
    log_file = Path('logs/app.log')
    if not log_file.exists():
        return {"tasks": [], "message": "Лог файл не найден"}
    
    try:
        # Читаем последние строки лога
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Ищем записи планировщика
        scheduler_logs = []
        for line in reversed(lines[-200:]):  # Последние 200 строк
            if 'scheduler_daemon' in line and ('задача' in line.lower() or 'task' in line.lower()):
                # Парсим лог: время, уровень, сообщение
                match = re.match(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) - .* - (\w+) - (.+)', line.strip())
                if match:
                    timestamp, level, message = match.groups()
                    scheduler_logs.append({
                        "timestamp": timestamp,
                        "level": level,
                        "message": message.strip()
                    })
                    
                if len(scheduler_logs) >= 10:  # Ограничиваем количество
                    break
        
        return {
            "tasks": scheduler_logs,
            "message": f"Найдено {len(scheduler_logs)} записей планировщика"
        }
        
    except Exception as e:
        return {
            "tasks": [],
            "message": f"Ошибка чтения логов: {str(e)}"
        }

# Background task для broadcast обновлений
async def broadcast_updates():
    """Фоновая задача для отправки обновлений всем подключенным клиентам"""
    while True:
        try:
            # Получаем актуальные данные безопасно
            try:
                stats_data = await get_stats()
            except Exception as e:
                print(f"Ошибка получения статистики: {e}")
                stats_data = {"status": "error", "error": str(e)}
            
            try:
                system_info = _get_system_info()
            except Exception as e:
                print(f"Ошибка получения системной информации: {e}")
                system_info = {"status": "error", "error": str(e)}
            
            # Отправляем всем подключенным клиентам
            if manager.active_connections:
                await manager.broadcast({
                    "type": "stats_update",
                    "data": stats_data,
                    "timestamp": time.time()
                })
                
                await manager.broadcast({
                    "type": "system_update", 
                    "data": system_info,
                    "timestamp": time.time()
                })
            
            await asyncio.sleep(5)  # Обновляем каждые 5 секунд
            
        except Exception as e:
            print(f"Broadcast error: {e}")
            await asyncio.sleep(10)  # При ошибке ждем дольше

@app.on_event("startup")
async def startup_event():
    """Событие запуска - запускаем фоновые задачи"""
    asyncio.create_task(broadcast_updates())

def run_web_server(host: str = "localhost", port: int = 8080, debug: bool = False):
    """Запуск веб-сервера"""
    # // Chg_UVICORN_RELOAD_1509: при debug=True uvicorn требует импорт-строку
    if debug:
        # Используем строку импорта приложения, чтобы работал reload
        uvicorn.run("web.server:app", host=host, port=port, reload=True)
    else:
        uvicorn.run(app, host=host, port=port)

def _get_system_info() -> Dict[str, Any]:
    """Получение системных метрик: память%/диск%/CPU/нагрузка + метрики из БД"""
    try:
        vm = psutil.virtual_memory()
        total_mb = round(vm.total / 1024 / 1024, 2)
        memory_percent = round(vm.percent, 1)
        
        # Диск: процент использования
        try:
            if os.name == 'nt':  # Windows
                disk = psutil.disk_usage('C:\\')
            else:
                disk = psutil.disk_usage('/')
            disk_percent = round((disk.used / disk.total) * 100, 1)
        except Exception:
            disk_percent = 0.0
        
        # // Chg_STATS_CACHE_1509: неблокирующее измерение CPU (interval=0)
        cpu_percent = round(psutil.cpu_percent(interval=0), 1)
        
        load_avg = None
        try:
            la1, la5, la15 = psutil.getloadavg()  # Не работает на Windows
            load_avg = {"1m": round(la1, 2), "5m": round(la5, 2), "15m": round(la15, 2)}
        except (AttributeError, OSError):
            load_avg = {"1m": None, "5m": None, "15m": None}
        
        # Размер всех файлов *.sqlite* в рабочей папке
        try:
            db_files = glob.glob("data/*.sqlite*", recursive=False)
            db_total_size = sum(os.path.getsize(f) for f in db_files if os.path.exists(f))
            db_total_mb = round(db_total_size / 1024 / 1024, 2)
        except Exception:
            db_total_mb = 0.0
        
        # Расширенные метрики
        enhanced_metrics = _load_enhanced_metrics()
        
        return {
            "memory_total_mb": total_mb,
            "memory_percent": memory_percent,
            "disk_percent": disk_percent,
            "cpu_percent": cpu_percent,
            "load_avg": load_avg,
            "db_files_total_mb": db_total_mb,
            **enhanced_metrics
        }
    except Exception as e:
        print(f"Ошибка получения системных метрик: {e}")
        return {
            "memory_total_mb": 0,
            "memory_percent": 0,
            "disk_percent": 0,
            "cpu_percent": 0,
            "load_avg": {"1m": None, "5m": None, "15m": None},
            "db_files_total_mb": 0
        }

def _load_enhanced_metrics() -> Dict[str, Any]:
    """Загрузка расширенных метрик из logs/dashboard_metrics.json или logs/local_metrics.txt"""
    try:
        logs_dir = Path("logs")
        json_file = logs_dir / "dashboard_metrics.json"
        txt_file = logs_dir / "local_metrics.txt"

        if json_file.exists():
            try:
                with open(json_file, 'r', encoding='utf-8') as jf:
                    data = json.load(jf)
                def _norm_dt(v):
                    try:
                        if isinstance(v, str):
                            return v.replace('T', ' ')
                    except Exception:
                        pass
                    return v
                return {
                    "db_last_update": _norm_dt(data.get("db_last_update", "unknown")),
                    "max_published_at": _norm_dt(data.get("max_published_at", "unknown")),
                    "unique_publish_dates": int(data.get("unique_publish_dates", 0) or 0),
                    "captcha_detected": int(data.get("captcha_detected", 0) or 0),
                    "captcha_solved": int(data.get("captcha_solved", 0) or 0),
                    "last_captcha": _norm_dt(data.get("last_captcha", "none")),
                    "unique_companies": int(data.get("unique_companies", 0) or 0)
                }
            except Exception:
                pass

        # Фоллбэк: TXT
        if txt_file.exists():
            with open(txt_file, 'r', encoding='utf-8') as f:
                content = f.read()

            metrics = {}
            for line in content.split('\n'):
                if '=' in line and not line.startswith('['):
                    key, value = line.split('=', 1)
                    value = value.strip()
                    try:
                        if value.replace('.', '', 1).isdigit():
                            if '.' in value:
                                metrics[key.lower()] = float(value)
                            else:
                                metrics[key.lower()] = int(value)
                        else:
                            metrics[key.lower()] = value
                    except Exception:
                        metrics[key.lower()] = value

            def _norm_dt(v):
                try:
                    if isinstance(v, str):
                        return v.replace('T', ' ')
                except Exception:
                    pass
                return v

            return {
                "db_last_update": _norm_dt(metrics.get("db_last_update", "unknown")),
                "max_published_at": _norm_dt(metrics.get("max_published_at", "unknown")),
                "unique_publish_dates": metrics.get("unique_publish_dates", 0),
                "captcha_detected": metrics.get("captcha_detected", 0),
                "captcha_solved": metrics.get("captcha_solved", 0),
                "last_captcha": _norm_dt(metrics.get("last_captcha", "none")),
                "unique_companies": metrics.get("unique_companies", 0)
            }
        
        return {
            "db_last_update": "unknown",
            "max_published_at": "unknown",
            "unique_publish_dates": 0,
            "captcha_detected": 0,
            "captcha_solved": 0,
            "last_captcha": "none",
            "unique_companies": 0
        }

    except Exception:
        return {
            "db_last_update": "error",
            "max_published_at": "error",
            "unique_publish_dates": 0,
            "captcha_detected": 0,
            "captcha_solved": 0,
            "last_captcha": "error",
            "unique_companies": 0
        }

def _get_active_processes() -> List[Dict[str, Any]]:
    """Получение списка активных процессов (для v4 - из tasks с status='running')"""
    try:
        task_db = TaskDatabase()
        
        # В v4 нет process_status таблицы, используем tasks
        with task_db.get_connection() as conn:
            cursor = conn.execute("""
                SELECT id, type, status, created_at, started_at, progress_json 
                FROM tasks 
                WHERE status = 'running' 
                ORDER BY created_at DESC
            """)
            
            processes = []
            for row in cursor.fetchall():
                task_id, task_type, status, created_at, started_at, progress_json = row
                
                # Парсим прогресс
                progress_data = {}
                if progress_json:
                    try:
                        progress_data = json.loads(progress_json)
                    except:
                        pass
                
                total_items = progress_data.get('total', 0)
                processed_items = progress_data.get('processed', 0)
                progress = 0.0
                eta_minutes = None
                
                if total_items and total_items > 0:
                    progress = (processed_items / total_items) * 100
                    # Примерная оценка времени
                    if started_at and processed_items > 0:
                        elapsed = time.time() - started_at
                        speed_per_second = processed_items / elapsed if elapsed > 0 else 0
                        remaining = total_items - processed_items
                        if speed_per_second > 0:
                            eta_minutes = round((remaining / speed_per_second) / 60)
                
                processes.append({
                    "id": task_id,
                    "name": f"{task_type} Task",
                    "status": status,
                    "progress": round(progress, 1),
                    "eta_minutes": eta_minutes,
                    "speed_per_minute": progress_data.get('speed_per_minute', 0.0),
                    "total_items": total_items,
                    "processed_items": processed_items
                })
            
            return processes
            
    except Exception as e:
        print(f"Ошибка чтения активных процессов: {e}")
        return []

def run_server(host="localhost", port=8080):
    """Запуск FastAPI сервера"""
    uvicorn.run(app, host=host, port=port, log_level="info")

if __name__ == "__main__":
    run_web_server()
